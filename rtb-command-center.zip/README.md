# The Pitt · Amazon DSP Disconnection Room

> **Equativ · AI Days 2026 (Competitive Track)**  
> Production-grade AI investigation assistant and revenue-at-risk triage room for publisher networks disconnected from the Amazon DSP.

---

## 1. Overview & Purpose

**The Pitt** is the operational output layer and triage room for publisher networks disconnected from the Amazon DSP. It surfaces:
- **Which networks are cut**: Tracked across 365 days of alert history with exact aging buckets.
- **How much revenue is at risk**: Strict weekly run-rate tracking based on 7-day pre-cut spend (`SPEND_7D_BEFORE`).
- **Why (Evidence-Based Checks)**: 4 core checks across `BEFORE` and `AFTER` windows (`ADS_TXT`, `SCO`, `BLOCKED_INVENTORY`, `IVT`).
- **What to fix to reconnect**: Step-by-step remediation plans, OpenRTB 2.5 readiness checklists, and draft communications locked under human approval.

---

## 2. Architecture & File Structure

The application enforces a **strict architectural decoupling**:
- **All raw data lives in exactly one file**: `src/lib/pitt/data.ts`.
- **All thresholds, labels, priority rules, and derived selectors live in**: `src/lib/pitt/engine.ts`.
- **Zero computation in components**: React components only render selectors derived from `engine.ts`.
- **Filter-First Derivations**: Filters (Business unit, Amazon partner seat, Region, Priority, Status, Date window, Search) are applied *before* any derivation, guaranteeing that every KPI card, Sankey flow, waterfall step, and table row on screen reflects the identical cohort.

```
├── README.md                           # Documentation, data contract & Snowflake export guide
├── index.html                          # Entry HTML with Inter & JetBrains Mono typography
├── metadata.json                       # Applet metadata & capabilities
├── package.json                        # Dependencies (React 19, Tailwind v4, d3-sankey, Recharts)
├── src/
│   ├── App.tsx                         # Main app router, reconciliation logger & layout
│   ├── index.css                       # Ops-room dark theme variables & tabular numerals
│   ├── main.tsx                        # Application mount
│   ├── components/
│   │   ├── Header.tsx                  # 3-zone top bar, cohort summary, filter drawer, view toggle
│   │   ├── KpiStrip.tsx                # 5 KPI cards with delta & definition tooltips
│   │   ├── SankeyFlow.tsx              # Animated Sankey (d3-sankey) with keyboard nav & table equivalent
│   │   ├── RiskAgingTable.tsx          # Northwind AR aging table (Current, 1–7, 8–30, 31–90, 90+)
│   │   ├── DemandFunnelView.tsx        # Crestline demand funnel (Auctions → Impressions) & drop triage
│   │   ├── WaterfallAndWhatIf.tsx      # Variance waterfall & What-If simulator ("Projection, not a forecast")
│   │   ├── NetworkDetailPage.tsx      # Drill-down: 4x2 checks matrix, AI investigator card, readiness checklist
│   │   ├── PublisherView.tsx           # Publisher-facing view with privacy masking & timeline
│   │   ├── ThresholdConfigModal.tsx    # Live editor for P0/P1/P2 thresholds & Amazon RPMBR reference
│   │   ├── UseYourDataModal.tsx        # In-app data onboarding guide
│   │   └── SpecsDocumentation.tsx      # Specifications & seed scenarios A, B, C
│   └── lib/
│       └── pitt/
│           ├── data.ts                 # Source data arrays (ANALYTICS.PUBLIC.VIEW_DISCONNECTION_ALERT_365DAYS)
│           ├── engine.ts               # Pure calculation engine, selectors & reconciliation invariants
│           └── engine.test.ts          # Native node:test suite verifying logic & invariants
```

---

## 3. Strict Data Contract

### A. Disconnections
Source view: `ANALYTICS.PUBLIC.VIEW_DISCONNECTION_ALERT_365DAYS`
| Field Name | Type | Description |
| :--- | :--- | :--- |
| `PARTNER_ID` | `number` | Amazon DSP seat identifier (e.g., 437, 489, 490, 491, 492) |
| `PARTNER_NAME` | `string` | Human-readable Amazon seat name (e.g., "Amazon DSP US (437)") |
| `PUBLISHER` | `string` | Publisher network name |
| `NETWORK_ID` | `number` | Unique Equativ Network ID |
| `BUSINESS_UNIT` | `string` | `'Web & Media'` \| `'CTV & Video'` \| `'In-App & Gaming'` |
| `USERNAME` | `string` | Equativ account owner email (hidden in Publisher View) |
| `CUT_AT` | `string` | ISO 8601 Timestamp of disconnection |
| `RECONNECTED_AT` | `string \| null` | ISO 8601 Timestamp or `null`. **`null` strictly denotes still disconnected; never infer it.** |
| `SPEND_7D_BEFORE` | `number \| null` | Weekly revenue run-rate prior to cut; `null` if unmonitored |

### B. Checks
| Field Name | Values | Description |
| :--- | :--- | :--- |
| `network_id` | `number` | Target network ID |
| `check` | `'ADS_TXT'` \| `'SCO'` \| `'BLOCKED_INVENTORY'` \| `'IVT'` | Check type |
| `window` | `'BEFORE'` \| `'AFTER'` | Pre-cut baseline vs post-cut audit window |
| `result` | `'PASS'` \| `'FAIL'` \| `'NO_DATA'` | **`NO_DATA` means unknown (rendered slate grey, never as a pass)** |
| `evidence_ref` | `string` | Verifiable audit log reference code (e.g. `EV-1082-AT-A`) |
| `detail` | `string` | Specific diagnosis explanation |

### C. Traffic Metrics
| Field Name | Description |
| :--- | :--- |
| `metric` | Metric label (e.g. "Network Total Auctions", "Amazon Bid Requests") |
| `partner_name` | Partner name |
| `partner_ids` | Array of partner IDs |
| `change_pct` | Percentage delta post-cut |
| `before`, `after` | Raw volumes |
| `period` | Comparison window (`'7d_before_vs_after'`) |
| `source` | Telemetry source |

### D. Demand Funnel
Stages: `Auctions` → `Bid requests` → `Bids` → `Wins` → `Impressions`  
Includes `drop_reasons[]`: `{ stage, reason, count }`.

### E. AI Investigation
- `hypotheses[]`: `{ label, confidence ∈ {LOW, MEDIUM, HIGH}, evidence_refs[], missing_info[] }`
- **Rule 1**: If no check is `FAIL`, **never display HIGH confidence**.
- **Rule 2**: If an `evidence_ref` does not exist in `CHECKS_DATA`, the app displays a red **"Unverified evidence"** badge.
- `draft_message`: Synthesized communication with mandatory **"Requires human approval in Slack"** lock. No automated send button exists.
- `validation`: `{ passed, ai_output_accepted, fallback_fields[] }`.

---

## 4. Priority Engine & Reference Benchmarks

Configurable via `src/lib/pitt/engine.ts` or the in-app **"Placeholder thresholds"** control:
- **P0**: Still disconnected (`RECONNECTED_AT === null`) AND `SPEND_7D_BEFORE >= $10,000`.
- **P1**: `SPEND_7D_BEFORE >= $1,000` OR `REVENUE_DROP_PCT >= 50%`.
- **P2**: Still disconnected with missing revenue (`SPEND_7D_BEFORE === null`).
- **Amazon RPMBR Regional References**:
  - Americas: `$50`
  - EMEA: `$25`
  - APAC: `$10`

---

## 5. Reconciliation Invariant

On application mount and whenever cohort filters change, `checkReconciliation()` computes:
$$\sum \text{Revenue at Risk (Sankey Flow)} = \text{KPI Total} = \sum \text{Risk Table Column}$$
And logs to the browser console:
```
[THE PITT RECONCILIATION] RECONCILIATION OK - Sankey Total: $274,300 | KPI Total: $274,300 | Table Total: $274,300
```
If any discrepancy occurs, the exact difference is logged as an error.

---

## 6. How to Replace Sample Data with Snowflake CSV / SQL Export

### Step 1: Run Snowflake Query
Execute in Snowflake:
```sql
SELECT 
    PARTNER_ID,
    PARTNER_NAME,
    PUBLISHER,
    NETWORK_ID,
    BUSINESS_UNIT,
    USERNAME,
    CUT_AT,
    RECONNECTED_AT,
    SPEND_7D_BEFORE
FROM ANALYTICS.PUBLIC.VIEW_DISCONNECTION_ALERT_365DAYS
WHERE CUT_AT >= DATEADD('day', -365, CURRENT_TIMESTAMP())
ORDER BY SPEND_7D_BEFORE DESC NULLS LAST;
```

### Step 2: Replace Data in `src/lib/pitt/data.ts`
1. Replace `DISCONNECTIONS_DATA` with the exported array of objects.
2. Toggle `IS_SYNTHETIC_DEMO_DATA = false` to remove the persistent demo banner.
3. Run `node --test src/lib/pitt/engine.test.ts` to automatically verify data integrity and the reconciliation invariant.

---

## 7. Testing & Verification

Run the unit test suite natively using Node 22+:
```bash
node --test src/lib/pitt/engine.test.ts
```
Verifies:
- Priority engine rules (P0, P1, P2)
- AR aging bucket bounds (Current, 1–7, 8–30, 31–90, 90+)
- Mathematical reconciliation invariant (Sankey = KPI = Table)
- AI confidence guardrails (downgrading HIGH when no checks fail)
- Unverified evidence detection
- Traffic signal banner conditions ("Drop is Amazon-specific")
- What-If simulation calculations
