/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { EnrichedDisconnection, AgingBucket, PriorityLevel, RiskLevel } from '../lib/pitt/engine.ts';
import { ArrowUpDown, AlertCircle, ArrowRight, UserCheck, Shield } from 'lucide-react';

interface RiskAgingTableProps {
  cohort: EnrichedDisconnection[];
  onSelectNetwork: (networkId: number) => void;
  selectedNetworkId?: number | null;
  isPublisherView?: boolean;
}

type SortField = 'Age' | 'Value' | 'A-Z';

export const RiskAgingTable: React.FC<RiskAgingTableProps> = ({
  cohort,
  onSelectNetwork,
  selectedNetworkId,
  isPublisherView = false,
}) => {
  const [sortField, setSortField] = useState<SortField>('Age');
  const [atRiskOnly, setAtRiskOnly] = useState(false);
  const [selectedBucketFilter, setSelectedBucketFilter] = useState<AgingBucket | 'ALL'>('ALL');

  // Compute bucket totals for the AR Aging distribution bar
  const bucketTotals = useMemo(() => {
    const buckets: Record<AgingBucket, number> = {
      'Current': 0,
      '1–7': 0,
      '8–30': 0,
      '31–90': 0,
      '90+': 0,
    };

    cohort.forEach(r => {
      if (r.RECONNECTED_AT === null) {
        buckets[r.agingBucket] += (r.SPEND_7D_BEFORE ?? 0);
      }
    });

    const total = Object.values(buckets).reduce((sum, val) => sum + val, 0) || 1;

    return {
      buckets,
      total,
      shares: {
        'Current': (buckets['Current'] / total) * 100,
        '1–7': (buckets['1–7'] / total) * 100,
        '8–30': (buckets['8–30'] / total) * 100,
        '31–90': (buckets['31–90'] / total) * 100,
        '90+': (buckets['90+'] / total) * 100,
      },
    };
  }, [cohort]);

  // Filter and sort rows
  const sortedRows = useMemo(() => {
    let rows = [...cohort];

    if (atRiskOnly) {
      rows = rows.filter(r => r.RECONNECTED_AT === null);
    }

    if (selectedBucketFilter !== 'ALL') {
      rows = rows.filter(r => r.agingBucket === selectedBucketFilter);
    }

    if (sortField === 'Age') {
      rows.sort((a, b) => b.daysSinceCut - a.daysSinceCut);
    } else if (sortField === 'Value') {
      rows.sort((a, b) => (b.SPEND_7D_BEFORE ?? -1) - (a.SPEND_7D_BEFORE ?? -1));
    } else if (sortField === 'A-Z') {
      rows.sort((a, b) => a.PUBLISHER.localeCompare(b.PUBLISHER));
    }

    return rows;
  }, [cohort, atRiskOnly, selectedBucketFilter, sortField]);

  const totalAtRiskShown = sortedRows
    .filter(r => r.RECONNECTED_AT === null)
    .reduce((sum, r) => sum + (r.SPEND_7D_BEFORE ?? 0), 0);

  // Styling helper for Risk tags
  const renderRiskBadge = (risk: RiskLevel) => {
    if (risk === 'Critical') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold tracking-wide uppercase bg-rose-500/10 text-rose-400 border border-rose-500/30">
          <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
          Critical
        </span>
      );
    }
    if (risk === 'High') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold tracking-wide uppercase bg-amber-500/10 text-amber-400 border border-amber-500/30">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
          High
        </span>
      );
    }
    if (risk === 'Watch') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold tracking-wide uppercase bg-blue-500/10 text-blue-400 border border-blue-500/30">
          <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />
          Watch
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold tracking-wide uppercase bg-slate-500/10 text-slate-400 border border-slate-500/30">
        <span className="w-1.5 h-1.5 rounded-full bg-slate-400" />
        Low
      </span>
    );
  };

  // Styling helper for Priority tags (P0 red, P1 amber, P2 blue)
  const renderPriorityBadge = (prio: PriorityLevel) => {
    if (prio === 'P0') {
      return (
        <span className="px-1.5 py-0.5 rounded text-[10px] font-mono-num font-bold bg-rose-600 text-white" title="P0: Still disconnected & spend >= $10K">
          P0
        </span>
      );
    }
    if (prio === 'P1') {
      return (
        <span className="px-1.5 py-0.5 rounded text-[10px] font-mono-num font-bold bg-amber-500 text-slate-950" title="P1: Spend >= $1K or revenue drop >= 50%">
          P1
        </span>
      );
    }
    return (
      <span className="px-1.5 py-0.5 rounded text-[10px] font-mono-num font-bold bg-blue-600 text-white" title="P2: Missing spend snapshot or lower risk">
        P2
      </span>
    );
  };

  return (
    <div className="rounded-xl border border-white/10 bg-[#0d1424] p-5 shadow-2xl">
      {/* Title & Stats */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-3">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Receivables & Triage Queue
          </span>
          <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight mt-0.5">
            Disconnection Risk & Aging Ledger
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            ${(totalAtRiskShown / 1000).toFixed(1)}K flagged at risk · Click any row to open AI investigation room
          </p>
        </div>

        {/* Controls: At-risk toggle and Sort */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setAtRiskOnly(!atRiskOnly)}
            className={`px-3 py-1.5 rounded-lg border text-xs font-medium transition-colors ${
              atRiskOnly
                ? 'bg-rose-600/20 text-rose-300 border-rose-500/40'
                : 'bg-slate-900 text-slate-300 border-white/10 hover:border-white/30'
            }`}
          >
            At-risk only
          </button>

          <div className="flex items-center gap-1 text-xs text-slate-400 bg-slate-900 border border-white/10 rounded-lg p-1">
            <span className="px-1.5 text-slate-500 font-medium">SORT</span>
            {(['Age', 'Value', 'A-Z'] as SortField[]).map(s => (
              <button
                key={s}
                onClick={() => setSortField(s)}
                className={`px-2 py-0.5 rounded text-xs transition-colors ${
                  sortField === s
                    ? 'bg-blue-600 text-white font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* AR Aging Bar (Northwind style visual segmented distribution) */}
      <div className="mb-4 pt-1">
        <div className="h-2 w-full rounded-full bg-slate-900 flex overflow-hidden">
          <div
            style={{ width: `${bucketTotals.shares['Current']}%` }}
            className="bg-blue-500 transition-all duration-300"
            title={`Current: $${bucketTotals.buckets['Current'].toLocaleString()}`}
          />
          <div
            style={{ width: `${bucketTotals.shares['1–7']}%` }}
            className="bg-sky-500 transition-all duration-300"
            title={`1–7d: $${bucketTotals.buckets['1–7'].toLocaleString()}`}
          />
          <div
            style={{ width: `${bucketTotals.shares['8–30']}%` }}
            className="bg-indigo-500 transition-all duration-300"
            title={`8–30d: $${bucketTotals.buckets['8–30'].toLocaleString()}`}
          />
          <div
            style={{ width: `${bucketTotals.shares['31–90']}%` }}
            className="bg-amber-500 transition-all duration-300"
            title={`31–90d: $${bucketTotals.buckets['31–90'].toLocaleString()}`}
          />
          <div
            style={{ width: `${bucketTotals.shares['90+']}%` }}
            className="bg-rose-500 transition-all duration-300"
            title={`90+d: $${bucketTotals.buckets['90+'].toLocaleString()}`}
          />
        </div>

        {/* Bucket amounts legend & interactive filter */}
        <div className="flex flex-wrap items-center justify-between text-[11px] text-slate-400 mt-2 font-mono-num gap-2">
          {(['Current', '1–7', '8–30', '31–90', '90+'] as AgingBucket[]).map(b => {
            const amount = bucketTotals.buckets[b];
            const isSelected = selectedBucketFilter === b;
            return (
              <button
                key={b}
                onClick={() => setSelectedBucketFilter(isSelected ? 'ALL' : b)}
                className={`flex items-center gap-1 px-1.5 py-0.5 rounded transition-colors ${
                  isSelected ? 'bg-white/10 text-white font-bold' : 'hover:text-slate-200'
                }`}
              >
                <span className="font-sans text-slate-400">{b}:</span>
                <span className="font-semibold text-white">
                  ${(amount / 1000).toFixed(0)}K
                </span>
              </button>
            );
          })}
          {selectedBucketFilter !== 'ALL' && (
            <button
              onClick={() => setSelectedBucketFilter('ALL')}
              className="text-xs text-blue-400 hover:underline font-sans"
            >
              Clear filter
            </button>
          )}
        </div>
      </div>

      {/* Table Data Grid */}
      <div className="overflow-x-auto rounded-lg border border-white/10">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="bg-slate-900 border-b border-white/10 text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
            <tr>
              <th className="py-2.5 px-3">Publisher / Network</th>
              <th className="py-2.5 px-3">Amazon Partner</th>
              <th className="py-2.5 px-2 text-center">Bucket</th>
              <th className="py-2.5 px-2 text-right">Days</th>
              <th className="py-2.5 px-3 text-right">Revenue at Risk</th>
              <th className="py-2.5 px-2 text-center">Priority</th>
              <th className="py-2.5 px-3">Risk Level</th>
              {!isPublisherView && <th className="py-2.5 px-3">Owner</th>}
              <th className="py-2.5 px-2 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5 bg-[#0a0f1d] text-slate-300">
            {sortedRows.length === 0 ? (
              <tr>
                <td colSpan={isPublisherView ? 8 : 9} className="py-8 text-center text-slate-500">
                  No networks match current filter criteria.
                </td>
              </tr>
            ) : (
              sortedRows.map(row => {
                const isSelected = selectedNetworkId === row.NETWORK_ID;
                const isReconnected = row.RECONNECTED_AT !== null;

                return (
                  <tr
                    key={row.NETWORK_ID}
                    onClick={() => onSelectNetwork(row.NETWORK_ID)}
                    className={`cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-blue-900/30 border-l-2 border-l-blue-400'
                        : 'hover:bg-white/5'
                    }`}
                  >
                    {/* Publisher with network ID and one-line reason */}
                    <td className="py-3 px-3">
                      <div className="font-medium text-white flex items-center gap-1.5">
                        <span>{row.PUBLISHER}</span>
                        {isReconnected && (
                          <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-1.5 py-0.2 rounded font-sans">
                            Reconnected
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                        <span className="font-mono-num text-slate-500">ID #{row.NETWORK_ID}</span>
                        <span>·</span>
                        <span className="text-slate-400">{row.BUSINESS_UNIT}</span>
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5 line-clamp-1 italic">
                        {row.ONE_LINE_REASON}
                      </div>
                    </td>

                    {/* Amazon Partner */}
                    <td className="py-3 px-3">
                      <div className="text-slate-200">{row.PARTNER_NAME}</div>
                      <div className="text-[11px] text-slate-500 font-mono-num">
                        Seat #{row.PARTNER_ID} ({row.REGION})
                      </div>
                    </td>

                    {/* Bucket */}
                    <td className="py-3 px-2 text-center font-mono-num">
                      <span className="px-1.5 py-0.5 rounded bg-slate-900 border border-white/10 text-[11px]">
                        {row.agingBucket}
                      </span>
                    </td>

                    {/* Days */}
                    <td className="py-3 px-2 text-right font-mono-num font-semibold text-white">
                      {row.daysSinceCut}d
                    </td>

                    {/* Revenue at Risk */}
                    <td className="py-3 px-3 text-right font-mono-num">
                      {row.SPEND_7D_BEFORE !== null ? (
                        <span className={`font-bold ${isReconnected ? 'text-slate-500 line-through' : 'text-rose-400'}`}>
                          ${row.SPEND_7D_BEFORE.toLocaleString()}
                        </span>
                      ) : (
                        <span className="text-slate-500 italic">No data</span>
                      )}
                    </td>

                    {/* Priority */}
                    <td className="py-3 px-2 text-center">
                      {renderPriorityBadge(row.priority)}
                    </td>

                    {/* Risk */}
                    <td className="py-3 px-3">
                      {renderRiskBadge(row.riskLevel)}
                    </td>

                    {/* Owner (internal only) */}
                    {!isPublisherView && (
                      <td className="py-3 px-3 font-mono-num text-[11px] text-slate-400">
                        {row.USERNAME}
                      </td>
                    )}

                    {/* Action */}
                    <td className="py-3 px-2 text-right">
                      <span className="inline-flex items-center text-blue-400 hover:text-blue-300 p-1">
                        <ArrowRight className="w-4 h-4" />
                      </span>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
