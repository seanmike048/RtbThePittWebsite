/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  EnrichedDisconnection,
  getNetworkChecks,
  getAIInvestigation,
  getNetworkReadiness,
} from '../lib/pitt/engine.ts';
import {
  CHECKS_DATA,
  TRAFFIC_METRICS_DATA,
  CheckType,
  CheckWindow,
  CheckResult,
} from '../lib/pitt/data.ts';
import {
  ArrowLeft,
  Lock,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  HelpCircle,
  ExternalLink,
  ShieldCheck,
  ShieldAlert,
  Brain,
  Info,
  Radio,
  FileCheck,
  Zap,
} from 'lucide-react';

interface NetworkDetailPageProps {
  networkId: number;
  cohort: EnrichedDisconnection[];
  onBack: () => void;
  isPublisherView?: boolean;
}

export const NetworkDetailPage: React.FC<NetworkDetailPageProps> = ({
  networkId,
  cohort,
  onBack,
  isPublisherView = false,
}) => {
  const network = cohort.find(c => c.NETWORK_ID === networkId);
  const checks = getNetworkChecks(networkId, CHECKS_DATA);
  const ai = getAIInvestigation(networkId, CHECKS_DATA, TRAFFIC_METRICS_DATA);
  const readinessSignals = getNetworkReadiness(networkId);
  const trafficMetrics = TRAFFIC_METRICS_DATA.filter(m => m.network_id === networkId);

  const [selectedEvidenceRef, setSelectedEvidenceRef] = useState<string | null>(null);

  if (!network) {
    return (
      <div className="p-8 text-center text-slate-400">
        <p>Network ID #{networkId} not found in current cohort.</p>
        <button
          onClick={onBack}
          className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg text-xs"
        >
          Back to Triage
        </button>
      </div>
    );
  }

  // 4 checks × 2 windows matrix helper
  const checkTypes: { type: CheckType; label: string; desc: string }[] = [
    { type: 'ADS_TXT', label: 'ads.txt / app-ads.txt', desc: 'Direct publisher line crawlers & declarations' },
    { type: 'SCO', label: 'Supply Chain (SCO)', desc: 'sellers.json nodes & schain completeness' },
    { type: 'BLOCKED_INVENTORY', label: 'Blocked Inventory', desc: 'Amazon global exclusions & brand safety' },
    { type: 'IVT', label: 'Invalid Traffic (IVT)', desc: 'Moat & Amazon DSP ad-fraud threshold' },
  ];

  const getCheckCell = (checkType: CheckType, windowType: CheckWindow) => {
    const row = checks.find(c => c.check === checkType && c.window === windowType);
    if (!row) {
      return { result: 'NO_DATA' as CheckResult, evidence_ref: 'N/A', detail: 'No log recorded' };
    }
    return row;
  };

  const renderResultBadge = (result: CheckResult) => {
    if (result === 'PASS') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded text-xs font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
          <CheckCircle2 className="w-3.5 h-3.5" />
          PASS
        </span>
      );
    }
    if (result === 'FAIL') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded text-xs font-semibold bg-rose-500/15 text-rose-400 border border-rose-500/30">
          <XCircle className="w-3.5 h-3.5" />
          FAIL
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded text-xs font-semibold bg-slate-500/15 text-slate-400 border border-slate-500/30">
        <HelpCircle className="w-3.5 h-3.5" />
        NO_DATA
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Breadcrumb & Actions */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <button
          onClick={onBack}
          className="px-3 py-1.5 rounded-lg border border-white/10 bg-slate-900 text-xs font-medium text-slate-300 hover:text-white hover:border-white/20 flex items-center gap-1.5 transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Triage Ledger</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">
            Network <strong className="text-white">#{network.NETWORK_ID}</strong>
          </span>
          <span className="text-slate-600">·</span>
          <span className="text-xs text-blue-400 font-mono-num font-semibold">
            Seat #{network.PARTNER_ID}
          </span>
        </div>
      </div>

      {/* Network Header Banner */}
      <div className="p-5 rounded-xl border border-white/10 bg-[#0d1424] shadow-2xl">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                {network.PUBLISHER}
              </h1>
              <span className="text-xs px-2.5 py-0.5 rounded font-medium bg-blue-500/10 text-blue-400 border border-blue-500/30">
                {network.BUSINESS_UNIT}
              </span>
              <span className="text-xs px-2.5 py-0.5 rounded font-medium bg-slate-800 text-slate-300">
                {network.REGION}
              </span>
              {network.RECONNECTED_AT ? (
                <span className="text-xs px-2.5 py-0.5 rounded font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  Reconnected: {new Date(network.RECONNECTED_AT).toLocaleDateString()}
                </span>
              ) : (
                <span className="text-xs px-2.5 py-0.5 rounded font-semibold bg-rose-500/15 text-rose-400 border border-rose-500/30">
                  Still Disconnected ({network.daysSinceCut} days)
                </span>
              )}
            </div>

            <p className="text-xs text-slate-400 mt-1.5 max-w-2xl">
              <strong>Root cause summary:</strong> {network.ONE_LINE_REASON}
            </p>
          </div>

          <div className="text-right font-mono-num bg-[#0a0f1d] px-4 py-2.5 rounded-lg border border-white/5">
            <span className="text-[11px] text-slate-400 block font-sans">Pre-Cut Weekly Spend</span>
            <span className="text-2xl font-bold text-white">
              {network.SPEND_7D_BEFORE !== null ? `$${network.SPEND_7D_BEFORE.toLocaleString()}` : 'No data'}
            </span>
            <div className="text-[11px] text-rose-400 font-sans mt-0.5">
              -{network.REVENUE_DROP_PCT}% spend impact
            </div>
          </div>
        </div>

        {/* Internal Owner & Timeline strip */}
        {!isPublisherView && (
          <div className="mt-4 pt-3 border-t border-white/5 flex flex-wrap items-center justify-between text-xs text-slate-400 gap-3">
            <div>
              Account Owner: <strong className="text-white font-mono-num">{network.USERNAME}</strong>
            </div>
            <div>
              Cut Timestamp: <strong className="text-white font-mono-num">{network.CUT_AT}</strong>
            </div>
            <div>
              Amazon Partner: <strong className="text-white">{network.PARTNER_NAME}</strong>
            </div>
          </div>
        )}
      </div>

      {/* Traffic Context & Amazon-Specific Banner */}
      <div className="rounded-xl border border-white/10 bg-[#0d1424] p-5 shadow-2xl space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-blue-400">
                Traffic Context Signal
              </span>
              <span className="text-slate-600">·</span>
              <span className="text-xs text-slate-400">Network Auctions vs Amazon Bid Requests</span>
            </div>
            <h2 className="text-base sm:text-lg font-bold text-white mt-0.5">
              Before vs After Traffic Comparison
            </h2>
          </div>

          {/* Conditional Banner: ONLY if auctions are stable and Amazon bid requests dropped */}
          {ai?.isAmazonSpecificDrop && (
            <div className="px-3 py-1.5 rounded-lg bg-amber-500/10 border border-amber-500/40 text-amber-300 text-xs font-semibold flex items-center gap-1.5 shadow-sm">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>Drop is Amazon-specific (Network auctions stable, Amazon DSP dropped)</span>
            </div>
          )}
        </div>

        {/* Traffic Metrics Comparison Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {trafficMetrics.length > 0 ? (
            trafficMetrics.map((tm, idx) => (
              <div
                key={idx}
                className="p-3.5 rounded-lg border border-white/5 bg-[#0a0f1d] flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-semibold text-white">{tm.metric}</span>
                    <span
                      className={`font-mono-num font-bold px-1.5 py-0.5 rounded text-[11px] ${
                        tm.change_pct < -50
                          ? 'bg-rose-500/15 text-rose-400'
                          : tm.change_pct < 0
                          ? 'bg-amber-500/15 text-amber-400'
                          : 'bg-emerald-500/15 text-emerald-400'
                      }`}
                    >
                      {tm.change_pct > 0 ? `+${tm.change_pct}%` : `${tm.change_pct}%`}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 mb-2">Source: {tm.source}</div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs font-mono-num pt-2 border-t border-white/5">
                  <div>
                    <span className="text-slate-500 block text-[10px] font-sans">Pre-Cut (7d)</span>
                    <span className="text-slate-300 font-semibold">{tm.before.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px] font-sans">Post-Cut (7d)</span>
                    <span className="text-white font-bold">{tm.after.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-2 text-xs text-slate-500 italic p-3 bg-[#0a0f1d] rounded-lg">
              Historical traffic sampling in progress for this network.
            </div>
          )}
        </div>
      </div>

      {/* Before vs After Checks Grid (4 checks × 2 windows) */}
      <div className="rounded-xl border border-white/10 bg-[#0d1424] p-5 shadow-2xl">
        <div className="mb-4">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-blue-400">
              Technical Verification Engine
            </span>
            <span className="text-slate-600">·</span>
            <span className="text-xs text-slate-400">4 Core Checks × 2 Windows</span>
          </div>
          <h2 className="text-base sm:text-lg font-bold text-white mt-0.5">
            Supply Health & DSP Policy Audit Matrix
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Every cell links directly to verifiable raw evidence logs. NO_DATA indicates unknown telemetry, never a pass.
          </p>
        </div>

        <div className="overflow-x-auto rounded-lg border border-white/10">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-900 border-b border-white/10 text-slate-300 font-semibold">
              <tr>
                <th className="py-2.5 px-3 w-1/4">Check Type</th>
                <th className="py-2.5 px-3 text-center w-28">BEFORE Window</th>
                <th className="py-2.5 px-3 text-center w-28">AFTER Window</th>
                <th className="py-2.5 px-3">Evidence Ref & Audit Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 bg-[#0a0f1d]">
              {checkTypes.map(ct => {
                const beforeCell = getCheckCell(ct.type, 'BEFORE');
                const afterCell = getCheckCell(ct.type, 'AFTER');

                return (
                  <tr key={ct.type} className="hover:bg-white/5 transition-colors">
                    <td className="py-3 px-3">
                      <div className="font-semibold text-white">{ct.label}</div>
                      <div className="text-[11px] text-slate-400">{ct.desc}</div>
                    </td>

                    {/* BEFORE Window */}
                    <td className="py-3 px-3 text-center">
                      {renderResultBadge(beforeCell.result)}
                    </td>

                    {/* AFTER Window */}
                    <td className="py-3 px-3 text-center">
                      {renderResultBadge(afterCell.result)}
                    </td>

                    {/* Evidence & Details */}
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2 mb-1">
                        <button
                          onClick={() => setSelectedEvidenceRef(afterCell.evidence_ref)}
                          className="font-mono-num text-[11px] text-blue-400 hover:text-blue-300 hover:underline flex items-center gap-1 font-semibold"
                        >
                          <span>[{afterCell.evidence_ref}]</span>
                          <ExternalLink className="w-3 h-3" />
                        </button>
                      </div>
                      <p className="text-xs text-slate-300">{afterCell.detail}</p>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* AI Investigator Card (Not shown in Publisher View) */}
      {!isPublisherView && ai && (
        <div className="rounded-xl border border-blue-500/30 bg-[#0d1424] p-5 shadow-2xl relative overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400">
                <Brain className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base sm:text-lg font-bold text-white">
                    AI Investigation Assistant
                  </h2>
                  <span className="text-xs px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">
                    Rule-Grounded Synthesis
                  </span>
                </div>
                <p className="text-xs text-slate-400">
                  Hypotheses ranked by confidence · Guardrail: No FAIL check implies low confidence only
                </p>
              </div>
            </div>

            {/* Validation Badges */}
            <div className="flex items-center gap-2 flex-wrap text-[11px]">
              <span className={`px-2 py-0.5 rounded font-mono-num border ${
                ai.validation.passed
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                  : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
              }`}>
                Validation: {ai.validation.passed ? 'PASSED' : 'FAILED'}
              </span>

              <span className={`px-2 py-0.5 rounded font-mono-num border ${
                ai.validation.ai_output_accepted
                  ? 'bg-blue-500/10 text-blue-400 border-blue-500/30'
                  : 'bg-amber-500/10 text-amber-400 border-amber-500/30'
              }`}>
                Output Accepted: {ai.validation.ai_output_accepted ? 'TRUE' : 'FALSE'}
              </span>

              {ai.validation.fallback_fields.length > 0 && (
                <span className="px-2 py-0.5 rounded font-mono-num bg-amber-500/10 text-amber-300 border border-amber-500/30">
                  Fallback: {ai.validation.fallback_fields.join(', ')}
                </span>
              )}
            </div>
          </div>

          {/* Hypotheses Ranked by Confidence */}
          <div className="space-y-3 mb-5">
            <span className="text-xs font-semibold text-slate-400 block uppercase tracking-wider">
              Competing Hypotheses:
            </span>
            {ai.hypotheses.map((hyp, hIdx) => {
              const confColor =
                hyp.displayConfidence === 'HIGH'
                  ? 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                  : hyp.displayConfidence === 'MEDIUM'
                  ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                  : 'bg-blue-500/15 text-blue-300 border-blue-500/30';

              return (
                <div
                  key={hIdx}
                  className="p-3.5 rounded-lg border border-white/5 bg-[#0a0f1d] hover:border-white/10 transition-colors"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-white">
                        #{hIdx + 1}. {hyp.label}
                      </span>
                    </div>

                    <span className={`px-2 py-0.5 rounded text-[10px] font-mono-num font-bold uppercase border ${confColor}`}>
                      Confidence: {hyp.displayConfidence}
                    </span>
                  </div>

                  {/* Evidence Chips with Verification Check */}
                  <div className="flex flex-wrap items-center gap-2 mt-2">
                    <span className="text-[11px] text-slate-500">Evidence:</span>
                    {hyp.verifiedEvidenceRefs.map(ev => (
                      <span
                        key={ev.ref}
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono-num border ${
                          ev.isVerified
                            ? 'bg-blue-900/30 text-blue-300 border-blue-500/30'
                            : 'bg-rose-900/40 text-rose-300 border-rose-500/50 font-bold'
                        }`}
                      >
                        <span>{ev.ref}</span>
                        {!ev.isVerified && (
                          <span className="text-rose-400 bg-rose-500/20 px-1 rounded text-[9px] font-bold">
                            Unverified evidence
                          </span>
                        )}
                      </span>
                    ))}
                  </div>

                  {/* Missing Info List */}
                  {hyp.missing_info.length > 0 && (
                    <div className="mt-2.5 pt-2 border-t border-white/5">
                      <span className="text-[11px] text-amber-400 font-semibold block mb-1">
                        Missing Information:
                      </span>
                      <ul className="list-disc list-inside text-[11px] text-slate-400 space-y-0.5">
                        {hyp.missing_info.map((mi, mIdx) => (
                          <li key={mIdx}>{mi}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Draft Message (Read-Only) with Human Approval Lock */}
          <div className="p-4 rounded-lg border border-amber-500/30 bg-[#0a0f1d] relative">
            <div className="flex items-center justify-between gap-2 mb-2">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <FileCheck className="w-4 h-4 text-blue-400" />
                Draft Publisher Triage Notification (Synthesized)
              </span>

              {/* Strict Lock: Human approval required in Slack */}
              <div className="px-2.5 py-1 rounded-md bg-amber-500/10 border border-amber-500/30 text-amber-300 text-[11px] font-semibold flex items-center gap-1.5 shadow-sm">
                <Lock className="w-3.5 h-3.5 text-amber-400" />
                <span>Requires human approval in Slack</span>
              </div>
            </div>

            <pre className="text-xs text-slate-300 font-sans whitespace-pre-wrap bg-slate-950/80 p-3 rounded border border-white/5 select-text leading-relaxed">
              {ai.draft_message}
            </pre>

            <div className="mt-2 text-[11px] text-slate-500 flex items-center justify-between">
              <span>Read-only preview · No automated dispatch without manual sign-off</span>
              <span className="text-slate-400 font-mono-num">Channel: #equativ-yield-disconnections</span>
            </div>
          </div>
        </div>
      )}

      {/* Amazon Readiness Checklist (OpenRTB signals) */}
      <div className="rounded-xl border border-white/10 bg-[#0d1424] p-5 shadow-2xl">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-blue-400">
                OpenRTB Specification Compliance
              </span>
              <span className="text-slate-600">·</span>
              <span className="text-xs text-slate-400">Amazon DSP Ingestion Requirements</span>
            </div>
            <h2 className="text-base sm:text-lg font-bold text-white mt-0.5">
              Amazon Readiness Checklist
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Inspection of 21 OpenRTB signals required for complete programmatic monetization on Amazon DSP
            </p>
          </div>

          <div className="px-2.5 py-1 rounded bg-blue-500/10 border border-blue-500/20 text-blue-300 text-[11px]">
            {readinessSignals.filter(s => s.present).length} / {readinessSignals.length} Signals Validated
          </div>
        </div>

        {/* Signals Grid Grouped by Category */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {readinessSignals.map(sig => {
            const isContentGroup = sig.category === 'content';

            return (
              <div
                key={sig.signal}
                className="p-3 rounded-lg border border-white/5 bg-[#0a0f1d] flex items-start justify-between gap-2"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono-num text-xs font-bold text-white">
                      {sig.signal}
                    </span>
                    {sig.present ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    ) : (
                      <XCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                    )}
                  </div>

                  <p className="text-[11px] text-slate-400 mt-1">
                    {sig.valueDescription || sig.category}
                  </p>

                  {/* Mandated Tag for content.* group */}
                  {isContentGroup && (
                    <span className="inline-block mt-1.5 px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 border border-white/10 font-sans">
                      Not fully relevant until January 2027
                    </span>
                  )}
                </div>

                <span
                  className={`text-[10px] font-mono-num px-1.5 py-0.5 rounded uppercase font-semibold shrink-0 ${
                    sig.present
                      ? 'bg-emerald-500/15 text-emerald-400'
                      : 'bg-rose-500/15 text-rose-400'
                  }`}
                >
                  {sig.present ? 'Present' : 'Absent'}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
