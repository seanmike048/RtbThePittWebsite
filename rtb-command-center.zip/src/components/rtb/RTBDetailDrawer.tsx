/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { DisconnectionPartnerRecord, RTBViewModel } from '../../lib/adapter/types.ts';
import { X, AlertTriangle, ShieldCheck, Clock, DollarSign, Database, Copy, Check } from 'lucide-react';

interface RTBDetailDrawerProps {
  record: DisconnectionPartnerRecord | null;
  onClose: () => void;
  model: RTBViewModel;
}

export const RTBDetailDrawer: React.FC<RTBDetailDrawerProps> = ({
  record,
  onClose,
  model,
}) => {
  const [copied, setCopied] = React.useState(false);

  if (!record) return null;

  const rawJson = JSON.stringify(record, null, 2);

  const handleCopy = () => {
    navigator.clipboard.writeText(rawJson);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-xl h-full bg-[#0d1424] border-l border-white/10 p-6 flex flex-col justify-between overflow-y-auto shadow-2xl">
        <div className="space-y-5">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-blue-400">
                  Seat Diagnostic Drawer
                </span>
                <span className="text-slate-600">·</span>
                <span className="text-[11px] text-slate-400 font-mono-num">
                  ID #{record.partnerId}
                </span>
              </div>
              <h2 className="text-lg font-bold text-white mt-0.5">
                {record.partnerName}
              </h2>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg border border-white/10 text-slate-400 hover:text-white hover:border-white/20 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Connection Status & Timestamps */}
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 bg-slate-900 rounded-lg border border-white/5">
              <span className="text-slate-400 text-[11px] block mb-1">Connection Status</span>
              <span className="px-2 py-0.5 rounded font-bold uppercase text-[11px] bg-rose-500/15 text-rose-400 border border-rose-500/30 inline-block">
                {record.status === 'still_disconnected' ? 'Still Disconnected' : 'Reconnected'}
              </span>
            </div>

            <div className="p-3 bg-slate-900 rounded-lg border border-white/5">
              <span className="text-slate-400 text-[11px] block mb-1">Disconnection Timestamp</span>
              <span className="font-mono-num font-semibold text-white">
                {record.disconnectionTimestamp}
              </span>
              <span className="text-[10px] text-slate-500 block mt-0.5">
                Preserves source timezone ({model.metadata.timezone})
              </span>
            </div>
          </div>

          {/* Revenue Context (No currency symbol) */}
          <div className="p-4 bg-slate-900 rounded-lg border border-white/5 space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-300">
                Historical 7d Run-Rate Before Disconnection
              </span>
              <span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 text-[10px] font-medium border border-amber-500/30">
                Currency not provided
              </span>
            </div>

            <div className="text-2xl font-bold font-mono-num text-white">
              {record.spend7dBefore.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>

            <p className="text-[11px] text-slate-400">
              Note: Do not label historical revenue as lost revenue, projected loss, or recoverable revenue. The value is preserved directly from the source alert view.
            </p>
          </div>

          {/* Reason Diagnosis & Availability */}
          <div className="p-4 bg-slate-900 rounded-lg border border-white/5 space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-300">Disconnection Reason Context</span>
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-medium border ${
                  record.reasonType === 'confirmed'
                    ? 'bg-blue-500/10 text-blue-400 border-blue-500/20'
                    : record.reasonType === 'hypothesis'
                    ? 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                    : 'bg-slate-800 text-slate-400 border-white/10'
                }`}
              >
                {record.reasonType === 'confirmed'
                  ? 'Confirmed Reason'
                  : record.reasonType === 'hypothesis'
                  ? 'Hypothesis Only'
                  : 'Not Provided in Alert'}
              </span>
            </div>

            <p className="text-slate-200 italic">
              {record.reason ? `"${record.reason}"` : 'No specific reason string provided in alert row.'}
            </p>

            <span className="text-[11px] text-slate-500 block">
              Guardrail: Root cause reason is only displayed when verified by checks. Hypotheses are never labeled as confirmed causes.
            </span>
          </div>

          {/* Data Quality Notes */}
          <div className="p-4 bg-slate-900 rounded-lg border border-white/5 space-y-2 text-xs">
            <span className="font-semibold text-slate-400 uppercase tracking-wider block text-[11px]">
              Data Quality & Source Telemetry Notes
            </span>
            <ul className="list-disc list-inside space-y-1 text-slate-300 text-[11px]">
              {record.dataQualityNotes.map((note, idx) => (
                <li key={idx}>{note}</li>
              ))}
              <li>Owner Context: {record.ownerContext}</li>
              <li>Publisher: {model.overview.publisherName} (#{model.overview.publisherId})</li>
            </ul>
          </div>

          {/* Raw Source Record JSON */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-400 uppercase tracking-wider text-[11px]">
                Raw Record JSON
              </span>
              <button
                onClick={handleCopy}
                className="px-2 py-1 rounded bg-slate-800 text-slate-300 hover:text-white flex items-center gap-1 text-[11px]"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'Copied' : 'Copy Record'}</span>
              </button>
            </div>
            <pre className="p-3 bg-slate-950 rounded-lg border border-white/5 text-[11px] font-mono-num text-blue-300 overflow-x-auto max-h-48">
              {rawJson}
            </pre>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-white/10 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white rounded-lg transition-colors"
          >
            Close Drawer
          </button>
        </div>
      </div>
    </div>
  );
};
