/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { RTBViewModel } from '../../lib/adapter/types.ts';
import {
  CheckCircle2,
  XCircle,
  HelpCircle,
  AlertTriangle,
  Layers,
  Radio,
  Shield,
  BarChart2,
  Info,
} from 'lucide-react';

interface RTBAmazonDspViewsProps {
  model: RTBViewModel;
}

export const RTBAmazonDspViews: React.FC<RTBAmazonDspViewsProps> = ({ model }) => {
  const [subTab, setSubTab] = useState<'partners' | 'signals' | 'checklist'>('partners');

  // Amazon partner mapping definition
  const KNOWN_AMAZON_PARTNERS: Record<number, { name: string; region: string; description: string }> = {
    437: { name: 'Amazon DSP US', region: 'Americas', description: 'Primary North American bidding endpoint' },
    489: { name: 'Amazon DSP EMEA', region: 'EMEA', description: 'European regional buying gateway' },
    490: { name: 'Amazon DSP UK', region: 'EMEA', description: 'UK regional market seat' },
    491: { name: 'Amazon DSP APAC', region: 'APAC', description: 'Asia-Pacific regional buying gateway' },
    492: { name: 'Amazon DSP Global CTV', region: 'Global', description: 'Connected TV dedicated buying endpoint' },
  };

  const presentPartnerIds = model.overview.distinctPartnerIds;

  return (
    <div className="rounded-xl border border-white/10 bg-[#0d1424] p-5 shadow-2xl space-y-5">
      {/* Header & Sub-tabs */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-blue-400">
              Demand Infrastructure
            </span>
            <span className="text-slate-600">·</span>
            <span className="text-xs text-slate-400">Amazon DSP Analysis Views</span>
          </div>
          <h2 className="text-base sm:text-lg font-bold text-white tracking-tight mt-0.5">
            Partner Performance & Signal Diagnostics
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Analyzes partner seat performance, OpenRTB signals, and compliance benchmarks without fabricating missing telemetry
          </p>
        </div>

        {/* Sub-tab pills */}
        <div className="flex items-center bg-slate-900 border border-white/10 rounded-lg p-1 text-xs">
          <button
            onClick={() => setSubTab('partners')}
            className={`px-3 py-1 rounded-md transition-colors ${
              subTab === 'partners'
                ? 'bg-blue-600 text-white font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Partner Seat Mapping
          </button>
          <button
            onClick={() => setSubTab('signals')}
            className={`px-3 py-1 rounded-md transition-colors ${
              subTab === 'signals'
                ? 'bg-blue-600 text-white font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Signal Associations
          </button>
          <button
            onClick={() => setSubTab('checklist')}
            className={`px-3 py-1 rounded-md transition-colors ${
              subTab === 'checklist'
                ? 'bg-blue-600 text-white font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Checklist & Benchmarks
          </button>
        </div>
      </div>

      {/* Sub-tab 1: Partner & Publisher Performance */}
      {subTab === 'partners' && (
        <div className="space-y-4">
          <div className="p-3 bg-[#0a0f1d] rounded-lg border border-white/5 text-xs text-slate-400">
            <strong>Rule:</strong> Support validated Amazon partner mappings (437, 489, 490, 491, 492) when present in imported payloads. Absent partners are marked unrepresented rather than inventing records.
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Present Partners */}
            <div className="space-y-3">
              <span className="text-xs font-semibold text-white uppercase tracking-wider block">
                Active / Present in Imported Payload ({presentPartnerIds.length})
              </span>

              {presentPartnerIds.map(id => {
                const partnerInfo = KNOWN_AMAZON_PARTNERS[id] || {
                  name: `Amazon DSP Partner (${id})`,
                  region: 'Unknown',
                  description: 'Validated partner seat',
                };
                const record = model.disconnections.find(d => d.partnerId === id);

                return (
                  <div
                    key={id}
                    className="p-4 rounded-lg bg-slate-900 border border-blue-500/30 space-y-2 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Radio className="w-4 h-4 text-blue-400" />
                        <strong className="text-white text-sm">{partnerInfo.name}</strong>
                      </div>
                      <span className="font-mono-num px-2 py-0.5 rounded bg-blue-500/10 text-blue-300 border border-blue-500/20 text-[11px]">
                        Seat #{id}
                      </span>
                    </div>

                    <p className="text-slate-400 text-[11px]">{partnerInfo.description}</p>

                    <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/5 font-mono-num text-[11px]">
                      <div>
                        <span className="text-slate-500 block font-sans text-[10px]">Pre-Cut 7d Spend</span>
                        <span className="text-white font-bold">
                          {record?.spend7dBefore.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          <span className="font-sans text-amber-400 ml-1 text-[10px]">[No Currency]</span>
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 block font-sans text-[10px]">Status</span>
                        <span className="text-rose-400 font-semibold font-sans">Still Disconnected</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Absent Partners (Supported but not in this payload) */}
            <div className="space-y-3">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
                Unrepresented Partner Seats (In Supported Schema)
              </span>

              {([490, 491, 492] as number[]).map(id => {
                const partnerInfo = KNOWN_AMAZON_PARTNERS[id];
                return (
                  <div
                    key={id}
                    className="p-3.5 rounded-lg bg-[#0a0f1d] border border-white/5 text-xs space-y-1 opacity-70"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-slate-300">{partnerInfo.name}</span>
                      <span className="font-mono-num text-[10px] text-slate-500">Seat #{id} ({partnerInfo.region})</span>
                    </div>
                    <p className="text-[11px] text-slate-500 italic">
                      Not present in current queried alert view. No fabricated records created.
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Sub-tab 2: Signal Associations */}
      {subTab === 'signals' && (
        <div className="space-y-4 text-xs">
          <div className="p-3 bg-[#0a0f1d] rounded-lg border border-white/5 text-slate-300 space-y-1 leading-relaxed">
            <strong className="text-blue-400 block">Signal Analysis Safeguards:</strong>
            <ul className="list-disc list-inside text-slate-400 space-y-0.5">
              <li>Separates observed associations from documented policy requirements.</li>
              <li>Treats <strong>IPv6</strong> and <strong>truncated IP</strong> as acceptable analysis categories, NOT automatic failures.</li>
              <li>Does NOT treat nonconsented traffic as an automatic failure.</li>
              <li>Keeps IP-version and truncation attributes separate because they can overlap.</li>
              <li>Never claims official Amazon DSP approval or rejection.</li>
            </ul>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="p-3.5 rounded-lg bg-slate-900 border border-white/5 space-y-2">
              <div className="flex items-center justify-between">
                <strong className="text-white">IP Version (IPv4 vs IPv6)</strong>
                <span className="px-2 py-0.5 rounded bg-blue-500/10 text-blue-300 text-[10px]">
                  Observed Category
                </span>
              </div>
              <p className="text-slate-400 text-[11px]">
                IPv6 traffic is an acceptable transmission protocol. It is monitored as a traffic category and not flagged as an inherent technical defect.
              </p>
              <div className="text-[11px] text-slate-500 italic">
                Status: Not available in current raw alert view
              </div>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-900 border border-white/5 space-y-2">
              <div className="flex items-center justify-between">
                <strong className="text-white">IP Truncation / Privacy Masking</strong>
                <span className="px-2 py-0.5 rounded bg-blue-500/10 text-blue-300 text-[10px]">
                  Independent Attribute
                </span>
              </div>
              <p className="text-slate-400 text-[11px]">
                Kept separate from IP version because IPv4 and IPv6 can both be subject to client truncation or subnet masking.
              </p>
              <div className="text-[11px] text-slate-500 italic">
                Status: Not available in current raw alert view
              </div>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-900 border border-white/5 space-y-2">
              <div className="flex items-center justify-between">
                <strong className="text-white">Consent Signals (GDPR / CCPA / GPP)</strong>
                <span className="px-2 py-0.5 rounded bg-blue-500/10 text-blue-300 text-[10px]">
                  Policy Framework
                </span>
              </div>
              <p className="text-slate-400 text-[11px]">
                Nonconsented impressions are analyzed under context-aware rules and not treated as an automatic failure in diagnostic scoring.
              </p>
              <div className="text-[11px] text-slate-500 italic">
                Status: Not available in current raw alert view
              </div>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-900 border border-white/5 space-y-2">
              <div className="flex items-center justify-between">
                <strong className="text-white">ads.txt Root Declaration</strong>
                <span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 text-[10px]">
                  Unconfirmed Hypothesis
                </span>
              </div>
              <p className="text-slate-400 text-[11px]">
                Cited in the workflow hypothesis string: "The pattern may be related to ads.txt compliance." Unconfirmed by backend evidence in raw input.
              </p>
              <div className="text-[11px] text-amber-400/90 font-medium">
                Status: Unverified working hypothesis
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Sub-tab 3: Checklist & Benchmarks */}
      {subTab === 'checklist' && (
        <div className="space-y-4 text-xs">
          {/* Important Benchmark Disclaimer */}
          <div className="p-3 bg-amber-950/30 border border-amber-500/30 rounded-lg text-amber-300 text-[11px] flex items-start gap-2">
            <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <strong>Benchmark Scope Notice:</strong> Regional RPMBR benchmarks (Americas $50, EMEA $25, APAC $10) are internal comparison benchmarks utilized for triage prioritization, NOT official Amazon thresholds or SLA guarantees.
            </div>
          </div>

          <div className="overflow-x-auto rounded-lg border border-white/10">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-900 border-b border-white/10 text-slate-400 font-semibold">
                <tr>
                  <th className="py-2.5 px-3">Signal / Attribute</th>
                  <th className="py-2.5 px-3">Classification Category</th>
                  <th className="py-2.5 px-3">Availability Status</th>
                  <th className="py-2.5 px-3">Diagnostic Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 bg-[#0a0f1d] text-slate-300">
                {model.amazonDspAnalytics.signalChecklist.map((item, idx) => (
                  <tr key={idx} className="hover:bg-white/5">
                    <td className="py-2.5 px-3 font-semibold text-white">
                      {item.signal}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-medium border ${
                        item.category === 'Policy Requirement'
                          ? 'bg-rose-500/10 text-rose-300 border-rose-500/20'
                          : item.category === 'Internal Benchmark'
                          ? 'bg-amber-500/10 text-amber-300 border-amber-500/20'
                          : 'bg-blue-500/10 text-blue-300 border-blue-500/20'
                      }`}>
                        {item.category}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 font-mono-num text-[11px]">
                      {item.status === 'NOT_AVAILABLE_IN_QUERY' ? (
                        <span className="text-slate-500 italic">Not available in queried data</span>
                      ) : (
                        <span className="text-emerald-400">Observed acceptable</span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-slate-400 text-[11px]">
                      {item.notes}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
