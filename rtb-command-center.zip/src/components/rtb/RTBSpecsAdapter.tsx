/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  FileCode,
  Shield,
  Layers,
  CheckCircle2,
  AlertTriangle,
  Copy,
  Check,
  Cpu,
  BookOpen,
  ArrowRight,
  ExternalLink,
} from 'lucide-react';
import { SAMPLE_FINALIZED_REPORT, RAW_SAMPLE_WORKFLOW_INPUT } from '../../lib/adapter/sampleData.ts';

export const RTBSpecsAdapter: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'adapter' | 'boundaries' | 'n8n' | 'schema'>('adapter');
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  const handleCopy = (text: string, sectionId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(sectionId);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const schemaExample = JSON.stringify(SAMPLE_FINALIZED_REPORT, null, 2);

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* 1. Header Banner */}
      <div className="rounded-xl border border-white/10 bg-[#0d1424] p-5 sm:p-6 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-blue-400">
              Technical Documentation
            </span>
            <span className="text-slate-600">·</span>
            <span className="text-[11px] text-slate-400">Adapter & Behavioral Contracts</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            RTB Workflow Report Adapter Specification
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-3xl leading-relaxed">
            Preserving strict backend decision boundaries between deterministic logic, generative language models, and automated output truth validation.
          </p>
        </div>

        {/* Sub-nav pills */}
        <div className="flex items-center bg-slate-900 border border-white/10 rounded-lg p-1 text-xs shrink-0 self-start md:self-auto">
          <button
            onClick={() => setActiveSubTab('adapter')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
              activeSubTab === 'adapter'
                ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Adapter Contract
          </button>
          <button
            onClick={() => setActiveSubTab('boundaries')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
              activeSubTab === 'boundaries'
                ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Decision Boundaries
          </button>
          <button
            onClick={() => setActiveSubTab('n8n')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
              activeSubTab === 'n8n'
                ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            n8n Pipeline Setup
          </button>
          <button
            onClick={() => setActiveSubTab('schema')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
              activeSubTab === 'schema'
                ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            JSON Schema Reference
          </button>
        </div>
      </div>

      {/* 2. Sub-tab: Adapter Contract */}
      {activeSubTab === 'adapter' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="rounded-xl border border-blue-500/30 bg-blue-500/5 p-4 space-y-2">
              <div className="flex items-center gap-2 text-blue-400 font-semibold text-xs uppercase tracking-wider">
                <Cpu className="w-4 h-4" />
                <span>Boundary A: Deterministic</span>
              </div>
              <h3 className="text-sm font-bold text-white">Rule-Engine Derivations</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Derives priority (<code className="text-blue-300 font-mono-num">P0..P4, P?</code>), confidence score, confirmed factual statements, up to 3 selected evidence items, explicit unknowns, and primary owner action.
              </p>
            </div>

            <div className="rounded-xl border border-purple-500/30 bg-purple-500/5 p-4 space-y-2">
              <div className="flex items-center gap-2 text-purple-400 font-semibold text-xs uppercase tracking-wider">
                <FileCode className="w-4 h-4" />
                <span>Boundary B: Gemini</span>
              </div>
              <h3 className="text-sm font-bold text-white">Language Synthesis</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Synthesizes human-friendly <code className="text-purple-300">finding</code>, <code className="text-purple-300">client_message</code>, and <code className="text-purple-300">owner_actions</code> strictly constrained to the facts established by Boundary A.
              </p>
            </div>

            <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-4 space-y-2">
              <div className="flex items-center gap-2 text-emerald-400 font-semibold text-xs uppercase tracking-wider">
                <Shield className="w-4 h-4" />
                <span>Boundary C: Validation</span>
              </div>
              <h3 className="text-sm font-bold text-white">Truth Enforcement</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Verifies Gemini text contains no ungrounded claims. If hallucinated or discordant with source telemetry, substitutes deterministic fallbacks and verifies Slack text stays under 200 words.
              </p>
            </div>
          </div>

          <div className="rounded-xl border border-white/10 bg-[#0d1424] p-5 shadow-2xl space-y-4">
            <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-blue-400" />
              Documented Adapter Ingestion Protocol
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed">
              The frontend adapter in <code className="text-blue-400 font-mono-num">src/lib/adapter/parser.ts</code> accepts both raw workflow input payloads and finalized executed reports, adhering to these rules:
            </p>

            <div className="space-y-3 text-xs">
              <div className="p-3.5 bg-slate-900 rounded-lg border border-white/5 space-y-1">
                <span className="font-bold text-white flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  1. Explicit Priority & Confidence Requirement
                </span>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  If the input payload does not contain an executed <code className="text-white font-mono-num">deterministic.priority</code> and <code className="text-white font-mono-num">deterministic.confidence</code>, the frontend displays them as <code className="text-amber-300 font-mono-num">UNAVAILABLE</code>. It never invents, guesses, or infers priority on the client.
                </p>
              </div>

              <div className="p-3.5 bg-slate-900 rounded-lg border border-white/5 space-y-1">
                <span className="font-bold text-white flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  2. Currency Guardrail on Revenue Summation
                </span>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  When source alerts provide numerical spend without a valid currency identifier (e.g. <code className="text-white font-mono-num">currency: null</code>), the frontend displays individual seat amounts as reported with an explicit caveat and suppresses total summation to prevent fraudulent or multi-currency aggregation errors.
                </p>
              </div>

              <div className="p-3.5 bg-slate-900 rounded-lg border border-white/5 space-y-1">
                <span className="font-bold text-white flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  3. Hypothesis Demarcation
                </span>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  Unvalidated input statements (such as <code className="text-white font-mono-num">&quot;The pattern may be related to ads.txt compliance&quot;</code>) are quarantined as <em>unconfirmed hypotheses</em>. They are never displayed as verified root causes or used to alter priority.
                </p>
              </div>

              <div className="p-3.5 bg-slate-900 rounded-lg border border-white/5 space-y-1">
                <span className="font-bold text-white flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  4. Distinct Window Coverage Preservation
                </span>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  When traffic metric comparison periods differ from the module reporting window, the discrepancy is highlighted in the operational metadata strip and never silently forced to match.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3. Sub-tab: Decision Boundaries */}
      {activeSubTab === 'boundaries' && (
        <div className="rounded-xl border border-white/10 bg-[#0d1424] p-5 shadow-2xl space-y-4">
          <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
            <Shield className="w-4 h-4 text-emerald-400" />
            Decision Boundary Invariants
          </h2>
          <p className="text-xs text-slate-400">
            TechOps workflows demand audit-grade traceability. The dashboard strictly maintains the following invariants:
          </p>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-white/10 rounded-lg overflow-hidden">
              <thead className="bg-slate-900 text-slate-400 font-semibold border-b border-white/10">
                <tr>
                  <th className="p-3">Field / Entity</th>
                  <th className="p-3">Boundary Authority</th>
                  <th className="p-3">Frontend Rule</th>
                  <th className="p-3">Prohibited Behavior</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-sans text-slate-300">
                <tr className="hover:bg-white/5">
                  <td className="p-3 font-semibold text-white">Priority (P0..P4, P?)</td>
                  <td className="p-3 text-blue-400">Boundary A (Deterministic)</td>
                  <td className="p-3">Render exactly as provided</td>
                  <td className="p-3 text-rose-400 font-medium">Never recalculate or score</td>
                </tr>
                <tr className="hover:bg-white/5">
                  <td className="p-3 font-semibold text-white">Confidence (HIGH..UNKNOWN)</td>
                  <td className="p-3 text-blue-400">Boundary A (Deterministic)</td>
                  <td className="p-3">Render exactly as provided</td>
                  <td className="p-3 text-rose-400 font-medium">Never infer from hypotheses</td>
                </tr>
                <tr className="hover:bg-white/5">
                  <td className="p-3 font-semibold text-white">Confirmed Facts</td>
                  <td className="p-3 text-blue-400">Boundary A (Deterministic)</td>
                  <td className="p-3">Numbered bullet list</td>
                  <td className="p-3 text-rose-400 font-medium">Never mix with hypotheses</td>
                </tr>
                <tr className="hover:bg-white/5">
                  <td className="p-3 font-semibold text-white">Root Cause Reason</td>
                  <td className="p-3 text-blue-400">Boundary A / Source Evidence</td>
                  <td className="p-3">Display only if verified by checks</td>
                  <td className="p-3 text-rose-400 font-medium">Never claim ads.txt without proof</td>
                </tr>
                <tr className="hover:bg-white/5">
                  <td className="p-3 font-semibold text-white">Findings & Narratives</td>
                  <td className="p-3 text-purple-400">Boundary B (Gemini 2.5)</td>
                  <td className="p-3">Must pass Boundary C truth check</td>
                  <td className="p-3 text-rose-400 font-medium">Never bypass validation issues</td>
                </tr>
                <tr className="hover:bg-white/5">
                  <td className="p-3 font-semibold text-white">Slack Communication</td>
                  <td className="p-3 text-emerald-400">Boundary C (Assembly)</td>
                  <td className="p-3">Enforce ≤ 200 word ceiling</td>
                  <td className="p-3 text-rose-400 font-medium">Never send unverified draft</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 4. Sub-tab: n8n Pipeline Setup */}
      {activeSubTab === 'n8n' && (
        <div className="rounded-xl border border-white/10 bg-[#0d1424] p-5 shadow-2xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                <Cpu className="w-4 h-4 text-blue-400" />
                n8n Workflow Integration Guide
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Connecting workflow: <strong>[TechOps] RTB-Checklist-Output-Generation</strong>
              </p>
            </div>

            <div className="p-2 rounded bg-amber-500/10 border border-amber-500/30 text-[11px] text-amber-300 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>Pipeline Definition Rejection Guardrail Active</span>
            </div>
          </div>

          <div className="space-y-3 text-xs text-slate-300">
            <div className="p-4 bg-slate-900 rounded-lg border border-white/5 space-y-2">
              <h3 className="font-semibold text-white">How to export executed reports from n8n:</h3>
              <ol className="list-decimal pl-5 space-y-1.5 text-slate-400 text-[11px]">
                <li>
                  Open your n8n canvas: <code className="text-white">[TechOps] RTB-Checklist-Output-Generation</code>.
                </li>
                <li>
                  Execute the workflow with test or real Snowflake webhook events.
                </li>
                <li>
                  Click on the final node (e.g. <strong>Format RTB Command Center Report</strong> or <strong>Validate & Assemble Output</strong>).
                </li>
                <li>
                  In the right drawer, select the <strong>JSON</strong> tab in the node output pane.
                </li>
                <li>
                  Copy the single JSON object and paste it directly into the <strong>Import Data</strong> dialog in RTB Command Center.
                </li>
              </ol>
            </div>

            <div className="p-4 bg-rose-950/20 rounded-lg border border-rose-500/30 space-y-1">
              <span className="font-semibold text-rose-300 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                Why n8n workflow pipeline definitions are rejected:
              </span>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                When users paste raw n8n workflow JSON containing <code className="text-white">&quot;nodes&quot;</code> and <code className="text-white">&quot;connections&quot;</code>, the adapter recognizes this as workflow source code rather than an executed report. An informative warning is displayed guiding the user to copy the executed node output instead of the canvas blueprint.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* 5. Sub-tab: JSON Schema Reference */}
      {activeSubTab === 'schema' && (
        <div className="rounded-xl border border-white/10 bg-[#0d1424] p-5 shadow-2xl space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                <FileCode className="w-4 h-4 text-purple-400" />
                Finalized Executed Report Schema Example
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Full schema compliant with Boundaries A, B, and C
              </p>
            </div>

            <button
              onClick={() => handleCopy(schemaExample, 'schema_example')}
              className="px-3 py-1.5 rounded-lg border border-white/10 bg-slate-900 text-xs text-slate-300 hover:text-white flex items-center gap-1.5"
            >
              {copiedSection === 'schema_example' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Copied Schema</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy JSON Schema</span>
                </>
              )}
            </button>
          </div>

          <pre className="p-4 bg-slate-950 rounded-lg border border-white/10 text-slate-300 font-mono text-[11px] leading-relaxed overflow-x-auto max-h-[500px]">
            {schemaExample}
          </pre>
        </div>
      )}
    </div>
  );
};
