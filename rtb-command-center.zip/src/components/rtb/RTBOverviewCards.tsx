/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { RTBViewModel, PRIORITY_LABELS, PRIORITY_COLORS } from '../../lib/adapter/types.ts';
import {
  AlertTriangle,
  Building,
  Radio,
  TrendingDown,
  DollarSign,
  Info,
  ShieldCheck,
  ShieldAlert,
  HelpCircle,
  Clock,
} from 'lucide-react';

interface RTBOverviewCardsProps {
  model: RTBViewModel;
}

export const RTBOverviewCards: React.FC<RTBOverviewCardsProps> = ({ model }) => {
  const [activeTooltip, setActiveTooltip] = useState<string | null>(null);

  const { overview } = model;
  const priorityColor = PRIORITY_COLORS[overview.priority] || PRIORITY_COLORS.UNAVAILABLE;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
      {/* 1. Priority & Confidence Card */}
      <div
        className="relative p-4 rounded-xl border border-white/10 bg-[#0d1424] shadow-lg flex flex-col justify-between"
        onMouseEnter={() => setActiveTooltip('priority')}
        onMouseLeave={() => setActiveTooltip(null)}
      >
        <div>
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
            <span className="font-semibold uppercase tracking-wider text-[11px] text-slate-400">
              Workflow Priority & Confidence
            </span>
            <button
              type="button"
              className="text-slate-500 hover:text-slate-300"
              aria-label="Priority definition"
              onClick={() => setActiveTooltip(activeTooltip === 'priority' ? null : 'priority')}
            >
              <Info className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="mt-1">
            <span
              className={`inline-block px-2.5 py-1 rounded text-sm font-bold font-mono-num border ${priorityColor.bg} ${priorityColor.text} ${priorityColor.border}`}
            >
              {PRIORITY_LABELS[overview.priority]}
            </span>
          </div>

          <div className="mt-2 text-xs text-slate-300 flex items-center gap-1.5">
            <span className="text-slate-500">Confidence:</span>
            {overview.confidence === 'UNAVAILABLE' ? (
              <span className="text-slate-400 italic">Awaiting execution</span>
            ) : (
              <span className="font-semibold text-white font-mono-num">
                {overview.confidence}
              </span>
            )}
          </div>
        </div>

        <div className="mt-2 pt-2 border-t border-white/5 text-[11px] text-slate-500">
          Source: {overview.prioritySource === 'explicit_backend' ? 'Validated report output' : 'Not in raw sample input'}
        </div>

        {/* Tooltip */}
        {activeTooltip === 'priority' && (
          <div className="absolute z-50 bottom-full left-0 right-0 mb-2 p-3 bg-slate-900 border border-white/20 rounded-md text-xs text-slate-300 shadow-xl">
            <p className="font-semibold text-white mb-1">Backend Priority & Confidence Boundary</p>
            <p className="text-[11px] leading-relaxed">
              Priority (P0–P4, P?) and confidence (HIGH/MED/LOW/UNKNOWN) are determined exclusively by deterministic backend derivation nodes in executed reports. The frontend never recalculates, predicts, or overrides backend classifications.
            </p>
          </div>
        )}
      </div>

      {/* 2. Publisher & Partner Seats Card */}
      <div
        className="relative p-4 rounded-xl border border-white/10 bg-[#0d1424] shadow-lg flex flex-col justify-between"
        onMouseEnter={() => setActiveTooltip('partners')}
        onMouseLeave={() => setActiveTooltip(null)}
      >
        <div>
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
            <span className="font-semibold uppercase tracking-wider text-[11px] text-slate-400">
              Publisher & Partner Seats
            </span>
            <button
              type="button"
              className="text-slate-500 hover:text-slate-300"
              aria-label="Counting rules"
              onClick={() => setActiveTooltip(activeTooltip === 'partners' ? null : 'partners')}
            >
              <Info className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="text-base font-bold text-white tracking-tight truncate">
            {overview.publisherName}
          </div>
          <div className="text-xs font-mono-num text-slate-400 mt-0.5">
            Network ID: #{overview.publisherId}
          </div>

          <div className="mt-2 text-xs text-blue-400 font-medium flex items-center gap-1.5">
            <Radio className="w-3.5 h-3.5 text-blue-400 shrink-0" />
            <span>Seats: {overview.distinctPartnerIds.map(id => `#${id}`).join(', ')}</span>
          </div>
        </div>

        <div className="mt-2 pt-2 border-t border-white/5 text-[11px] text-slate-400 leading-relaxed">
          {overview.partnerSeatsNote}
        </div>

        {/* Tooltip */}
        {activeTooltip === 'partners' && (
          <div className="absolute z-50 bottom-full left-0 right-0 mb-2 p-3 bg-slate-900 border border-white/20 rounded-md text-xs text-slate-300 shadow-xl">
            <p className="font-semibold text-white mb-1">Partner Counting Rules</p>
            <p className="text-[11px] leading-relaxed">
              Counting rules: Distinct partner IDs (437 and 489) represent separate buying seats under Amazon DSP (US and EMEA), NOT two distinct DSP companies.
            </p>
          </div>
        )}
      </div>

      {/* 3. Bid-Request Volume & Change Card */}
      <div
        className="relative p-4 rounded-xl border border-white/10 bg-[#0d1424] shadow-lg flex flex-col justify-between"
        onMouseEnter={() => setActiveTooltip('traffic')}
        onMouseLeave={() => setActiveTooltip(null)}
      >
        <div>
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
            <span className="font-semibold uppercase tracking-wider text-[11px] text-slate-400">
              Reported Bid-Request Change
            </span>
            <button
              type="button"
              className="text-slate-500 hover:text-slate-300"
              aria-label="Traffic metrics explanation"
              onClick={() => setActiveTooltip(activeTooltip === 'traffic' ? null : 'traffic')}
            >
              <Info className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono-num text-rose-400">
              {overview.reportedChangePct > 0 ? `+${overview.reportedChangePct}%` : `${overview.reportedChangePct}%`}
            </span>
            <span className="text-xs text-slate-400">change</span>
          </div>

          <div className="mt-1 text-xs font-mono-num text-slate-300 flex items-center justify-between">
            <span>Before: {(overview.bidRequestsBefore / 1_000_000).toFixed(2)}M</span>
            <span>After: {(overview.bidRequestsAfter / 1_000).toFixed(1)}K</span>
          </div>
        </div>

        <div className="mt-2 pt-2 border-t border-white/5 text-[11px] text-slate-500 truncate" title={model.metadata.metricPeriod}>
          Period: {model.metadata.metricPeriod}
        </div>

        {/* Tooltip */}
        {activeTooltip === 'traffic' && (
          <div className="absolute z-50 bottom-full left-0 right-0 mb-2 p-3 bg-slate-900 border border-white/20 rounded-md text-xs text-slate-300 shadow-xl">
            <p className="font-semibold text-white mb-1">Bid Request Drop Telemetry</p>
            <p className="text-[11px] leading-relaxed">
              Calculated across 7-day pre-cut vs post-cut baseline: 12,400,000 requests reduced to 297,600 requests (-97.6%).
            </p>
          </div>
        )}
      </div>

      {/* 4. Pre-Cut 7-Day Revenue Card (NO SUMMING ACROSS NULL CURRENCY) */}
      <div
        className="relative p-4 rounded-xl border border-white/10 bg-[#0d1424] shadow-lg flex flex-col justify-between"
        onMouseEnter={() => setActiveTooltip('revenue')}
        onMouseLeave={() => setActiveTooltip(null)}
      >
        <div>
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
            <span className="font-semibold uppercase tracking-wider text-[11px] text-slate-400">
              Historical 7d Pre-Cut Spend
            </span>
            <button
              type="button"
              className="text-slate-500 hover:text-slate-300"
              aria-label="Revenue reporting rules"
              onClick={() => setActiveTooltip(activeTooltip === 'revenue' ? null : 'revenue')}
            >
              <Info className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-1 font-mono-num text-xs">
            {overview.revenuePrior7dDays.map(rev => (
              <div key={rev.partnerId} className="flex items-center justify-between">
                <span className="text-slate-400 font-sans truncate pr-2">
                  Seat #{rev.partnerId}:
                </span>
                <span className="font-bold text-white">
                  {rev.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  <span className="text-[10px] text-amber-400 font-sans ml-1 font-normal">
                    [No Currency]
                  </span>
                </span>
              </div>
            ))}
          </div>

          <div className="mt-1 text-[11px] text-amber-300/90 font-medium">
            Currency not provided
          </div>
        </div>

        <div className="mt-2 pt-2 border-t border-white/5 text-[11px] text-slate-500 truncate" title="Historical run-rate only. Not lost or recoverable revenue.">
          Historical 7d spend before cut. Not lost revenue.
        </div>

        {/* Tooltip */}
        {activeTooltip === 'revenue' && (
          <div className="absolute z-50 bottom-full left-0 right-0 mb-2 p-3 bg-slate-900 border border-white/20 rounded-md text-xs text-slate-300 shadow-xl">
            <p className="font-semibold text-white mb-1">Revenue Data Contract Guardrail</p>
            <p className="text-[11px] leading-relaxed">
              Do not label historical revenue as lost revenue, projected loss, or recoverable revenue. Because currency was not supplied in the source data, amounts are displayed as raw figures and must not be aggregated across unverified denominations.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
