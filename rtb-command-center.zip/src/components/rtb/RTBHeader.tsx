/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { RTBViewModel } from '../../lib/adapter/types.ts';
import {
  Activity,
  Upload,
  RotateCcw,
  Code,
  FileText,
  AlertTriangle,
  Clock,
  Globe,
  CheckCircle2,
  Database,
  Layers,
  Sparkles,
} from 'lucide-react';

interface RTBHeaderProps {
  model: RTBViewModel;
  activeTab: 'overview' | 'disconnections' | 'signals' | 'validation' | 'specs';
  onTabChange: (tab: 'overview' | 'disconnections' | 'signals' | 'validation' | 'specs') => void;
  onOpenImport: () => void;
  onOpenSourceViewer: () => void;
  onLoadSampleInput: () => void;
  onLoadFinalizedDemo: () => void;
}

export const RTBHeader: React.FC<RTBHeaderProps> = ({
  model,
  activeTab,
  onTabChange,
  onOpenImport,
  onOpenSourceViewer,
  onLoadSampleInput,
  onLoadFinalizedDemo,
}) => {
  const [showCoverageDetails, setShowCoverageDetails] = React.useState(false);

  return (
    <header className="border-b border-white/10 bg-[#090d16] sticky top-0 z-40 backdrop-blur-md">
      {/* 1. Main Navigation & Brand Row */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Brand */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-9 h-9 rounded-lg bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400 font-black text-sm tracking-wider shadow-inner">
              RTB
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold tracking-tight text-white">
                  RTB Command Center
                </h1>
                <span className="text-[11px] font-medium px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">
                  Equativ TechOps
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                Evidence-based publisher and demand diagnostics
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="hidden md:flex items-center gap-1">
            <button
              onClick={() => onTabChange('overview')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeTab === 'overview'
                  ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Overview & Triage
            </button>
            <button
              onClick={() => onTabChange('disconnections')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeTab === 'disconnections'
                  ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Partner Disconnections ({model.disconnections.length})
            </button>
            <button
              onClick={() => onTabChange('signals')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeTab === 'signals'
                  ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Signals & Checklist
            </button>
            <button
              onClick={() => onTabChange('validation')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeTab === 'validation'
                  ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Validation & Slack
            </button>
            <button
              onClick={() => onTabChange('specs')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeTab === 'specs'
                  ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Adapter Specs
            </button>
          </nav>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={onOpenImport}
              className="px-2.5 py-1.5 rounded-lg border border-white/10 bg-slate-900 text-xs font-medium text-slate-200 hover:border-white/30 transition-colors flex items-center gap-1.5"
              title="Import executed workflow JSON or load samples"
            >
              <Upload className="w-3.5 h-3.5 text-blue-400" />
              <span>Import Data</span>
            </button>

            <button
              onClick={onOpenSourceViewer}
              className="px-2.5 py-1.5 rounded-lg border border-white/10 bg-slate-900 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors flex items-center gap-1.5"
              title="Inspect raw source JSON payload"
            >
              <Code className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Raw Source</span>
            </button>
          </div>
        </div>

        {/* 2. Metadata Strip: Data-source mode, window, timezone, import timestamp */}
        <div className="py-2.5 border-t border-white/5 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 flex-wrap">
            {/* Data Source Mode Tag */}
            <span
              className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[11px] font-semibold border ${
                model.sourceType === 'finalized_report'
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                  : 'bg-amber-500/10 text-amber-300 border-amber-500/30'
              }`}
            >
              <Database className="w-3 h-3" />
              {model.sourceType === 'finalized_report'
                ? 'Finalized Executed Report'
                : 'Sample workflow input — not production data'}
            </span>

            <span className="text-slate-600">·</span>

            {/* Source Window & Timezone */}
            <span className="text-slate-300 flex items-center gap-1 text-[11px]">
              <Globe className="w-3 h-3 text-slate-500" />
              <span>Window: <strong>{model.metadata.moduleReportingWindow}</strong></span>
              {model.metadata.hasWindowCoverageDiscrepancy && (
                <button
                  type="button"
                  onClick={() => setShowCoverageDetails(!showCoverageDetails)}
                  className="ml-1 inline-flex items-center gap-1 text-[10px] text-amber-300 bg-amber-500/15 px-2 py-0.5 rounded border border-amber-500/30 hover:bg-amber-500/25 cursor-pointer font-medium"
                  title="Click to view coverage interval distinction"
                >
                  <AlertTriangle className="w-3 h-3 text-amber-400" />
                  <span>Metric interval differs (2026-09-28..10-04 vs 10-06..10-12)</span>
                </button>
              )}
            </span>

            <span className="text-slate-600">·</span>

            {/* Import Timestamp (NOT source refresh timestamp) */}
            <span className="text-slate-400 flex items-center gap-1 text-[11px]" title="Client-side import timestamp — not source-data refresh timestamp">
              <Clock className="w-3 h-3 text-slate-500" />
              <span>Imported: <span className="font-mono-num">{new Date(model.metadata.importTimestamp).toLocaleTimeString()}</span> (Client Import)</span>
            </span>
          </div>

          {/* Quick Preset Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={onLoadSampleInput}
              className="text-[11px] text-slate-400 hover:text-white underline cursor-pointer"
            >
              Reset to Sample Input
            </button>
            <span className="text-slate-600">·</span>
            <button
              onClick={onLoadFinalizedDemo}
              className="text-[11px] text-blue-400 hover:text-blue-300 underline font-medium cursor-pointer"
            >
              Preview Finalized Report Output
            </button>
          </div>
        </div>

        {/* 3. Coverage Discrepancy Expanded Explainer */}
        {model.metadata.hasWindowCoverageDiscrepancy && showCoverageDetails && (
          <div className="mb-2 py-2 px-3 bg-amber-950/40 border border-amber-500/30 rounded text-[11px] text-amber-300 flex items-center justify-between gap-2 animate-in fade-in">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>
                <strong>Date Coverage Distinction:</strong> {model.metadata.windowDiscrepancyNotice}
              </span>
            </div>
            <button
              onClick={() => setShowCoverageDetails(false)}
              className="text-amber-400 hover:text-white text-xs underline cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
