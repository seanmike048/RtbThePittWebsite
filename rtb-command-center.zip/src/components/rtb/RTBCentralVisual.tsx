/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { RTBViewModel } from '../../lib/adapter/types.ts';
import { TrendingDown, Calendar, AlertOctagon, Clock, Layers, ShieldAlert, ArrowRight } from 'lucide-react';

interface RTBCentralVisualProps {
  model: RTBViewModel;
}

export const RTBCentralVisual: React.FC<RTBCentralVisualProps> = ({ model }) => {
  const { overview, metadata, disconnections } = model;

  const beforeVal = overview.bidRequestsBefore;
  const afterVal = overview.bidRequestsAfter;
  const changePct = overview.reportedChangePct;

  // Relative width math for before vs after bar
  const beforePct = 100;
  const afterPct = Math.max(2.4, (afterVal / beforeVal) * 100);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      {/* 1. Large Before vs After Bid Request Comparison */}
      <div className="rounded-xl border border-white/10 bg-[#0d1424] p-5 shadow-2xl flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span className="font-semibold uppercase tracking-wider text-blue-400">
              Demand Flow Impact
            </span>
            <span className="text-slate-500 font-mono-num text-[11px]">
              {metadata.metricPeriod}
            </span>
          </div>

          <h2 className="text-lg font-bold text-white tracking-tight">
            Bid-Request Collapse Comparison
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Verified ad server request volumes before and after the October 5 disconnection event
          </p>

          {/* Volume Cards */}
          <div className="grid grid-cols-2 gap-3 mt-4">
            <div className="p-3.5 bg-slate-900 rounded-lg border border-white/5">
              <span className="text-[11px] text-slate-400 block font-sans mb-1">
                7d Baseline Volume (Before)
              </span>
              <div className="text-2xl font-bold font-mono-num text-white">
                {(beforeVal / 1_000_000).toFixed(2)}M
              </div>
              <div className="text-[11px] text-slate-500 font-mono-num mt-0.5">
                {beforeVal.toLocaleString()} requests
              </div>
            </div>

            <div className="p-3.5 bg-rose-950/20 rounded-lg border border-rose-500/30">
              <span className="text-[11px] text-rose-300 block font-sans mb-1">
                Post-Cut Volume (After)
              </span>
              <div className="text-2xl font-bold font-mono-num text-rose-400">
                {(afterVal / 1_000).toFixed(1)}K
              </div>
              <div className="text-[11px] text-rose-400/80 font-mono-num mt-0.5">
                {afterVal.toLocaleString()} requests ({changePct}%)
              </div>
            </div>
          </div>

          {/* Scale Visualization */}
          <div className="mt-5 space-y-3">
            <div>
              <div className="flex justify-between text-xs font-mono-num text-slate-300 mb-1">
                <span>Baseline (100%)</span>
                <span>{(beforeVal / 1_000_000).toFixed(1)}M</span>
              </div>
              <div className="w-full bg-slate-900 h-3 rounded-full overflow-hidden">
                <div className="bg-blue-500 h-full rounded-full transition-all duration-500 w-full" />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-mono-num text-rose-400 mb-1">
                <span>Post-Cut Collapse ({(afterVal / beforeVal * 100).toFixed(1)}%)</span>
                <span>{(afterVal / 1_000).toFixed(1)}K</span>
              </div>
              <div className="w-full bg-slate-900 h-3 rounded-full overflow-hidden">
                <div
                  className="bg-rose-500 h-full rounded-full transition-all duration-500"
                  style={{ width: `${afterPct}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="mt-4 pt-3 border-t border-white/5 text-[11px] text-slate-500 flex items-center justify-between">
          <span>Source: Equativ AdServer Log Stream</span>
          <span className="text-rose-400 font-medium">97.6% Demand Interruption</span>
        </div>
      </div>

      {/* 2. Disconnection & Metric Window Timeline */}
      <div className="rounded-xl border border-white/10 bg-[#0d1424] p-5 shadow-2xl flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span className="font-semibold uppercase tracking-wider text-amber-400">
              Event Sequence & Intervals
            </span>
            <span className="text-slate-500 text-[11px]">
              Timezone: {metadata.timezone}
            </span>
          </div>

          <h2 className="text-lg font-bold text-white tracking-tight">
            Disconnection Sequence Timeline
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Key anchors: pre-cut baseline, simultaneous seat cut, and post-cut measurement
          </p>

          {/* Interactive Visual Timeline Anchors */}
          <div className="mt-4 space-y-3">
            {/* Step 1: Pre-cut */}
            <div className="flex items-start gap-3 p-2.5 rounded-lg bg-slate-900 border border-white/5">
              <div className="w-6 h-6 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                1
              </div>
              <div className="text-xs flex-1">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-white">Pre-Cut Metric Period</span>
                  <span className="font-mono-num text-slate-400 text-[11px]">2026-09-28 – 2026-10-04</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  12.40M normal bid requests across Amazon DSP US and EMEA seats.
                </p>
              </div>
            </div>

            {/* Step 2: Cut Event */}
            <div className="flex items-start gap-3 p-2.5 rounded-lg bg-rose-950/30 border border-rose-500/30">
              <div className="w-6 h-6 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                2
              </div>
              <div className="text-xs flex-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-rose-300">Simultaneous Disconnection Cut</span>
                  <span className="font-mono-num text-rose-400 text-[11px]">2026-10-05T09:14:00</span>
                </div>
                <p className="text-[11px] text-rose-200/80 mt-0.5">
                  Seats 437 (US) and 489 (EMEA) cut simultaneously. Both marked <code>still_disconnected</code>.
                </p>
              </div>
            </div>

            {/* Step 3: Post-cut Interval */}
            <div className="flex items-start gap-3 p-2.5 rounded-lg bg-slate-900 border border-white/5">
              <div className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                3
              </div>
              <div className="text-xs flex-1">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-white">Post-Cut Measurement Period</span>
                  <span className="font-mono-num text-slate-400 text-[11px]">2026-10-06 – 2026-10-12</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Residual traffic of 297.6K bid requests recorded (-97.6% reduction).
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-4 pt-3 border-t border-white/5 text-[11px] text-slate-500">
          Module Reporting Window: <strong>{metadata.moduleReportingWindow}</strong> · Preserves source timezone
        </div>
      </div>
    </div>
  );
};
