/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { RTBViewModel, DisconnectionPartnerRecord } from '../../lib/adapter/types.ts';
import { ArrowRight } from 'lucide-react';

interface RTBDisconnectionsTableProps {
  model: RTBViewModel;
  onSelectRecord?: (record: DisconnectionPartnerRecord) => void;
}

export const RTBDisconnectionsTable: React.FC<RTBDisconnectionsTableProps> = ({
  model,
  onSelectRecord,
}) => {
  const [partnerFilter, setPartnerFilter] = useState<'ALL' | number>('ALL');

  const filteredDisconnections = model.disconnections.filter(d => {
    if (partnerFilter !== 'ALL' && d.partnerId !== partnerFilter) return false;
    return true;
  });

  return (
    <div className="rounded-xl border border-white/10 bg-[#0d1424] p-5 sm:p-6 shadow-2xl space-y-4 overflow-visible">
      {/* Title & Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 pt-1">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-rose-400">
              Disconnection Ledger
            </span>
            <span className="text-slate-600">·</span>
            <span className="text-xs text-slate-400">ANALYTICS.PUBLIC.VIEW_DISCONNECTION_ALERT_365DAYS</span>
          </div>
          <h2 className="text-base sm:text-lg font-bold text-white tracking-tight mt-1">
            Partner Disconnections & Seat Diagnostics
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Verified disconnection alerts · Click any row to open the complete evidence & source data drawer
          </p>
        </div>

        {/* Filter by partner seat */}
        <div className="flex items-center gap-2 text-xs">
          <label htmlFor="seat-filter" className="text-slate-400 font-medium whitespace-nowrap">
            Filter Seat:
          </label>
          <select
            id="seat-filter"
            value={partnerFilter}
            onChange={e => setPartnerFilter(e.target.value === 'ALL' ? 'ALL' : Number(e.target.value))}
            className="bg-slate-900 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500 cursor-pointer"
          >
            <option value="ALL">All Reported Seats ({model.disconnections.length})</option>
            {model.overview.distinctPartnerIds.map(id => (
              <option key={id} value={id}>
                Seat #{id} (Amazon DSP)
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Table Data Grid */}
      <div className="overflow-x-auto rounded-lg border border-white/10">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="bg-slate-900 border-b border-white/10 text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
            <tr>
              <th className="py-3 px-3.5 whitespace-nowrap">Publisher (ID)</th>
              <th className="py-3 px-3.5 whitespace-nowrap">Partner Seat (ID)</th>
              <th className="py-3 px-3.5 whitespace-nowrap">Disconnection Cut</th>
              <th className="py-3 px-3.5 whitespace-nowrap">Lifecycle Status</th>
              <th className="py-3 px-3.5 text-right whitespace-nowrap min-w-[150px]">7d Pre-Cut Spend</th>
              <th className="py-3 px-3.5 whitespace-nowrap min-w-[160px]">Root Cause Status</th>
              <th className="py-3 px-3.5 whitespace-nowrap">Owner Context</th>
              <th className="py-3 px-2.5 text-right whitespace-nowrap">Inspect</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5 bg-[#0a0f1d] text-slate-300">
            {filteredDisconnections.length === 0 ? (
              <tr>
                <td colSpan={8} className="py-8 text-center text-slate-500">
                  No disconnection records match current filter.
                </td>
              </tr>
            ) : (
              filteredDisconnections.map(record => (
                <tr
                  key={record.partnerId}
                  onClick={() => onSelectRecord?.(record)}
                  className="cursor-pointer hover:bg-white/5 transition-colors group"
                >
                  {/* Publisher */}
                  <td className="py-3.5 px-3.5 whitespace-nowrap">
                    <div className="font-semibold text-white">
                      {model.overview.publisherName}
                    </div>
                    <div className="text-[11px] font-mono-num text-slate-500">
                      ID #{model.overview.publisherId}
                    </div>
                  </td>

                  {/* Partner Seat */}
                  <td className="py-3.5 px-3.5 whitespace-nowrap">
                    <div className="font-medium text-slate-200">
                      {record.partnerName}
                    </div>
                    <div className="text-[11px] font-mono-num text-slate-500">
                      Seat #{record.partnerId}
                    </div>
                  </td>

                  {/* Cut Timestamp */}
                  <td className="py-3.5 px-3.5 whitespace-nowrap">
                    <div className="font-mono-num text-slate-200 text-xs">
                      {record.disconnectionTimestamp.replace('T', ' ')}
                    </div>
                    <div className="text-[10px] text-slate-500">
                      Europe/Paris
                    </div>
                  </td>

                  {/* Lifecycle Status */}
                  <td className="py-3.5 px-3.5 whitespace-nowrap">
                    {record.status === 'still_disconnected' ? (
                      <span className="inline-block px-2.5 py-1 rounded text-[11px] font-bold font-mono-num bg-rose-500/15 text-rose-400 border border-rose-500/30">
                        STILL DISCONNECTED
                      </span>
                    ) : (
                      <span className="inline-block px-2.5 py-1 rounded text-[11px] font-bold font-mono-num bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                        RECONNECTED
                      </span>
                    )}
                  </td>

                  {/* 7d Pre-Cut Spend with Integrated Currency Disclosure */}
                  <td className="py-3.5 px-3.5 text-right whitespace-nowrap">
                    <div className="font-mono-num text-white text-xs font-bold">
                      {record.spend7dBefore.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </div>
                    <span className="inline-block mt-0.5 px-1.5 py-0.5 rounded text-[10px] bg-amber-500/10 text-amber-300 border border-amber-500/30 font-medium">
                      Currency not provided
                    </span>
                  </td>

                  {/* Reason & Root Cause Status */}
                  <td className="py-3.5 px-3.5 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase border ${
                          record.reasonType === 'confirmed'
                            ? 'bg-blue-500/15 text-blue-300 border-blue-500/30'
                            : record.reasonType === 'hypothesis'
                            ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                            : 'bg-slate-800 text-slate-400 border-white/10'
                        }`}
                      >
                        {record.reasonType === 'confirmed'
                          ? 'Confirmed'
                          : record.reasonType === 'hypothesis'
                          ? 'Hypothesis Only'
                          : 'Not Provided in Alert'}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400 italic mt-0.5 line-clamp-1 max-w-[200px]">
                      {record.reason ? `"${record.reason}"` : 'No root cause string in alert'}
                    </div>
                  </td>

                  {/* Owner Context */}
                  <td className="py-3.5 px-3.5 text-[11px] text-slate-400 font-mono-num whitespace-nowrap">
                    {record.ownerContext}
                  </td>

                  {/* Action */}
                  <td className="py-3.5 px-2.5 text-right whitespace-nowrap">
                    <span className="inline-flex items-center text-blue-400 group-hover:text-blue-300 p-1">
                      <ArrowRight className="w-4 h-4" />
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
