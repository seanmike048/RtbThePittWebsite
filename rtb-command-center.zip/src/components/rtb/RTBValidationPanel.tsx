/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { RTBViewModel } from '../../lib/adapter/types.ts';
import {
  ShieldCheck,
  ShieldAlert,
  Copy,
  Check,
  Download,
  AlertTriangle,
  MessageSquare,
  Lock,
  FileText,
  HelpCircle,
} from 'lucide-react';

interface RTBValidationPanelProps {
  model: RTBViewModel;
}

export const RTBValidationPanel: React.FC<RTBValidationPanelProps> = ({ model }) => {
  const { validation } = model;
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const handleCopy = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleExportJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(model.rawSourceJson);
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `rtb_report_${model.overview.publisherId}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="rounded-xl border border-white/10 bg-[#0d1424] p-5 shadow-2xl space-y-5">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-blue-400">
              Boundary C · Output Validation & Assembly
            </span>
            <span className="text-slate-600">·</span>
            <span className="text-xs text-slate-400">Truth Enforcement</span>
          </div>
          <h2 className="text-base sm:text-lg font-bold text-white tracking-tight mt-0.5">
            Communication & Truth Validation
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Validates generated language against source facts and deterministic fallbacks. Max 200 words enforced on Slack text.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportJson}
            className="px-3 py-1.5 rounded-lg border border-white/10 bg-slate-900 text-xs font-medium text-slate-200 hover:text-white flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-blue-400" />
            <span>Export Report JSON</span>
          </button>
        </div>
      </div>

      {/* Validation Status Badges */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
        <div className="p-3 bg-slate-900 rounded-lg border border-white/5 flex items-center justify-between">
          <span className="text-slate-400">Finalized Validation Supplied:</span>
          <span
            className={`font-semibold font-mono-num px-2 py-0.5 rounded text-[11px] ${
              validation.isFinalizedReportSupplied
                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                : 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
            }`}
          >
            {validation.isFinalizedReportSupplied ? 'YES (Finalized)' : 'NO (Raw Sample Input)'}
          </span>
        </div>

        <div className="p-3 bg-slate-900 rounded-lg border border-white/5 flex items-center justify-between">
          <span className="text-slate-400">Reported Validation Issues:</span>
          <span
            className={`font-semibold font-mono-num px-2 py-0.5 rounded text-[11px] ${
              validation.issues.length === 0
                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                : 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
            }`}
          >
            {validation.issues.length} Issues
          </span>
        </div>

        <div className="p-3 bg-slate-900 rounded-lg border border-white/5 flex items-center justify-between">
          <span className="text-slate-400">Deterministic Fallback Fields:</span>
          <span className="font-semibold font-mono-num text-slate-300">
            {validation.fallbackFields.length > 0 ? validation.fallbackFields.join(', ') : 'None Replaced'}
          </span>
        </div>
      </div>

      {/* Slack Text (Preserved Exactly + 200 Words Rule Check) */}
      <div className="p-4 rounded-lg bg-slate-900 border border-white/5 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-emerald-400" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Validated Slack Broadcast Text (Boundary C Output)
            </h3>
          </div>

          <div className="flex items-center gap-3">
            {/* Word count check */}
            <span
              className={`font-mono-num text-[11px] px-2 py-0.5 rounded border ${
                validation.isSlackExceeding200Words
                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 font-bold'
                  : 'bg-slate-800 text-slate-400 border-white/10'
              }`}
            >
              {validation.slackWordCount} / 200 words max
            </span>

            {validation.slackText && (
              <button
                onClick={() => handleCopy(validation.slackText!, 'slack')}
                className="px-2.5 py-1 rounded bg-slate-800 text-slate-300 hover:text-white flex items-center gap-1 text-xs transition-colors"
              >
                {copiedField === 'slack' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedField === 'slack' ? 'Copied' : 'Copy Slack Text'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Warning if exceeds 200 words */}
        {validation.isSlackExceeding200Words && (
          <div className="p-2.5 rounded bg-rose-950/40 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>
              Warning: Slack text exceeds the 200-word limit ({validation.slackWordCount} words). The text is preserved exactly as supplied and not silently truncated.
            </span>
          </div>
        )}

        {validation.slackText ? (
          <pre className="p-3 bg-slate-950 rounded border border-white/5 text-xs text-emerald-300 font-mono-num whitespace-pre-wrap leading-relaxed select-text">
            {validation.slackText}
          </pre>
        ) : (
          <div className="p-4 bg-[#0a0f1d] rounded border border-white/5 text-xs text-slate-500 italic flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-slate-600" />
            <span>
              No validated Slack broadcast supplied in raw sample input. This text is synthesized during report finalization.
            </span>
          </div>
        )}

        <div className="text-[11px] text-slate-500 flex items-center justify-between">
          <span>Target channel: #equativ-techops-rtb</span>
          <span className="italic">Read-only presentation · No automated dispatch without human confirmation</span>
        </div>
      </div>

      {/* Client Message (Read-only Draft) */}
      <div className="p-4 rounded-lg bg-slate-900 border border-white/5 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-blue-400" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Validated Client Communication (Gemini formatting)
            </h3>
          </div>

          {validation.clientMessage && (
            <button
              onClick={() => handleCopy(validation.clientMessage!, 'client')}
              className="px-2.5 py-1 rounded bg-slate-800 text-slate-300 hover:text-white flex items-center gap-1 text-xs transition-colors"
            >
              {copiedField === 'client' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedField === 'client' ? 'Copied' : 'Copy Message'}</span>
            </button>
          )}
        </div>

        {validation.clientMessage ? (
          <pre className="p-3 bg-slate-950 rounded border border-white/5 text-xs text-slate-200 font-sans whitespace-pre-wrap leading-relaxed select-text">
            {validation.clientMessage}
          </pre>
        ) : (
          <div className="p-4 bg-[#0a0f1d] rounded border border-white/5 text-xs text-slate-500 italic flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-slate-600" />
            <span>
              No client message generated in raw sample input mode.
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
