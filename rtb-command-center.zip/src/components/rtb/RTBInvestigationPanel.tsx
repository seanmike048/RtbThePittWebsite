/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { RTBViewModel } from '../../lib/adapter/types.ts';
import {
  Brain,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  ShieldAlert,
  ArrowRight,
  FileText,
  UserCheck,
  Link,
  BookOpen,
} from 'lucide-react';

interface RTBInvestigationPanelProps {
  model: RTBViewModel;
}

export const RTBInvestigationPanel: React.FC<RTBInvestigationPanelProps> = ({ model }) => {
  const { investigation, sourceType } = model;
  const isRawInput = sourceType === 'sample_input';

  return (
    <div className="rounded-xl border border-white/10 bg-[#0d1424] p-5 shadow-2xl space-y-5">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400">
            <Brain className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">
                Report & Investigation Diagnostics
              </h2>
              <span className="text-[11px] px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">
                Evidence-Grounded
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Preserves backend boundaries: Deterministic facts vs Gemini narrative vs Validation assembly
            </p>
          </div>
        </div>

        <div className="text-xs">
          {isRawInput ? (
            <span className="px-2.5 py-1 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30 font-medium">
              Raw Sample Input Mode
            </span>
          ) : (
            <span className="px-2.5 py-1 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-medium">
              Finalized Validated Report
            </span>
          )}
        </div>
      </div>

      {/* 1. Validated Finding (Gemini formatting) */}
      <div className="p-4 rounded-lg bg-slate-900 border border-white/5 space-y-2">
        <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
          Validated Incident Finding
        </span>
        {investigation.finding ? (
          <p className="text-sm font-medium text-white leading-relaxed">
            {investigation.finding}
          </p>
        ) : (
          <div className="p-3 bg-[#0a0f1d] rounded border border-white/5 text-xs text-slate-500 italic flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-slate-600" />
            <span>
              Unavailable in raw sample input. The finding is synthesized by the Gemini formatting step in executed finalized reports.
            </span>
          </div>
        )}
      </div>

      {/* 2. Confirmed Facts & Selected Evidence */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Confirmed Facts */}
        <div className="p-4 rounded-lg bg-slate-900 border border-white/5 space-y-2">
          <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Confirmed Facts (Deterministic)
          </span>
          <ul className="space-y-1.5 text-xs text-slate-300">
            {investigation.confirmedFacts.map((fact, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="text-emerald-500 mt-0.5">•</span>
                <span className="leading-snug">{fact}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Selected Evidence (up to 3 items) */}
        <div className="p-4 rounded-lg bg-slate-900 border border-white/5 space-y-2">
          <span className="text-xs font-semibold text-blue-400 uppercase tracking-wider flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5" />
            Selected Evidence (Max 3 Items)
          </span>
          <div className="space-y-2">
            {investigation.selectedEvidence.map((ev, idx) => (
              <div key={idx} className="p-2.5 rounded bg-[#0a0f1d] border border-white/5 text-xs space-y-0.5">
                <div className="flex items-center justify-between">
                  <strong className="text-white">{ev.title}</strong>
                  <span className="text-[10px] text-slate-500 font-mono-num">{ev.source}</span>
                </div>
                <p className="text-[11px] text-slate-400">{ev.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 3. Unknowns & Visually Separate Hypotheses */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Unknowns and Data-Quality Limitations */}
        <div className="p-4 rounded-lg bg-slate-900 border border-white/5 space-y-2">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
            <HelpCircle className="w-3.5 h-3.5 text-slate-500" />
            Unknowns & Data-Quality Limitations
          </span>
          <ul className="space-y-1.5 text-xs text-slate-400">
            {investigation.unknowns.map((unk, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="text-slate-500 mt-0.5">•</span>
                <span className="leading-snug">{unk}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Visually Separate Unconfirmed Hypotheses Section */}
        <div className="p-4 rounded-lg bg-amber-950/20 border border-amber-500/30 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
              <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
              Unconfirmed Hypotheses
            </span>
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
              Not Confirmed Cause
            </span>
          </div>

          <p className="text-[11px] text-amber-200/80 leading-snug">
            Guardrail: The ads.txt statement is strictly an unconfirmed working hypothesis. It must never be treated as a confirmed root cause or affect priority.
          </p>

          <div className="space-y-1.5 mt-2">
            {investigation.hypotheses.map((hyp, idx) => (
              <div key={idx} className="p-2.5 rounded bg-[#0a0f1d] border border-amber-500/20 text-xs">
                <strong className="text-amber-200">Hypothesis {idx + 1}:</strong>
                <p className="text-slate-300 mt-0.5 italic">"{hyp.statement}"</p>
                <span className="text-[10px] text-slate-500 block mt-1">{hyp.note}</span>
              </div>
            ))}
          </div>

          <div className="pt-2 text-[11px] text-slate-400">
            Confirmed Disconnection Reason:{' '}
            <strong className="text-white">
              {investigation.confirmedReason || 'None confirmed in report'}
            </strong>
          </div>
        </div>
      </div>

      {/* 4. Action Directives & Ownership */}
      <div className="p-4 rounded-lg bg-slate-900 border border-white/5 space-y-3">
        <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
          Action Directives & Ownership
        </span>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          {/* Primary Action */}
          <div>
            <strong className="text-white block mb-1">Primary Action:</strong>
            {investigation.primaryAction ? (
              <p className="text-blue-300 bg-[#0a0f1d] p-3 rounded border border-white/5 font-medium">
                {investigation.primaryAction}
              </p>
            ) : (
              <p className="text-slate-500 bg-[#0a0f1d] p-3 rounded border border-white/5 italic">
                Awaiting finalized workflow generation (unavailable in raw sample input).
              </p>
            )}

            {/* Owner Actions */}
            {investigation.ownerActions.length > 0 && (
              <div className="mt-3">
                <strong className="text-white block mb-1">Owner Action Checklist:</strong>
                <ul className="list-disc list-inside space-y-1 text-slate-300">
                  {investigation.ownerActions.map((act, idx) => (
                    <li key={idx}>{act}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Source-Provided Contacts & References */}
          <div className="space-y-3">
            <div>
              <strong className="text-white block mb-1">Source Contacts:</strong>
              <div className="space-y-1.5">
                {investigation.contacts.map((c, idx) => (
                  <div key={idx} className="p-2 bg-[#0a0f1d] rounded border border-white/5 flex items-center justify-between text-[11px]">
                    <span className="text-slate-300 font-semibold">{c.role}</span>
                    <span className="text-slate-400">{c.nameOrTeam}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <strong className="text-white block mb-1">Available References:</strong>
              <div className="flex flex-wrap gap-1.5">
                {investigation.availableReferences.map((ref, idx) => (
                  <span key={idx} className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-white/10 text-[10px] font-mono-num">
                    {ref}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
