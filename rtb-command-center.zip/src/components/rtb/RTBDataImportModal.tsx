/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { parseWorkflowPayload } from '../../lib/adapter/parser.ts';
import { RAW_SAMPLE_WORKFLOW_INPUT, SAMPLE_FINALIZED_REPORT } from '../../lib/adapter/sampleData.ts';
import { RTBViewModel } from '../../lib/adapter/types.ts';
import {
  X,
  Upload,
  RotateCcw,
  Sparkles,
  AlertOctagon,
  CheckCircle2,
  AlertTriangle,
  FileCode,
  Info,
} from 'lucide-react';

interface RTBDataImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyModel: (model: RTBViewModel) => void;
}

export const RTBDataImportModal: React.FC<RTBDataImportModalProps> = ({
  isOpen,
  onClose,
  onApplyModel,
}) => {
  const [jsonInput, setJsonInput] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isN8nPipelineError, setIsN8nPipelineError] = useState(false);
  const [fieldErrors, setFieldErrors] = useState<{ field: string; message: string }[]>([]);

  if (!isOpen) return null;

  const handleParseAndApply = (customJsonStr?: string) => {
    const textToParse = customJsonStr !== undefined ? customJsonStr : jsonInput;
    setErrorMessage(null);
    setIsN8nPipelineError(false);
    setFieldErrors([]);

    if (!textToParse.trim()) {
      setErrorMessage('Please paste or upload a JSON payload.');
      return;
    }

    try {
      const parsed = JSON.parse(textToParse);
      const res = parseWorkflowPayload(parsed, 'Custom User Import');

      if (!res.success) {
        setErrorMessage(res.error || 'Failed to parse payload.');
        setIsN8nPipelineError(Boolean(res.isN8nWorkflowDefinition));
        if (res.fieldErrors) setFieldErrors(res.fieldErrors);
        return;
      }

      if (res.model) {
        onApplyModel(res.model);
        onClose();
      }
    } catch (err: any) {
      setErrorMessage(`JSON Syntax Error: ${err.message}`);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = event => {
      const content = event.target?.result as string;
      setJsonInput(content);
      handleParseAndApply(content);
    };
    reader.readAsText(file);
  };

  const loadSampleInput = () => {
    const sampleStr = JSON.stringify(RAW_SAMPLE_WORKFLOW_INPUT, null, 2);
    setJsonInput(sampleStr);
    handleParseAndApply(sampleStr);
  };

  const loadFinalizedDemo = () => {
    const demoStr = JSON.stringify(SAMPLE_FINALIZED_REPORT, null, 2);
    setJsonInput(demoStr);
    handleParseAndApply(demoStr);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
      <div className="w-full max-w-2xl rounded-xl border border-white/20 bg-[#0d1424] p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400">
              <Upload className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white">
                Import RTB Workflow Execution Data
              </h2>
              <p className="text-xs text-slate-400">
                Paste JSON or load sample inputs to test the diagnostic pipeline
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Preset Action Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <button
            onClick={loadSampleInput}
            className="p-3 rounded-lg border border-white/10 bg-slate-900 hover:bg-slate-800 text-left transition-colors flex items-start gap-2.5"
          >
            <RotateCcw className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-white block font-medium">Load Faithful Sample Input</strong>
              <span className="text-[11px] text-slate-400 block mt-0.5">
                Loads supplied raw input from [TechOps] RTB-Checklist-Output-Generation.
              </span>
            </div>
          </button>

          <button
            onClick={loadFinalizedDemo}
            className="p-3 rounded-lg border border-emerald-500/30 bg-emerald-950/20 hover:bg-emerald-950/30 text-left transition-colors flex items-start gap-2.5"
          >
            <Sparkles className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-emerald-300 block font-medium">Load Finalized Executed Report</strong>
              <span className="text-[11px] text-slate-400 block mt-0.5">
                Previews a completed report with validated P0 priority, facts, and Slack text.
              </span>
            </div>
          </button>
        </div>

        {/* File Upload & Paste Area */}
        <div className="space-y-2 text-xs">
          <div className="flex items-center justify-between">
            <label htmlFor="json-paste-input" className="font-semibold text-slate-300">
              Paste Executed JSON Payload:
            </label>
            <label className="cursor-pointer text-blue-400 hover:underline flex items-center gap-1 font-medium text-[11px]">
              <Upload className="w-3.5 h-3.5" />
              <span>Upload .json file</span>
              <input
                type="file"
                accept=".json"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>
          </div>

          <textarea
            id="json-paste-input"
            value={jsonInput}
            onChange={e => setJsonInput(e.target.value)}
            placeholder="Paste raw workflow module input or finalized report JSON here..."
            className="w-full h-48 bg-[#0a0f1d] border border-white/10 rounded-lg p-3 text-xs font-mono-num text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-blue-500 resize-none"
          />
        </div>

        {/* Error Callouts */}
        {errorMessage && (
          <div
            className={`p-3.5 rounded-lg border text-xs flex items-start gap-2.5 ${
              isN8nPipelineError
                ? 'bg-rose-950/40 border-rose-500/40 text-rose-200'
                : 'bg-amber-950/30 border-amber-500/30 text-amber-200'
            }`}
          >
            <AlertOctagon className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <strong>{isN8nPipelineError ? 'Pipeline Workflow Code Detected:' : 'Validation Error:'}</strong>
              <p className="text-[11px] leading-relaxed">{errorMessage}</p>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="pt-4 border-t border-white/10 flex items-center justify-between">
          <div className="text-[11px] text-slate-500">
            Client-side parsing · Never executes code in uploaded payloads
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg border border-white/10 text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              onClick={() => handleParseAndApply()}
              className="px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-xs font-semibold text-white shadow-md transition-colors"
            >
              Parse & Apply
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
