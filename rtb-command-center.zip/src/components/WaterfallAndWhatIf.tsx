/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  EnrichedDisconnection,
  deriveRevenueWaterfall,
  simulateWhatIf,
  WaterfallStep,
  WhatIfOptions,
} from '../lib/pitt/engine.ts';
import { TrendingDown, TrendingUp, Sparkles, CheckSquare, Square, Sliders, Info, BarChart3 } from 'lucide-react';

interface WaterfallAndWhatIfProps {
  cohort: EnrichedDisconnection[];
}

export const WaterfallAndWhatIf: React.FC<WaterfallAndWhatIfProps> = ({ cohort }) => {
  const waterfallSteps: WaterfallStep[] = deriveRevenueWaterfall(cohort);
  const disconnectedCount = cohort.filter(r => r.RECONNECTED_AT === null).length;

  const [whatIfOptions, setWhatIfOptions] = useState<WhatIfOptions>({
    networksFixedCount: 0,
    fixAdsTxt: false,
    fixSco: false,
    fixIvt: false,
    fixBlockedInventory: false,
  });

  const whatIfResult = simulateWhatIf(cohort, whatIfOptions);

  const maxCumulative = Math.max(...waterfallSteps.map(s => Math.abs(s.cumulative)), 1);

  return (
    <div className="space-y-6">
      {/* 1. Revenue Variance Waterfall Section */}
      <div className="rounded-xl border border-white/10 bg-[#0d1424] p-5 shadow-2xl">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-blue-400">
                Financial Variance
              </span>
              <span className="text-slate-600">·</span>
              <span className="text-xs text-slate-400">Run-Rate Delta Bridge</span>
            </div>
            <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight mt-0.5">
              Revenue Variance Waterfall
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Pre-cut 7-day run-rate → partner seat cut losses → remediated recovery → current run-rate
            </p>
          </div>
        </div>

        {/* Visual Waterfall Bars */}
        <div className="space-y-2.5 pt-2">
          {waterfallSteps.map((step, idx) => {
            const isLoss = step.category === 'LOSS';
            const isGain = step.category === 'GAIN';
            const isStart = step.category === 'START';
            const isEnd = step.category === 'END';

            const barWidthPct = Math.max(12, Math.min(100, (Math.abs(step.cumulative) / maxCumulative) * 100));

            return (
              <div
                key={idx}
                className="p-3 rounded-lg border border-white/5 bg-[#0a0f1d] hover:border-white/20 transition-all"
              >
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="font-semibold text-slate-200 flex items-center gap-2">
                    {isLoss && <TrendingDown className="w-3.5 h-3.5 text-rose-400" />}
                    {isGain && <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />}
                    {isStart && <span className="w-2 h-2 rounded-full bg-blue-400" />}
                    {isEnd && <span className="w-2 h-2 rounded-full bg-sky-400" />}
                    {step.name}
                  </span>

                  <div className="flex items-center gap-3 font-mono-num">
                    <span
                      className={`font-bold ${
                        isLoss
                          ? 'text-rose-400'
                          : isGain
                          ? 'text-emerald-400'
                          : 'text-white'
                      }`}
                    >
                      {step.formattedAmount}
                    </span>
                    <span className="text-slate-500 text-[11px]">
                      Balance: ${(step.cumulative / 1000).toFixed(1)}K
                    </span>
                  </div>
                </div>

                {/* Bar representation */}
                <div className="w-full bg-slate-900 h-2.5 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${
                      isLoss
                        ? 'bg-rose-500'
                        : isGain
                        ? 'bg-emerald-500'
                        : isEnd
                        ? 'bg-sky-500'
                        : 'bg-blue-500'
                    }`}
                    style={{ width: `${barWidthPct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 2. What-If Simulation Panel */}
      <div className="rounded-xl border border-white/10 bg-[#0d1424] p-5 shadow-2xl">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-amber-400 flex items-center gap-1">
                <Sliders className="w-3.5 h-3.5" />
                Scenario Modeling
              </span>
              <span className="text-slate-600">·</span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30">
                {whatIfResult.label}
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight mt-0.5">
              Remediation What-If Simulator
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Simulate technical fixes across the cohort to evaluate projected revenue recovery and priority demotions
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Controls: Slider & Check Toggles */}
          <div className="space-y-4 p-4 rounded-lg border border-white/5 bg-[#0a0f1d]">
            {/* Slider: Networks Fixed */}
            <div>
              <div className="flex justify-between items-center text-xs mb-1.5">
                <label htmlFor="networks-fixed-slider" className="font-semibold text-slate-300">
                  Fixed Networks Count:
                </label>
                <span className="font-mono-num font-bold text-blue-400 text-sm">
                  {whatIfOptions.networksFixedCount} / {disconnectedCount}
                </span>
              </div>
              <input
                id="networks-fixed-slider"
                type="range"
                min="0"
                max={disconnectedCount}
                value={whatIfOptions.networksFixedCount}
                onChange={e =>
                  setWhatIfOptions({ ...whatIfOptions, networksFixedCount: Number(e.target.value) })
                }
                className="w-full accent-blue-500 cursor-pointer h-2 bg-slate-900 rounded-lg"
              />
              <p className="text-[11px] text-slate-500 mt-1">
                Prioritizes fixing highest-spend disconnected networks first.
              </p>
            </div>

            {/* Per-Check Remediation Toggles */}
            <div className="pt-2 border-t border-white/5">
              <span className="text-xs font-semibold text-slate-400 block mb-2">
                Simulate Root Cause Remediations:
              </span>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() =>
                    setWhatIfOptions({ ...whatIfOptions, fixAdsTxt: !whatIfOptions.fixAdsTxt })
                  }
                  className={`p-2.5 rounded-lg border flex items-center gap-2 transition-colors ${
                    whatIfOptions.fixAdsTxt
                      ? 'bg-blue-600/20 text-blue-300 border-blue-500/40'
                      : 'bg-slate-900 text-slate-400 border-white/10 hover:border-white/20'
                  }`}
                >
                  {whatIfOptions.fixAdsTxt ? (
                    <CheckSquare className="w-4 h-4 text-blue-400" />
                  ) : (
                    <Square className="w-4 h-4" />
                  )}
                  <span>Fix ads.txt Issues</span>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    setWhatIfOptions({ ...whatIfOptions, fixSco: !whatIfOptions.fixSco })
                  }
                  className={`p-2.5 rounded-lg border flex items-center gap-2 transition-colors ${
                    whatIfOptions.fixSco
                      ? 'bg-blue-600/20 text-blue-300 border-blue-500/40'
                      : 'bg-slate-900 text-slate-400 border-white/10 hover:border-white/20'
                  }`}
                >
                  {whatIfOptions.fixSco ? (
                    <CheckSquare className="w-4 h-4 text-blue-400" />
                  ) : (
                    <Square className="w-4 h-4" />
                  )}
                  <span>Fix Supply Chain (SCO)</span>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    setWhatIfOptions({ ...whatIfOptions, fixIvt: !whatIfOptions.fixIvt })
                  }
                  className={`p-2.5 rounded-lg border flex items-center gap-2 transition-colors ${
                    whatIfOptions.fixIvt
                      ? 'bg-blue-600/20 text-blue-300 border-blue-500/40'
                      : 'bg-slate-900 text-slate-400 border-white/10 hover:border-white/20'
                  }`}
                >
                  {whatIfOptions.fixIvt ? (
                    <CheckSquare className="w-4 h-4 text-blue-400" />
                  ) : (
                    <Square className="w-4 h-4" />
                  )}
                  <span>Tighten IVT Filters</span>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    setWhatIfOptions({
                      ...whatIfOptions,
                      fixBlockedInventory: !whatIfOptions.fixBlockedInventory,
                    })
                  }
                  className={`p-2.5 rounded-lg border flex items-center gap-2 transition-colors ${
                    whatIfOptions.fixBlockedInventory
                      ? 'bg-blue-600/20 text-blue-300 border-blue-500/40'
                      : 'bg-slate-900 text-slate-400 border-white/10 hover:border-white/20'
                  }`}
                >
                  {whatIfOptions.fixBlockedInventory ? (
                    <CheckSquare className="w-4 h-4 text-blue-400" />
                  ) : (
                    <Square className="w-4 h-4" />
                  )}
                  <span>Delist Policy Blocks</span>
                </button>
              </div>
            </div>
          </div>

          {/* Results: Projected Recovery & Priority Shifts */}
          <div className="space-y-3 p-4 rounded-lg border border-white/5 bg-[#0a0f1d] flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-400">Projected Remediation Impact</span>
                <span className="text-[10px] font-mono-num text-slate-500">
                  {whatIfResult.fixedNetworksCount} networks resolved
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="p-3 bg-slate-900 rounded-lg border border-white/10">
                  <span className="text-[11px] text-slate-400 block mb-0.5">
                    Projected Recovered
                  </span>
                  <div className="text-xl font-bold font-mono-num text-emerald-400">
                    +${(whatIfResult.projectedRevenueRecovered / 1000).toFixed(1)}K/wk
                  </div>
                </div>

                <div className="p-3 bg-slate-900 rounded-lg border border-white/10">
                  <span className="text-[11px] text-slate-400 block mb-0.5">
                    Remaining at Risk
                  </span>
                  <div className="text-xl font-bold font-mono-num text-rose-400">
                    ${(whatIfResult.projectedRemainingAtRisk / 1000).toFixed(1)}K/wk
                  </div>
                </div>
              </div>

              {/* Priority Migration: P0 shifts to P2/Resolved */}
              <div className="p-3 bg-blue-950/40 border border-blue-500/20 rounded-lg text-xs space-y-1">
                <div className="flex items-center justify-between text-slate-300">
                  <span>P0 Critical Queue Shift:</span>
                  <span className="font-mono-num font-semibold text-white">
                    {whatIfResult.initialP0Count} → {whatIfResult.projectedP0Count} P0s
                  </span>
                </div>
                <p className="text-[11px] text-blue-300">
                  <strong>{whatIfResult.p0ShiftedCount} P0 networks</strong> successfully mitigated or downgraded to P2.
                </p>
              </div>
            </div>

            <div className="pt-2 text-[11px] text-slate-500 italic flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 shrink-0" />
              <span>Simulations are modeled deterministically using pre-cut 7-day spend run-rates.</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
