/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { PittKpiMetrics, KpiCardData } from '../lib/pitt/engine.ts';
import { Info, AlertTriangle, DollarSign, CheckCircle2, ShieldAlert, Sparkles } from 'lucide-react';

interface KpiStripProps {
  metrics: PittKpiMetrics;
}

export const KpiStrip: React.FC<KpiStripProps> = ({ metrics }) => {
  const [activeTooltip, setActiveTooltip] = useState<string | null>(null);

  const cards: { key: string; data: KpiCardData; icon: React.ReactNode; color: string }[] = [
    {
      key: 'disconnected',
      data: metrics.cards.networksDisconnected,
      icon: <AlertTriangle className="w-4 h-4 text-rose-400" />,
      color: 'border-rose-500/30 bg-rose-500/5',
    },
    {
      key: 'revenueAtRisk',
      data: metrics.cards.revenueAtRisk,
      icon: <DollarSign className="w-4 h-4 text-rose-400" />,
      color: 'border-rose-500/30 bg-rose-500/5',
    },
    {
      key: 'reconnected',
      data: metrics.cards.reconnected,
      icon: <CheckCircle2 className="w-4 h-4 text-emerald-400" />,
      color: 'border-emerald-500/30 bg-emerald-500/5',
    },
    {
      key: 'revenueSaved',
      data: metrics.cards.revenueSaved,
      icon: <Sparkles className="w-4 h-4 text-blue-400" />,
      color: 'border-blue-500/30 bg-blue-500/5',
    },
    {
      key: 'failingChecks',
      data: metrics.cards.failingChecks,
      icon: <ShieldAlert className="w-4 h-4 text-amber-400" />,
      color: 'border-amber-500/30 bg-amber-500/5',
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-5 gap-3.5">
      {cards.map(c => {
        const isHovered = activeTooltip === c.key;
        return (
          <div
            key={c.key}
            className={`relative p-3.5 rounded-lg border bg-[#0d1424] transition-all duration-200 ${
              isHovered ? 'border-white/30 shadow-lg' : 'border-white/10'
            }`}
            onMouseEnter={() => setActiveTooltip(c.key)}
            onMouseLeave={() => setActiveTooltip(null)}
          >
            <div className="flex items-center justify-between gap-1 mb-1.5">
              <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1.5">
                {c.icon}
                <span className="truncate">{c.data.title}</span>
              </span>
              <button
                type="button"
                className="text-slate-500 hover:text-slate-300 p-0.5"
                aria-label={`Definition for ${c.data.title}`}
                onClick={() => setActiveTooltip(isHovered ? null : c.key)}
              >
                <Info className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="text-xl sm:text-2xl font-bold font-mono-num text-white tracking-tight">
              {c.data.value}
            </div>

            <div className="mt-1 flex items-center justify-between text-[11px]">
              <span
                className={`font-medium ${
                  c.data.deltaIsPositive ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {c.data.deltaText}
              </span>
            </div>

            {/* Accessible Info Tooltip */}
            {isHovered && (
              <div
                role="tooltip"
                className="absolute z-50 bottom-full left-0 right-0 mb-2 p-2.5 bg-slate-900 border border-white/20 rounded-md text-[11px] text-slate-300 shadow-xl"
              >
                <p className="font-semibold text-white mb-0.5">{c.data.title}</p>
                <p className="leading-snug">{c.data.definition}</p>
                <div className="mt-1.5 pt-1 border-t border-white/10 text-[10px] text-blue-400">
                  Calculated from filtered cohort
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};
