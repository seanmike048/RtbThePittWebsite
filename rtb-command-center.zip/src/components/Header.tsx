/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { FilterState, EngineConfig } from '../lib/pitt/engine.ts';
import {
  SlidersHorizontal,
  RotateCcw,
  Search,
  Settings,
  Eye,
  ShieldCheck,
  Building2,
  Globe,
  Radio,
  FileSpreadsheet
} from 'lucide-react';

interface HeaderProps {
  filters: FilterState;
  onFilterChange: (filters: FilterState) => void;
  config: EngineConfig;
  onOpenConfigModal: () => void;
  isPublisherView: boolean;
  onTogglePublisherView: (val: boolean) => void;
  cohortCount: number;
  partnerCount: number;
  activeTab: 'overview' | 'funnel' | 'waterfall' | 'data' | 'specs';
  onTabChange: (tab: 'overview' | 'funnel' | 'waterfall' | 'data' | 'specs') => void;
  selectedPublisherName?: string;
}

export const Header: React.FC<HeaderProps> = ({
  filters,
  onFilterChange,
  config,
  onOpenConfigModal,
  isPublisherView,
  onTogglePublisherView,
  cohortCount,
  partnerCount,
  activeTab,
  onTabChange,
  selectedPublisherName,
}) => {
  const [showFilterDrawer, setShowFilterDrawer] = useState(false);

  const resetFilters = () => {
    onFilterChange({
      businessUnit: 'ALL',
      amazonPartner: 'ALL',
      region: 'ALL',
      priority: 'ALL',
      status: 'ALL',
      dateRange: 'ALL',
      atRiskOnly: false,
      searchQuery: '',
    });
  };

  const hasActiveFilters =
    filters.businessUnit !== 'ALL' ||
    filters.amazonPartner !== 'ALL' ||
    filters.region !== 'ALL' ||
    filters.priority !== 'ALL' ||
    filters.status !== 'ALL' ||
    filters.dateRange !== 'ALL' ||
    filters.atRiskOnly ||
    filters.searchQuery !== '';

  return (
    <header className="border-b border-white/10 bg-[#0a0f1d] sticky top-0 z-40">
      {/* Top Bar: Brand, Navigation tabs, Actions */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Brand */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-9 h-9 rounded-lg bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400 font-black tracking-wider text-base">
              Ψ
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold tracking-tight text-white">
                  The Pitt
                </span>
                <span className="text-xs text-blue-400 font-medium px-2 py-0.5 rounded bg-blue-500/10 border border-blue-500/20">
                  Amazon DSP Disconnection Room
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                Equativ · AI Days 2026 Competitive Track
              </p>
            </div>
          </div>

          {/* Navigation Links (Editorial Title Case) */}
          <nav className="hidden md:flex items-center gap-1">
            <button
              onClick={() => onTabChange('overview')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeTab === 'overview'
                  ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Triage & Sankey Flow
            </button>
            <button
              onClick={() => onTabChange('waterfall')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeTab === 'waterfall'
                  ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Waterfall & What-If
            </button>
            <button
              onClick={() => onTabChange('funnel')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeTab === 'funnel'
                  ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Demand Funnel
            </button>
            <button
              onClick={() => onTabChange('data')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeTab === 'data'
                  ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Use Your Data
            </button>
            <button
              onClick={() => onTabChange('specs')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeTab === 'specs'
                  ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Specs & Contract
            </button>
          </nav>

          {/* Right Action Island: View toggle & Config */}
          <div className="flex items-center gap-2">
            {/* Publisher View Toggle */}
            <div className="flex items-center bg-slate-900/90 border border-white/10 rounded-lg p-0.5">
              <button
                onClick={() => onTogglePublisherView(false)}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors flex items-center gap-1.5 ${
                  !isPublisherView
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Internal Equativ Ops View (Full owner & revenue breakdown)"
              >
                <Building2 className="w-3.5 h-3.5" />
                <span>Internal Ops</span>
              </button>
              <button
                onClick={() => onTogglePublisherView(true)}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors flex items-center gap-1.5 ${
                  isPublisherView
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Publisher View (Privacy-filtered, remediation checklist & timeline)"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Publisher View</span>
              </button>
            </div>

            {/* Placeholder Thresholds Chip */}
            <button
              onClick={onOpenConfigModal}
              className="px-2.5 py-1.5 text-xs font-medium text-amber-300 bg-amber-500/10 border border-amber-500/30 rounded-lg hover:bg-amber-500/20 transition-colors flex items-center gap-1.5"
              title="Click to inspect and edit P0/P1/P2 thresholds and Amazon RPMBR reference values"
            >
              <Settings className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Placeholder thresholds</span>
            </button>
          </div>
        </div>

        {/* Cohort Summary Bar & Quick Filters */}
        <div className="py-2.5 border-t border-white/5 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-slate-300 flex-wrap">
            <span className="font-semibold text-white">Cohort:</span>
            <span className="font-mono-num text-blue-400">{cohortCount}</span> networks
            <span className="text-slate-600">·</span>
            <span className="font-mono-num text-blue-400">{partnerCount}</span> Amazon partner seats
            <span className="text-slate-600">·</span>
            <span className="text-slate-400">Snapshot: Oct 20, 2026</span>

            {isPublisherView && selectedPublisherName && (
              <>
                <span className="text-slate-600">·</span>
                <span className="text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded">
                  Viewing: {selectedPublisherName}
                </span>
              </>
            )}
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Quick search */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                placeholder="Search publisher, owner, partner..."
                value={filters.searchQuery}
                onChange={e => onFilterChange({ ...filters, searchQuery: e.target.value })}
                className="pl-8 pr-3 py-1 bg-slate-900 border border-white/10 rounded-md text-xs text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-blue-500 w-44 sm:w-56"
              />
            </div>

            {/* Filter Toggle Button */}
            <button
              onClick={() => setShowFilterDrawer(!showFilterDrawer)}
              className={`px-2.5 py-1 rounded-md border text-xs font-medium flex items-center gap-1.5 transition-colors ${
                hasActiveFilters || showFilterDrawer
                  ? 'bg-blue-600/20 text-blue-300 border-blue-500/40'
                  : 'bg-slate-900 text-slate-400 border-white/10 hover:text-slate-200'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Filters {hasActiveFilters && '(Active)'}</span>
            </button>

            {hasActiveFilters && (
              <button
                onClick={resetFilters}
                className="px-2 py-1 text-xs text-slate-400 hover:text-white flex items-center gap-1 transition-colors"
                title="Reset all filters"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset</span>
              </button>
            )}
          </div>
        </div>

        {/* Collapsible Filter Bar */}
        {showFilterDrawer && (
          <div className="py-3 px-3 mb-2 bg-[#0d1424] border border-white/10 rounded-lg grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 text-xs">
            {/* Business Unit */}
            <div>
              <label className="block text-[11px] text-slate-400 font-medium mb-1">
                Business Unit
              </label>
              <select
                value={filters.businessUnit}
                onChange={e => onFilterChange({ ...filters, businessUnit: e.target.value })}
                className="w-full bg-slate-900 border border-white/10 rounded p-1.5 text-slate-200 focus:outline-none focus:border-blue-500"
              >
                <option value="ALL">All Units</option>
                <option value="Web & Media">Web & Media</option>
                <option value="In-App & Gaming">In-App & Gaming</option>
                <option value="CTV & Video">CTV & Video</option>
              </select>
            </div>

            {/* Amazon Partner Seat */}
            <div>
              <label className="block text-[11px] text-slate-400 font-medium mb-1">
                Amazon Partner
              </label>
              <select
                value={filters.amazonPartner}
                onChange={e => onFilterChange({ ...filters, amazonPartner: e.target.value })}
                className="w-full bg-slate-900 border border-white/10 rounded p-1.5 text-slate-200 focus:outline-none focus:border-blue-500"
              >
                <option value="ALL">All Partners</option>
                <option value="437">437 · Amazon US</option>
                <option value="489">489 · Amazon EMEA</option>
                <option value="490">490 · Amazon UK</option>
                <option value="491">491 · Amazon APAC</option>
                <option value="492">492 · Global CTV</option>
              </select>
            </div>

            {/* Region */}
            <div>
              <label className="block text-[11px] text-slate-400 font-medium mb-1">
                Region
              </label>
              <select
                value={filters.region}
                onChange={e => onFilterChange({ ...filters, region: e.target.value })}
                className="w-full bg-slate-900 border border-white/10 rounded p-1.5 text-slate-200 focus:outline-none focus:border-blue-500"
              >
                <option value="ALL">All Regions</option>
                <option value="Americas">Americas</option>
                <option value="EMEA">EMEA</option>
                <option value="APAC">APAC</option>
              </select>
            </div>

            {/* Priority */}
            <div>
              <label className="block text-[11px] text-slate-400 font-medium mb-1">
                Priority
              </label>
              <select
                value={filters.priority}
                onChange={e => onFilterChange({ ...filters, priority: e.target.value })}
                className="w-full bg-slate-900 border border-white/10 rounded p-1.5 text-slate-200 focus:outline-none focus:border-blue-500"
              >
                <option value="ALL">All Priorities</option>
                <option value="P0">P0 (≥$10K Disconnected)</option>
                <option value="P1">P1 (≥$1K or ≥50% drop)</option>
                <option value="P2">P2 (Missing revenue / other)</option>
              </select>
            </div>

            {/* Status */}
            <div>
              <label className="block text-[11px] text-slate-400 font-medium mb-1">
                Status
              </label>
              <select
                value={filters.status}
                onChange={e => onFilterChange({ ...filters, status: e.target.value })}
                className="w-full bg-slate-900 border border-white/10 rounded p-1.5 text-slate-200 focus:outline-none focus:border-blue-500"
              >
                <option value="ALL">All Statuses</option>
                <option value="DISCONNECTED">Still Disconnected</option>
                <option value="RECONNECTED">Reconnected</option>
              </select>
            </div>

            {/* Date Range */}
            <div>
              <label className="block text-[11px] text-slate-400 font-medium mb-1">
                Cut Window
              </label>
              <select
                value={filters.dateRange}
                onChange={e => onFilterChange({ ...filters, dateRange: e.target.value as any })}
                className="w-full bg-slate-900 border border-white/10 rounded p-1.5 text-slate-200 focus:outline-none focus:border-blue-500"
              >
                <option value="ALL">All 365 Days</option>
                <option value="LAST_7D">Last 7 Days</option>
                <option value="LAST_30D">Last 30 Days</option>
                <option value="LAST_90D">Last 90 Days</option>
              </select>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
