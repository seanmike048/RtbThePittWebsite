/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { EnrichedDisconnection, getNetworkChecks, getNetworkReadiness } from '../lib/pitt/engine.ts';
import { CHECKS_DATA } from '../lib/pitt/data.ts';
import {
  ShieldAlert,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Clock,
  ArrowRight,
  Send,
  Building,
  AlertCircle,
  Sparkles,
} from 'lucide-react';

interface PublisherViewProps {
  cohort: EnrichedDisconnection[];
  currentNetworkId?: number;
  onSelectNetwork: (networkId: number) => void;
}

export const PublisherView: React.FC<PublisherViewProps> = ({
  cohort,
  currentNetworkId,
  onSelectNetwork,
}) => {
  // Only publisher networks
  const uniquePublishers = Array.from(new Set(cohort.map(c => c.PUBLISHER))).map(pub => {
    return cohort.find(c => c.PUBLISHER === pub)!;
  });

  const activeNetwork =
    cohort.find(c => c.NETWORK_ID === currentNetworkId) || uniquePublishers[0] || cohort[0];

  const checks = getNetworkChecks(activeNetwork.NETWORK_ID, CHECKS_DATA);
  const readiness = getNetworkReadiness(activeNetwork.NETWORK_ID);

  const [recrawlRequested, setRecrawlRequested] = useState(false);

  const failedChecks = checks.filter(c => c.window === 'AFTER' && c.result === 'FAIL');

  return (
    <div className="space-y-6">
      {/* Publisher Perspective Bar */}
      <div className="p-4 rounded-xl border border-emerald-500/30 bg-[#0d1424] flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 font-bold">
            <Building className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase tracking-wider text-emerald-400 font-bold">
                Publisher Partner Portal
              </span>
              <span className="text-slate-600">·</span>
              <span className="text-xs text-slate-400">Strict Privacy Mode</span>
            </div>
            <h2 className="text-base sm:text-lg font-bold text-white mt-0.5">
              Amazon DSP Technical Health & Reconnection Portal
            </h2>
          </div>
        </div>

        {/* Publisher Switcher for Demo */}
        <div className="flex items-center gap-2">
          <label htmlFor="pub-select" className="text-xs text-slate-400">
            Simulate Publisher View:
          </label>
          <select
            id="pub-select"
            value={activeNetwork.NETWORK_ID}
            onChange={e => {
              setRecrawlRequested(false);
              onSelectNetwork(Number(e.target.value));
            }}
            className="bg-slate-900 border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-500 font-medium"
          >
            {uniquePublishers.map(p => (
              <option key={p.NETWORK_ID} value={p.NETWORK_ID}>
                {p.PUBLISHER} (#{p.NETWORK_ID})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Network Status Card */}
      <div className="rounded-xl border border-white/10 bg-[#0d1424] p-5 shadow-2xl">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-white">
              {activeNetwork.PUBLISHER}
            </h1>
            <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
              <span>Network ID: <strong className="text-white font-mono-num">{activeNetwork.NETWORK_ID}</strong></span>
              <span>·</span>
              <span>Amazon DSP Seat: <strong className="text-white">{activeNetwork.PARTNER_NAME}</strong></span>
              <span>·</span>
              <span>Region: <strong className="text-white">{activeNetwork.REGION}</strong></span>
            </div>
          </div>

          <div>
            {activeNetwork.RECONNECTED_AT ? (
              <span className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 inline-flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                Connected & Active
              </span>
            ) : (
              <span className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-rose-500/20 text-rose-300 border border-rose-500/40 inline-flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-rose-400" />
                Amazon DSP Buying Suspended ({activeNetwork.daysSinceCut} days)
              </span>
            )}
          </div>
        </div>

        {/* Reconnection Timeline */}
        <div className="mt-6 pt-5 border-t border-white/5">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 block mb-3">
            Reconnection Timeline
          </span>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
            {/* Step 1 */}
            <div className="p-3 rounded-lg border border-white/10 bg-[#0a0f1d]">
              <div className="flex items-center gap-2 mb-1">
                <span className="w-5 h-5 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center font-bold text-[10px]">
                  1
                </span>
                <span className="font-semibold text-white">Issue Detected</span>
              </div>
              <p className="text-[11px] text-slate-400">
                DSP crawler flagged validation exception on {new Date(activeNetwork.CUT_AT).toLocaleDateString()}
              </p>
            </div>

            {/* Step 2 */}
            <div className="p-3 rounded-lg border border-white/10 bg-[#0a0f1d]">
              <div className="flex items-center gap-2 mb-1">
                <span className="w-5 h-5 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-[10px]">
                  2
                </span>
                <span className="font-semibold text-white">Technical Remediation</span>
              </div>
              <p className="text-[11px] text-slate-400">
                Publisher applies technical fixes to ads.txt / sellers.json or pre-bid wrapper
              </p>
            </div>

            {/* Step 3 */}
            <div className="p-3 rounded-lg border border-white/10 bg-[#0a0f1d]">
              <div className="flex items-center gap-2 mb-1">
                <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-[10px]">
                  3
                </span>
                <span className="font-semibold text-white">Crawler Recrawl</span>
              </div>
              <p className="text-[11px] text-slate-400">
                Automated Amazon crawler re-verifies declarations (typically 24–48 hours)
              </p>
            </div>

            {/* Step 4 */}
            <div className="p-3 rounded-lg border border-white/10 bg-[#0a0f1d]">
              <div className="flex items-center gap-2 mb-1">
                <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-[10px]">
                  4
                </span>
                <span className="font-semibold text-white">DSP Buying Restored</span>
              </div>
              <p className="text-[11px] text-slate-400">
                Amazon DSP resumes bid requests across all eligible auctions
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Failing Checks & Recommended Fixes */}
      <div className="rounded-xl border border-white/10 bg-[#0d1424] p-5 shadow-2xl">
        <h2 className="text-base sm:text-lg font-bold text-white mb-2">
          Diagnostic Audit & Required Remediation
        </h2>
        <p className="text-xs text-slate-400 mb-4">
          Review the checks below to clear active Amazon DSP buying restrictions.
        </p>

        {failedChecks.length > 0 ? (
          <div className="space-y-3">
            {failedChecks.map((fc, idx) => (
              <div
                key={idx}
                className="p-4 rounded-lg border border-rose-500/30 bg-rose-500/5 space-y-2"
              >
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <XCircle className="w-4 h-4 text-rose-400" />
                    <span className="font-bold text-white">Check Failure: {fc.check}</span>
                  </div>
                  <span className="font-mono-num text-[11px] text-rose-400">
                    Ref: {fc.evidence_ref}
                  </span>
                </div>

                <p className="text-xs text-slate-300 font-medium">
                  {fc.detail}
                </p>

                <div className="pt-2 border-t border-rose-500/20 text-xs">
                  <strong className="text-emerald-400">Recommended Action: </strong>
                  <span className="text-slate-300">
                    {fc.check === 'ADS_TXT' &&
                      'Ensure "equativ.com, ' + activeNetwork.NETWORK_ID + ', DIRECT, 00b0c441" is present in root /ads.txt and server returns HTTP 200.'}
                    {fc.check === 'SCO' &&
                      'Verify your seller_id=' + activeNetwork.NETWORK_ID + ' is published in sellers.json with correct is_passthrough flag.'}
                    {fc.check === 'IVT' &&
                      'Enable pre-bid IVT filtering (e.g. HUMAN or Moat) on paid marketing traffic campaigns.'}
                    {fc.check === 'BLOCKED_INVENTORY' &&
                      'Submit domain review ticket via Equativ support to verify brand safety categorization.'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-4 rounded-lg border border-emerald-500/30 bg-emerald-500/5 text-xs text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>All supply health checks are currently passing. No blocking errors detected.</span>
          </div>
        )}

        {/* Action: Request Recrawl */}
        <div className="mt-5 pt-4 border-t border-white/5 flex flex-wrap items-center justify-between gap-3">
          <p className="text-xs text-slate-400">
            Have you deployed the fixes above? Submit an expedited recrawl request to the Equativ Operations team.
          </p>

          <button
            onClick={() => setRecrawlRequested(true)}
            disabled={recrawlRequested}
            className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all ${
              recrawlRequested
                ? 'bg-emerald-600 text-white cursor-default'
                : 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg'
            }`}
          >
            {recrawlRequested ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>Expedited Recrawl Ticket Logged (#EQ-{activeNetwork.NETWORK_ID})</span>
              </>
            ) : (
              <>
                <Send className="w-4 h-4" />
                <span>Request Expedited Amazon DSP Recrawl</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* OpenRTB Readiness Checklist */}
      <div className="rounded-xl border border-white/10 bg-[#0d1424] p-5 shadow-2xl">
        <h2 className="text-base sm:text-lg font-bold text-white mb-2">
          OpenRTB Signal Compliance
        </h2>
        <p className="text-xs text-slate-400 mb-4">
          Signals passed in OpenRTB bid requests to optimize Amazon buyer fill rates.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 text-xs">
          {readiness.map(sig => (
            <div
              key={sig.signal}
              className="p-2.5 rounded-lg border border-white/5 bg-[#0a0f1d] flex items-center justify-between"
            >
              <div className="truncate pr-2">
                <span className="font-mono-num font-semibold text-white">{sig.signal}</span>
                {sig.category === 'content' && (
                  <span className="block text-[10px] text-slate-500">Not required until Jan 2027</span>
                )}
              </div>
              {sig.present ? (
                <span className="text-emerald-400 font-semibold flex items-center gap-1 text-[11px]">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Present
                </span>
              ) : (
                <span className="text-rose-400 font-semibold flex items-center gap-1 text-[11px]">
                  <XCircle className="w-3.5 h-3.5" /> Absent
                </span>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
