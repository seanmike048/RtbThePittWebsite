/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ShieldCheck, Cpu, Code2, AlertTriangle, FileText, CheckCircle2 } from 'lucide-react';

export const SpecsDocumentation: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="rounded-xl border border-white/10 bg-[#0d1424] p-6 shadow-2xl">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-9 h-9 rounded-lg bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400 font-bold">
            <FileText className="w-4 h-4" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white tracking-tight">
              The Pitt System Architecture & Specifications
            </h1>
            <p className="text-xs text-slate-400">
              Equativ AI Days 2026 Competitive Track · Technical Reference
            </p>
          </div>
        </div>
      </div>

      {/* Demo Scenarios Tested */}
      <div className="rounded-xl border border-white/10 bg-[#0d1424] p-6 shadow-2xl">
        <h2 className="text-base font-bold text-white mb-3 flex items-center gap-2">
          <Cpu className="w-4 h-4 text-blue-400" />
          Three Seed Scenarios (A, B, C)
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          {/* Scenario A */}
          <div className="p-4 rounded-lg border border-rose-500/30 bg-rose-500/5 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-rose-300">Scenario A</span>
              <span className="font-mono-num text-[11px] text-rose-400">Network #1082</span>
            </div>
            <p className="font-semibold text-white">ads.txt FAIL after cut (Clear Cause)</p>
            <p className="text-slate-400 leading-relaxed text-[11px]">
              Vox Media experienced a 404 crawl failure on 28 subdomains post-deployment.
              Check ADS_TXT fails in AFTER window. AI confidence is <strong>HIGH</strong>.
            </p>
          </div>

          {/* Scenario B */}
          <div className="p-4 rounded-lg border border-amber-500/30 bg-amber-500/5 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-amber-300">Scenario B</span>
              <span className="font-mono-num text-[11px] text-amber-400">Network #2011</span>
            </div>
            <p className="font-semibold text-white">IVT Spike / Ad Fraud Flag (Clear Cause)</p>
            <p className="text-slate-400 leading-relaxed text-[11px]">
              Playwire Gaming breached Amazon's strict 2.0% IVT ceiling (surging to 8.4%).
              DSP circuit-breaker isolated the inventory. AI confidence is <strong>HIGH</strong>.
            </p>
          </div>

          {/* Scenario C */}
          <div className="p-4 rounded-lg border border-blue-500/30 bg-blue-500/5 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-blue-300">Scenario C</span>
              <span className="font-mono-num text-[11px] text-blue-400">Network #4001</span>
            </div>
            <p className="font-semibold text-white">All Checks PASS or NO_DATA (Amazon-Specific)</p>
            <p className="text-slate-400 leading-relaxed text-[11px]">
              Penske Media supply checks are 100% PASS; auctions remain stable (+0.3%) but Amazon bid requests collapsed 91.4%.
              Rule enforced: AI confidence is capped at <strong>LOW</strong>, missing information is explicitly listed.
            </p>
          </div>
        </div>
      </div>

      {/* Guardrails & Invariants */}
      <div className="rounded-xl border border-white/10 bg-[#0d1424] p-6 shadow-2xl">
        <h2 className="text-base font-bold text-white mb-3 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          Strict Architectural Guardrails
        </h2>

        <div className="space-y-3 text-xs">
          <div className="p-3 bg-[#0a0f1d] rounded-lg border border-white/5 flex items-start gap-3">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-white">Strict Reconciliation Invariant:</strong>
              <p className="text-slate-400 mt-0.5">
                On load, <code>checkReconciliation(cohort)</code> verifies that:
                <br />
                <code>Sankey Total at Risk == KPI Strip Revenue At Risk == Sum of Risk Table Column</code>
                <br />
                Outputs <code>RECONCILIATION OK</code> to the browser console.
              </p>
            </div>
          </div>

          <div className="p-3 bg-[#0a0f1d] rounded-lg border border-white/5 flex items-start gap-3">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-white">Confidence Downgrade Rule:</strong>
              <p className="text-slate-400 mt-0.5">
                If no check for a network reports FAIL in the AFTER window, the AI Investigator is prohibited from showing HIGH confidence. It automatically demotes to MEDIUM or LOW.
              </p>
            </div>
          </div>

          <div className="p-3 bg-[#0a0f1d] rounded-lg border border-white/5 flex items-start gap-3">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-white">Unverified Evidence Detection:</strong>
              <p className="text-slate-400 mt-0.5">
                Every citation chip in the AI hypotheses is verified against the <code>CHECKS_DATA</code> table. Any hallucinated or mismatched reference renders an alert badge: <strong>Unverified evidence</strong>.
              </p>
            </div>
          </div>

          <div className="p-3 bg-[#0a0f1d] rounded-lg border border-white/5 flex items-start gap-3">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-white">Human Approval in Slack:</strong>
              <p className="text-slate-400 mt-0.5">
                Synthesized publisher notifications are locked strictly in read-only mode with the mandatory badge: <em>"Requires human approval in Slack"</em>. No automated dispatch button exists in the client.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
