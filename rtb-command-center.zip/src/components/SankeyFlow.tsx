/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect, useRef } from 'react';
import { sankey, sankeyLinkHorizontal, SankeyLayout, SankeyNode as D3SankeyNode, SankeyLink as D3SankeyLink } from 'd3-sankey';
import { SankeyData, SankeyNode, SankeyLink } from '../lib/pitt/engine.ts';
import { Table, Eye, Keyboard, HelpCircle } from 'lucide-react';

interface SankeyFlowProps {
  data: SankeyData;
  onSelectPublisher?: (publisherName: string) => void;
}

interface ComputedNode {
  id: string;
  name: string;
  category: 'BU' | 'PARTNER' | 'NETWORK' | 'CHECK' | 'STATUS';
  value: number;
  x0?: number;
  x1?: number;
  y0?: number;
  y1?: number;
  index?: number;
  depth?: number;
  height?: number;
}

interface ComputedLink {
  value: number;
  width?: number;
  y0?: number;
  y1?: number;
  source: ComputedNode;
  target: ComputedNode;
  index?: number;
}

export const SankeyFlow: React.FC<SankeyFlowProps> = ({ data, onSelectPublisher }) => {
  const [showTable, setShowTable] = useState(false);
  const [hoveredNodeId, setHoveredNodeId] = useState<string | null>(null);
  const [hoveredLinkId, setHoveredLinkId] = useState<string | null>(null);
  const [activeNodeIndex, setActiveNodeIndex] = useState<number | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);
  const [containerWidth, setContainerWidth] = useState(1050);

  useEffect(() => {
    const updateWidth = () => {
      if (containerRef.current) {
        setContainerWidth(Math.max(680, containerRef.current.clientWidth - 40));
      }
    };
    updateWidth();
    window.addEventListener('resize', updateWidth);
    return () => window.removeEventListener('resize', updateWidth);
  }, []);

  const height = 620;
  const totalRev = data.totalRevenueAtRisk || 1;

  // Compute D3 Sankey layout
  const { nodes, links } = useMemo(() => {
    if (!data.nodes.length || !data.links.length) {
      return { nodes: [] as ComputedNode[], links: [] as ComputedLink[] };
    }

    try {
      // Deep clone to avoid mutating engine data
      const graphNodes = data.nodes.map(n => ({ ...n }));
      const graphLinks = data.links.map(l => ({ ...l }));

      const layout = sankey<SankeyNode, SankeyLink>()
        .nodeId((d: any) => d.id)
        .nodeWidth(18)
        .nodePadding(12)
        .extent([[24, 24], [containerWidth - 24, height - 24]]);

      const computed = layout({
        nodes: graphNodes as any,
        links: graphLinks as any,
      });

      return {
        nodes: computed.nodes as unknown as ComputedNode[],
        links: computed.links as unknown as ComputedLink[],
      };
    } catch (e) {
      console.warn('Sankey compute warning:', e);
      return { nodes: [] as ComputedNode[], links: [] as ComputedLink[] };
    }
  }, [data, containerWidth, height]);

  // Color generator based on node category and failing check
  const getNodeColor = (node: ComputedNode) => {
    if (node.category === 'BU') return '#3b82f6'; // Equativ Blue
    if (node.category === 'PARTNER') return '#0284c7'; // Sky
    if (node.category === 'NETWORK') return '#6366f1'; // Indigo
    if (node.category === 'CHECK') {
      if (node.name.includes('ads.txt')) return '#ef4444'; // Red
      if (node.name.includes('Supply Chain')) return '#f97316'; // Orange
      if (node.name.includes('IVT')) return '#dc2626'; // Crimson
      if (node.name.includes('Blocked')) return '#d97706'; // Amber
      return '#64748b'; // Slate (No Data)
    }
    return '#ef4444'; // Still Disconnected
  };

  const getLinkColor = (link: ComputedLink) => {
    const isTargetFail = link.target.category === 'CHECK';
    if (isTargetFail) {
      if (link.target.name.includes('ads.txt')) return 'rgba(239, 68, 68, 0.45)';
      if (link.target.name.includes('Supply Chain')) return 'rgba(249, 115, 22, 0.45)';
      if (link.target.name.includes('IVT')) return 'rgba(220, 38, 38, 0.45)';
      if (link.target.name.includes('Blocked')) return 'rgba(217, 119, 6, 0.45)';
      return 'rgba(100, 116, 139, 0.35)';
    }
    return 'rgba(59, 130, 246, 0.35)';
  };

  // Keyboard navigation: Arrow keys step through nodes, Escape exits
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (nodes.length === 0) return;

      if (e.key === 'Escape') {
        setActiveNodeIndex(null);
        setHoveredNodeId(null);
      } else if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
        e.preventDefault();
        setActiveNodeIndex(prev => {
          const next = prev === null ? 0 : (prev + 1) % nodes.length;
          setHoveredNodeId(nodes[next].id);
          return next;
        });
      } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
        e.preventDefault();
        setActiveNodeIndex(prev => {
          const next = prev === null ? nodes.length - 1 : (prev - 1 + nodes.length) % nodes.length;
          setHoveredNodeId(nodes[next].id);
          return next;
        });
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [nodes]);

  const activeNode = activeNodeIndex !== null ? nodes[activeNodeIndex] : null;

  return (
    <div
      ref={containerRef}
      className="rounded-xl border border-white/10 bg-[#0d1424] p-5 shadow-2xl relative overflow-hidden"
    >
      {/* Section Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-blue-400">
              Money Flow · Risk Topology
            </span>
            <span className="text-slate-600">·</span>
            <span className="text-xs text-slate-400">Northwind Animated Ribbon</span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight mt-0.5">
            Revenue at Risk Flow
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Business Unit → Amazon Partner Seat → Publisher Network → Primary Failing Check → Status
          </p>
        </div>

        {/* Action buttons: Table equivalent & keyboard hint */}
        <div className="flex items-center gap-2.5">
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 bg-slate-900 border border-white/10 rounded-md text-[11px] text-slate-400">
            <Keyboard className="w-3.5 h-3.5 text-blue-400" />
            <span>Use Arrow keys to step · Esc to exit</span>
          </div>

          <button
            onClick={() => setShowTable(!showTable)}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors flex items-center gap-1.5 ${
              showTable
                ? 'bg-blue-600/20 text-blue-400 border-blue-500/40'
                : 'bg-slate-900 text-slate-300 border-white/10 hover:border-white/30'
            }`}
            aria-label="Toggle screen-reader accessible table view"
          >
            <Table className="w-3.5 h-3.5" />
            <span>{showTable ? 'View Flow Diagram' : 'Accessible Table'}</span>
          </button>
        </div>
      </div>

      {/* Selected Node HUD Banner */}
      {activeNode && (
        <div className="mb-3 px-3 py-2 bg-blue-950/60 border border-blue-500/30 rounded-lg flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-blue-300">{activeNode.name}</span>
            <span className="text-slate-400">({activeNode.category})</span>
          </div>
          <div className="flex items-center gap-3 font-mono-num">
            <span className="text-white font-bold">${(activeNode.value / 1000).toFixed(1)}K/wk</span>
            <span className="text-slate-400">
              {((activeNode.value / totalRev) * 100).toFixed(1)}% of total at risk
            </span>
          </div>
        </div>
      )}

      {/* View: Accessible Table Equivalent */}
      {showTable ? (
        <div className="overflow-x-auto max-h-[460px] rounded-lg border border-white/10">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="sticky top-0 bg-slate-900 border-b border-white/10 text-slate-300 font-semibold">
              <tr>
                <th className="py-2.5 px-3">Business Unit</th>
                <th className="py-2.5 px-3">Amazon Partner Seat</th>
                <th className="py-2.5 px-3">Publisher Network</th>
                <th className="py-2.5 px-3">Primary Failing Check</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Revenue at Risk</th>
                <th className="py-2.5 px-3 text-right">Cohort Share</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 bg-[#0a0f1d] text-slate-300 font-mono-num">
              {data.accessibleTableRows.map((row, idx) => (
                <tr key={idx} className="hover:bg-white/5 transition-colors">
                  <td className="py-2 px-3 font-sans text-slate-200">{row.stage1}</td>
                  <td className="py-2 px-3 font-sans text-slate-300">{row.stage2}</td>
                  <td className="py-2 px-3 font-sans font-medium text-white">
                    <button
                      onClick={() => onSelectPublisher && onSelectPublisher(row.stage3)}
                      className="text-left text-blue-400 hover:underline"
                    >
                      {row.stage3}
                    </button>
                  </td>
                  <td className="py-2 px-3 font-sans">
                    <span className="px-2 py-0.5 rounded text-[11px] bg-rose-500/10 text-rose-300 border border-rose-500/20">
                      {row.stage4}
                    </span>
                  </td>
                  <td className="py-2 px-3 font-sans text-rose-400">{row.stage5}</td>
                  <td className="py-2 px-3 text-right font-bold text-white">
                    ${row.value.toLocaleString()}
                  </td>
                  <td className="py-2 px-3 text-right text-slate-400">
                    {((row.value / totalRev) * 100).toFixed(1)}%
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-slate-900 border-t border-white/10 font-bold text-white font-mono-num">
              <tr>
                <td colSpan={5} className="py-2 px-3 font-sans">Total Revenue at Risk</td>
                <td className="py-2 px-3 text-right text-rose-400">${totalRev.toLocaleString()}</td>
                <td className="py-2 px-3 text-right">100.0%</td>
              </tr>
            </tfoot>
          </table>
        </div>
      ) : (
        /* View: Interactive D3 Sankey SVG */
        <div className="relative overflow-x-auto">
          <svg
            width={containerWidth}
            height={height}
            className="w-full select-none"
            style={{ minWidth: '680px' }}
          >
            <defs>
              <linearGradient id="linkGrad" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.5" />
                <stop offset="100%" stopColor="#ef4444" stopOpacity="0.5" />
              </linearGradient>
            </defs>

            {/* Links / Ribbons */}
            <g className="links" fill="none">
              {links.map((link, i) => {
                const pathGen = sankeyLinkHorizontal();
                const pathStr = pathGen(link as any) || '';
                const isHovered =
                  hoveredLinkId === `${link.source.id}->${link.target.id}` ||
                  hoveredNodeId === link.source.id ||
                  hoveredNodeId === link.target.id;

                const linkColor = getLinkColor(link);

                return (
                  <path
                    key={i}
                    d={pathStr}
                    stroke={linkColor}
                    strokeWidth={Math.max(2, link.width || 1)}
                    strokeOpacity={isHovered ? 0.85 : 0.4}
                    className="transition-all duration-150 cursor-pointer"
                    onMouseEnter={() => setHoveredLinkId(`${link.source.id}->${link.target.id}`)}
                    onMouseLeave={() => setHoveredLinkId(null)}
                  >
                    <title>
                      {`${link.source.name} → ${link.target.name}\n$${link.value.toLocaleString()}/wk (${(
                        (link.value / totalRev) *
                        100
                      ).toFixed(1)}% of total)`}
                    </title>
                  </path>
                );
              })}
            </g>

            {/* Nodes */}
            <g className="nodes">
              {nodes.map(node => {
                const isHovered = hoveredNodeId === node.id;
                const nodeColor = getNodeColor(node);
                const x0 = node.x0 ?? 0;
                const x1 = node.x1 ?? 0;
                const y0 = node.y0 ?? 0;
                const y1 = node.y1 ?? 0;
                const nodeHeight = Math.max(4, y1 - y0);
                const nodeWidth = x1 - x0;

                const isLeftHalf = x0 < containerWidth / 2;

                return (
                  <g
                    key={node.id}
                    className="cursor-pointer group"
                    onClick={() => {
                      if (node.category === 'NETWORK' && onSelectPublisher) {
                        onSelectPublisher(node.name);
                      }
                      setHoveredNodeId(isHovered ? null : node.id);
                    }}
                    onMouseEnter={() => setHoveredNodeId(node.id)}
                    onMouseLeave={() => setHoveredNodeId(null)}
                  >
                    {/* Node Bar */}
                    <rect
                      x={x0}
                      y={y0}
                      width={nodeWidth}
                      height={nodeHeight}
                      fill={nodeColor}
                      rx={3}
                      stroke={isHovered ? '#ffffff' : 'rgba(255,255,255,0.2)'}
                      strokeWidth={isHovered ? 2 : 1}
                      className="transition-all duration-150"
                    />

                    {/* Node Label */}
                    <text
                      x={
                        node.category === 'STATUS'
                          ? x0 - 8
                          : node.category === 'CHECK'
                          ? x1 + 6
                          : isLeftHalf
                          ? x1 + 6
                          : x0 - 6
                      }
                      y={y0 + nodeHeight / 2}
                      dy="0.35em"
                      textAnchor={
                        node.category === 'STATUS'
                          ? 'end'
                          : node.category === 'CHECK'
                          ? 'start'
                          : isLeftHalf
                          ? 'start'
                          : 'end'
                      }
                      style={{
                        paintOrder: 'stroke',
                        stroke: '#0d1424',
                        strokeWidth: '3px',
                        strokeLinejoin: 'round',
                      }}
                      className={`text-[11px] font-medium transition-colors ${
                        isHovered ? 'fill-white font-bold' : 'fill-slate-200'
                      }`}
                    >
                      {node.name.length > 22 ? `${node.name.slice(0, 21)}…` : node.name}
                      <tspan className="fill-slate-400 font-mono-num text-[10px] ml-1">
                        {' '}
                        ${(node.value / 1000).toFixed(1)}K (
                        {((node.value / totalRev) * 100).toFixed(0)}%)
                      </tspan>
                    </text>
                  </g>
                );
              })}
            </g>
          </svg>

          {/* Flow Legend */}
          <div className="mt-3 pt-3 border-t border-white/5 flex flex-wrap items-center justify-between text-[11px] text-slate-400 gap-3">
            <div className="flex items-center gap-4 flex-wrap">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded bg-blue-500 inline-block" />
                Business Unit
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded bg-sky-500 inline-block" />
                Amazon Seat
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded bg-indigo-500 inline-block" />
                Publisher Network
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded bg-rose-500 inline-block" />
                Failing Check
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded bg-slate-500 inline-block" />
                No Data
              </span>
            </div>
            <div className="font-mono-num text-slate-400">
              Total Cohort At Risk: <strong className="text-white">${totalRev.toLocaleString()}/wk</strong>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
