/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Database, FileCode, CheckCircle, Copy, Terminal, Shield, ArrowDownCircle } from 'lucide-react';

export const UseYourDataModal: React.FC = () => {
  const [copiedSnippet, setCopiedSnippet] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSnippet(id);
    setTimeout(() => setCopiedSnippet(null), 2000);
  };

  const snowflakeSqlSnippet = `-- Snowflake Query to export Disconnection Alert View for The Pitt
SELECT 
    PARTNER_ID,
    PARTNER_NAME,
    PUBLISHER,
    NETWORK_ID,
    BUSINESS_UNIT,
    USERNAME,
    CUT_AT,
    RECONNECTED_AT,
    SPEND_7D_BEFORE
FROM ANALYTICS.PUBLIC.VIEW_DISCONNECTION_ALERT_365DAYS
WHERE CUT_AT >= DATEADD('day', -365, CURRENT_TIMESTAMP())
ORDER BY SPEND_7D_BEFORE DESC NULLS LAST;`;

  const dataContractSnippet = `// In src/lib/pitt/data.ts:
export interface DisconnectionAlertRow {
  PARTNER_ID: number;         // Amazon Partner Seat ID (e.g. 437, 489, 490)
  PARTNER_NAME: string;       // Name of seat (e.g. 'Amazon DSP US')
  PUBLISHER: string;          // Publisher Network Name
  NETWORK_ID: number;         // Equativ Network ID
  BUSINESS_UNIT: string;      // 'Web & Media' | 'CTV & Video' | 'In-App & Gaming'
  USERNAME: string;           // Equativ Owner Email
  CUT_AT: string;             // ISO 8601 Timestamp
  RECONNECTED_AT: string|null;// null = still disconnected. Never infer it!
  SPEND_7D_BEFORE: number|null; // 7-day spend run-rate prior to cut
}`;

  return (
    <div className="space-y-6">
      {/* Overview Card */}
      <div className="rounded-xl border border-white/10 bg-[#0d1424] p-6 shadow-2xl">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-lg bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white tracking-tight">
              Using Your Own Production Data in The Pitt
            </h1>
            <p className="text-xs text-slate-400">
              Zero-server architecture · Static type safety · Snowflake view mapping
            </p>
          </div>
        </div>

        <div className="prose prose-invert max-w-none text-xs text-slate-300 space-y-3 leading-relaxed">
          <p>
            The Pitt is architected strictly to decouple raw data storage from analytical derivations.
            <strong> ALL raw data lives in exactly one file: <code>src/lib/pitt/data.ts</code></strong>, and 
            <strong> ALL thresholds, labels, priority rules, and derived selectors live in <code>src/lib/pitt/engine.ts</code></strong>.
          </p>
          <p>
            No React component computes metrics or transforms data directly; every KPI card, Sankey flow, waterfall step, and table row renders selectors derived by <code>engine.ts</code> from the filtered cohort.
          </p>
        </div>
      </div>

      {/* Field Contract Section */}
      <div className="rounded-xl border border-white/10 bg-[#0d1424] p-6 shadow-2xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <FileCode className="w-4 h-4 text-blue-400" />
              1. Disconnection Alert Contract (Snowflake View)
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Source: <code>ANALYTICS.PUBLIC.VIEW_DISCONNECTION_ALERT_365DAYS</code>
            </p>
          </div>

          <button
            onClick={() => copyToClipboard(dataContractSnippet, 'contract')}
            className="px-2.5 py-1 rounded bg-slate-900 border border-white/10 text-xs text-slate-300 hover:text-white flex items-center gap-1.5"
          >
            {copiedSnippet === 'contract' ? (
              <>
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy TypeScript Contract</span>
              </>
            )}
          </button>
        </div>

        <pre className="p-4 bg-slate-950 rounded-lg border border-white/5 font-mono-num text-xs text-blue-300 overflow-x-auto leading-relaxed">
          {dataContractSnippet}
        </pre>

        {/* Contract Guardrails */}
        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="p-3 bg-[#0a0f1d] rounded-lg border border-white/5">
            <strong className="text-rose-400 block mb-1">RECONNECTED_AT Guardrail:</strong>
            <p className="text-slate-400 text-[11px]">
              <code>RECONNECTED_AT = null</code> strictly denotes that a network is currently cut from Amazon DSP. Never infer reconnect timestamps from traffic spikes.
            </p>
          </div>

          <div className="p-3 bg-[#0a0f1d] rounded-lg border border-white/5">
            <strong className="text-amber-400 block mb-1">SPEND_7D_BEFORE Nullability:</strong>
            <p className="text-slate-400 text-[11px]">
              If <code>SPEND_7D_BEFORE</code> is null, the priority engine classifies the network as <strong>P2 (Missing revenue)</strong> and renders "No data", never $0.
            </p>
          </div>
        </div>
      </div>

      {/* Snowflake Extraction Guide */}
      <div className="rounded-xl border border-white/10 bg-[#0d1424] p-6 shadow-2xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-400" />
              2. How to Export from Snowflake
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Execute in your Snowflake Worksheets or CLI to extract the latest 365-day cohort
            </p>
          </div>

          <button
            onClick={() => copyToClipboard(snowflakeSqlSnippet, 'sql')}
            className="px-2.5 py-1 rounded bg-slate-900 border border-white/10 text-xs text-slate-300 hover:text-white flex items-center gap-1.5"
          >
            {copiedSnippet === 'sql' ? (
              <>
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">Copied SQL</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy Snowflake SQL</span>
              </>
            )}
          </button>
        </div>

        <pre className="p-4 bg-slate-950 rounded-lg border border-white/5 font-mono-num text-xs text-emerald-300 overflow-x-auto leading-relaxed">
          {snowflakeSqlSnippet}
        </pre>

        <div className="mt-4 p-4 rounded-lg bg-blue-950/30 border border-blue-500/20 text-xs text-slate-300 space-y-2">
          <strong className="text-blue-300 block">Updating the Codebase with Exported Data:</strong>
          <ol className="list-decimal list-inside space-y-1 text-slate-400">
            <li>Export the Snowflake query results as JSON or CSV.</li>
            <li>Open <code>src/lib/pitt/data.ts</code>.</li>
            <li>Replace <code>DISCONNECTIONS_DATA</code> with your exported rows.</li>
            <li>Set <code>IS_SYNTHETIC_DEMO_DATA = false</code> to dismiss the synthetic demo data banner.</li>
            <li>Recompile or test with <code>npm test</code> (runs <code>node --test</code>) to verify the automatic reconciliation invariant!</li>
          </ol>
        </div>
      </div>
    </div>
  );
};
