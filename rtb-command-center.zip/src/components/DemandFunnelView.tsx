/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { FunnelStageMetric, deriveDemandFunnel, EnrichedDisconnection } from '../lib/pitt/engine.ts';
import { Filter, ArrowDown, ChevronRight, Layers, Table } from 'lucide-react';

interface DemandFunnelViewProps {
  cohort: EnrichedDisconnection[];
  selectedNetworkId?: number | null;
  onSelectNetwork?: (networkId: number | null) => void;
}

export const DemandFunnelView: React.FC<DemandFunnelViewProps> = ({
  cohort,
  selectedNetworkId,
  onSelectNetwork,
}) => {
  const [localNetworkId, setLocalNetworkId] = useState<number | null>(selectedNetworkId ?? null);
  const [showTable, setShowTable] = useState(false);

  const activeNetId = selectedNetworkId !== undefined ? selectedNetworkId : localNetworkId;
  const stages: FunnelStageMetric[] = deriveDemandFunnel(activeNetId, cohort);

  const formatNumber = (num: number) => {
    if (num >= 1_000_000) return `${(num / 1_000_000).toFixed(2)}M`;
    if (num >= 1_000) return `${(num / 1_000).toFixed(1)}K`;
    return num.toLocaleString();
  };

  const handleSelect = (val: string) => {
    const netId = val === 'COHORT' ? null : Number(val);
    setLocalNetworkId(netId);
    if (onSelectNetwork) onSelectNetwork(netId);
  };

  const selectedNetObj = cohort.find(c => c.NETWORK_ID === activeNetId);

  return (
    <div className="rounded-xl border border-white/10 bg-[#0d1424] p-5 shadow-2xl">
      {/* Header & Network Selector */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-blue-400">
              Demand Funnel · Crestline Architecture
            </span>
            <span className="text-slate-600">·</span>
            <span className="text-xs text-slate-400">Ad Server to DSP Conversion</span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight mt-0.5">
            End-to-End Demand Funnel & Drop Triage
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Diagnose exactly where Amazon DSP bids drop from auctions through impressions
          </p>
        </div>

        {/* Network Picker & Table toggle */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <label htmlFor="funnel-net-select" className="text-xs text-slate-400">
              Funnel Target:
            </label>
            <select
              id="funnel-net-select"
              value={activeNetId === null ? 'COHORT' : String(activeNetId)}
              onChange={e => handleSelect(e.target.value)}
              className="bg-slate-900 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
            >
              <option value="COHORT">Whole Cohort (Aggregate)</option>
              {cohort.map(c => (
                <option key={c.NETWORK_ID} value={String(c.NETWORK_ID)}>
                  #{c.NETWORK_ID} · {c.PUBLISHER}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={() => setShowTable(!showTable)}
            className="px-3 py-1.5 text-xs font-medium rounded-lg border border-white/10 bg-slate-900 text-slate-300 hover:border-white/30 flex items-center gap-1.5"
          >
            <Table className="w-3.5 h-3.5" />
            <span>{showTable ? 'View Funnel Cards' : 'View Funnel Table'}</span>
          </button>
        </div>
      </div>

      {selectedNetObj && (
        <div className="mb-4 px-3 py-2 bg-blue-950/40 border border-blue-500/20 rounded-lg text-xs text-slate-300 flex items-center justify-between">
          <div>
            <strong className="text-white">{selectedNetObj.PUBLISHER}</strong> · Network #{selectedNetObj.NETWORK_ID} ({selectedNetObj.PARTNER_NAME})
          </div>
          <span className="text-rose-400 font-mono-num font-semibold">
            {selectedNetObj.ONE_LINE_REASON}
          </span>
        </div>
      )}

      {/* Crestline Stage Cards */}
      {!showTable ? (
        <div className="space-y-3">
          {stages.map((stage, idx) => {
            const isFirst = idx === 0;
            const widthPct = Math.max(15, Math.min(100, (stage.count / (stages[0].count || 1)) * 100));

            return (
              <div
                key={stage.stage}
                className="p-4 rounded-lg border border-white/10 bg-[#0a0f1d] hover:border-white/20 transition-all"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400 font-bold text-xs">
                      {idx + 1}
                    </span>
                    <h3 className="text-sm font-bold text-white">{stage.stage}</h3>
                  </div>

                  <div className="flex items-center gap-4 text-xs font-mono-num">
                    <div>
                      <span className="text-slate-400">Intake: </span>
                      <strong className="text-white text-sm">{formatNumber(stage.count)}</strong>
                    </div>

                    {!isFirst && (
                      <div className="flex items-center gap-1.5">
                        <span className="text-slate-400">Continued: </span>
                        <span className={`font-semibold ${stage.retentionPctFromPrev > 30 ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {stage.retentionPctFromPrev}%
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Progress Ribbon */}
                <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden mb-3">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      stage.retentionPctFromPrev > 30 ? 'bg-blue-500' : 'bg-rose-500'
                    }`}
                    style={{ width: `${widthPct}%` }}
                  />
                </div>

                {/* Drop Reasons & Triage */}
                {!isFirst && stage.dropCount > 0 && (
                  <div className="mt-2 pt-2 border-t border-white/5 text-xs">
                    <div className="flex items-center justify-between text-slate-400 mb-1.5">
                      <span className="flex items-center gap-1 text-rose-400 font-medium">
                        <ArrowDown className="w-3.5 h-3.5" />
                        Dropped: {formatNumber(stage.dropCount)} ({(100 - stage.retentionPctFromPrev).toFixed(1)}%)
                      </span>
                      <span className="text-[11px] text-slate-500">Top Drop Reasons</span>
                    </div>

                    <div className="space-y-1">
                      {stage.dropReasons.length > 0 ? (
                        stage.dropReasons.map((dr, drIdx) => (
                          <div
                            key={drIdx}
                            className="flex items-center justify-between text-[11px] bg-slate-900/60 px-2.5 py-1 rounded text-slate-300"
                          >
                            <span className="truncate pr-2">• {dr.reason}</span>
                            <span className="font-mono-num font-semibold text-rose-300 shrink-0">
                              -{formatNumber(dr.count)}
                            </span>
                          </div>
                        ))
                      ) : (
                        <div className="text-[11px] text-slate-500 italic">
                          No major drops recorded at this stage.
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ) : (
        /* Accessible Stage Table Equivalent */
        <div className="overflow-x-auto rounded-lg border border-white/10">
          <table className="w-full text-left text-xs border-collapse font-sans">
            <thead className="bg-slate-900 border-b border-white/10 text-slate-300 font-semibold">
              <tr>
                <th className="py-2.5 px-3">Stage #</th>
                <th className="py-2.5 px-3">Funnel Stage</th>
                <th className="py-2.5 px-3 text-right">Volume</th>
                <th className="py-2.5 px-3 text-right">Continued %</th>
                <th className="py-2.5 px-3 text-right">Dropped Volume</th>
                <th className="py-2.5 px-3">Primary Drop Reason</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 bg-[#0a0f1d] text-slate-300 font-mono-num">
              {stages.map((stage, idx) => (
                <tr key={stage.stage} className="hover:bg-white/5">
                  <td className="py-2.5 px-3 text-slate-400 font-sans">{idx + 1}</td>
                  <td className="py-2.5 px-3 font-semibold text-white font-sans">{stage.stage}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-white">
                    {stage.count.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    {idx === 0 ? '100.0%' : `${stage.retentionPctFromPrev}%`}
                  </td>
                  <td className="py-2.5 px-3 text-right text-rose-400">
                    {stage.dropCount > 0 ? stage.dropCount.toLocaleString() : '0'}
                  </td>
                  <td className="py-2.5 px-3 font-sans text-slate-400">
                    {stage.dropReasons[0] ? stage.dropReasons[0].reason : 'Baseline intake'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
