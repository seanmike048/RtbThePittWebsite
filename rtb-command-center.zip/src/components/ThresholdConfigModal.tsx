/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { EngineConfig, DEFAULT_ENGINE_CONFIG } from '../lib/pitt/engine.ts';
import { X, Settings, RotateCcw, Check, DollarSign } from 'lucide-react';

interface ThresholdConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: EngineConfig;
  onSaveConfig: (newConfig: EngineConfig) => void;
}

export const ThresholdConfigModal: React.FC<ThresholdConfigModalProps> = ({
  isOpen,
  onClose,
  config,
  onSaveConfig,
}) => {
  const [formConfig, setFormConfig] = useState<EngineConfig>({ ...config });

  if (!isOpen) return null;

  const handleReset = () => {
    setFormConfig({ ...DEFAULT_ENGINE_CONFIG });
  };

  const handleSave = () => {
    onSaveConfig(formConfig);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
      <div className="w-full max-w-xl rounded-xl border border-white/20 bg-[#0d1424] p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <Settings className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white">
                Engine Thresholds & Reference Rates
              </h2>
              <p className="text-xs text-slate-400">
                Configure priority rules and regional benchmark indices (stored in engine.ts)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Priority Engine Thresholds */}
        <div className="space-y-4 text-xs">
          <div>
            <span className="font-semibold text-white block mb-2 uppercase tracking-wider text-[11px] text-blue-400">
              Priority Engine Classification
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-3 bg-slate-900 rounded-lg border border-white/10">
                <label className="text-slate-300 font-medium block mb-1">
                  P0 Minimum 7d Spend ($):
                </label>
                <div className="relative">
                  <DollarSign className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input
                    type="number"
                    value={formConfig.thresholds.p0MinSpend7d}
                    onChange={e =>
                      setFormConfig({
                        ...formConfig,
                        thresholds: {
                          ...formConfig.thresholds,
                          p0MinSpend7d: Number(e.target.value),
                        },
                      })
                    }
                    className="w-full pl-8 pr-3 py-1.5 bg-[#0a0f1d] border border-white/10 rounded font-mono-num text-white text-xs"
                  />
                </div>
                <span className="text-[10px] text-slate-500 mt-1 block">
                  Rule: Still disconnected AND spend &ge; threshold
                </span>
              </div>

              <div className="p-3 bg-slate-900 rounded-lg border border-white/10">
                <label className="text-slate-300 font-medium block mb-1">
                  P1 Minimum 7d Spend ($):
                </label>
                <div className="relative">
                  <DollarSign className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input
                    type="number"
                    value={formConfig.thresholds.p1MinSpend7d}
                    onChange={e =>
                      setFormConfig({
                        ...formConfig,
                        thresholds: {
                          ...formConfig.thresholds,
                          p1MinSpend7d: Number(e.target.value),
                        },
                      })
                    }
                    className="w-full pl-8 pr-3 py-1.5 bg-[#0a0f1d] border border-white/10 rounded font-mono-num text-white text-xs"
                  />
                </div>
                <span className="text-[10px] text-slate-500 mt-1 block">
                  Rule: Spend &ge; threshold OR drop &ge; 50%
                </span>
              </div>
            </div>
          </div>

          {/* Amazon RPMBR Reference by Region */}
          <div className="pt-2 border-t border-white/10">
            <span className="font-semibold text-white block mb-2 uppercase tracking-wider text-[11px] text-blue-400">
              Amazon RPMBR Reference Benchmarks ($)
            </span>

            <div className="grid grid-cols-3 gap-3">
              <div className="p-3 bg-slate-900 rounded-lg border border-white/10">
                <label className="text-slate-300 font-medium block mb-1">
                  Americas:
                </label>
                <input
                  type="number"
                  value={formConfig.amazonRpmbrReference.Americas}
                  onChange={e =>
                    setFormConfig({
                      ...formConfig,
                      amazonRpmbrReference: {
                        ...formConfig.amazonRpmbrReference,
                        Americas: Number(e.target.value),
                      },
                    })
                  }
                  className="w-full px-2.5 py-1.5 bg-[#0a0f1d] border border-white/10 rounded font-mono-num text-white text-xs"
                />
              </div>

              <div className="p-3 bg-slate-900 rounded-lg border border-white/10">
                <label className="text-slate-300 font-medium block mb-1">
                  EMEA:
                </label>
                <input
                  type="number"
                  value={formConfig.amazonRpmbrReference.EMEA}
                  onChange={e =>
                    setFormConfig({
                      ...formConfig,
                      amazonRpmbrReference: {
                        ...formConfig.amazonRpmbrReference,
                        EMEA: Number(e.target.value),
                      },
                    })
                  }
                  className="w-full px-2.5 py-1.5 bg-[#0a0f1d] border border-white/10 rounded font-mono-num text-white text-xs"
                />
              </div>

              <div className="p-3 bg-slate-900 rounded-lg border border-white/10">
                <label className="text-slate-300 font-medium block mb-1">
                  APAC:
                </label>
                <input
                  type="number"
                  value={formConfig.amazonRpmbrReference.APAC}
                  onChange={e =>
                    setFormConfig({
                      ...formConfig,
                      amazonRpmbrReference: {
                        ...formConfig.amazonRpmbrReference,
                        APAC: Number(e.target.value),
                      },
                    })
                  }
                  className="w-full px-2.5 py-1.5 bg-[#0a0f1d] border border-white/10 rounded font-mono-num text-white text-xs"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="pt-4 border-t border-white/10 flex items-center justify-between">
          <button
            onClick={handleReset}
            className="px-3 py-1.5 rounded-lg border border-white/10 text-xs text-slate-400 hover:text-white flex items-center gap-1.5 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restore Defaults</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg border border-white/10 text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-xs font-semibold text-white flex items-center gap-1.5 shadow-md"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Apply Thresholds</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
