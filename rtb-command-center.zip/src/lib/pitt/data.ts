/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * The Pitt · Amazon DSP Disconnection Room
 * Source file: src/lib/pitt/data.ts
 * ALL raw data lives here (typed arrays).
 * Source view: ANALYTICS.PUBLIC.VIEW_DISCONNECTION_ALERT_365DAYS
 */

export interface DisconnectionAlertRow {
  PARTNER_ID: number;
  PARTNER_NAME: string;
  PUBLISHER: string;
  NETWORK_ID: number;
  BUSINESS_UNIT: 'Web & Media' | 'CTV & Video' | 'In-App & Gaming';
  USERNAME: string; // Owner
  CUT_AT: string; // ISO 8601 Timestamp
  RECONNECTED_AT: string | null; // null means still disconnected
  SPEND_7D_BEFORE: number | null; // Weekly run-rate before cut; null if unmonitored
  REGION: 'Americas' | 'EMEA' | 'APAC';
  REVENUE_DROP_PCT: number; // Percentage drop post-cut (e.g. 100% if cut, or partial)
  ONE_LINE_REASON: string;
}

export type CheckType = 'ADS_TXT' | 'SCO' | 'BLOCKED_INVENTORY' | 'IVT';
export type CheckWindow = 'BEFORE' | 'AFTER';
export type CheckResult = 'PASS' | 'FAIL' | 'NO_DATA';

export interface CheckRow {
  network_id: number;
  check: CheckType;
  window: CheckWindow;
  result: CheckResult;
  evidence_ref: string;
  detail: string;
}

export interface TrafficMetricRow {
  network_id: number;
  metric: string;
  partner_name: string;
  partner_ids: number[];
  change_pct: number;
  before: number;
  after: number;
  period: string;
  source: string;
}

export interface FunnelDropReason {
  stage: 'Auctions' | 'Bid requests' | 'Bids' | 'Wins' | 'Impressions';
  reason: string;
  count: number;
}

export interface DemandFunnelRow {
  network_id: number;
  auctions: number;
  bid_requests: number;
  bids: number;
  wins: number;
  impressions: number;
  drop_reasons: FunnelDropReason[];
}

export interface Hypothesis {
  label: string;
  confidence: 'LOW' | 'MEDIUM' | 'HIGH';
  evidence_refs: string[];
  missing_info: string[];
}

export interface AIInvestigationRow {
  network_id: number;
  hypotheses: Hypothesis[];
  draft_message: string;
  validation: {
    passed: boolean;
    ai_output_accepted: boolean;
    fallback_fields: string[];
  };
}

export interface OpenRtbSignalStatus {
  signal: string;
  category: 'content' | 'video' | 'app' | 'imp' | 'regs' | 'device';
  present: boolean;
  valueDescription?: string;
}

export interface ReadinessCheckRow {
  network_id: number;
  signals: OpenRtbSignalStatus[];
}

export const IS_SYNTHETIC_DEMO_DATA = true;

/**
 * 25 synthetic networks across Amazon partner seats 437, 489, 490, 491, 492
 * Covering Scenarios A (ads.txt FAIL), B (IVT spike), C (Amazon-specific drop / PASS or NO_DATA),
 * plus reconnected networks, varying revenue buckets and regions.
 */
export const DISCONNECTIONS_DATA: DisconnectionAlertRow[] = [
  // --- SCENARIO A: ads.txt FAIL after cut (Clear Cause) ---
  {
    PARTNER_ID: 437,
    PARTNER_NAME: 'Amazon DSP US (437)',
    PUBLISHER: 'Vox Media Group',
    NETWORK_ID: 1082,
    BUSINESS_UNIT: 'Web & Media',
    USERNAME: 'm.dubois@equativ.com',
    CUT_AT: '2026-10-14T08:30:00Z', // 6 days ago (1-7 bucket)
    RECONNECTED_AT: null,
    SPEND_7D_BEFORE: 24500,
    REGION: 'Americas',
    REVENUE_DROP_PCT: 100,
    ONE_LINE_REASON: 'Missing DIRECT publisher seat in app-ads.txt / ads.txt crawling failure',
  },
  {
    PARTNER_ID: 489,
    PARTNER_NAME: 'Amazon DSP EMEA (489)',
    PUBLISHER: 'Le Figaro Digital',
    NETWORK_ID: 1094,
    BUSINESS_UNIT: 'Web & Media',
    USERNAME: 'c.bernard@equativ.com',
    CUT_AT: '2026-10-02T14:15:00Z', // 18 days ago (8-30 bucket)
    RECONNECTED_AT: null,
    SPEND_7D_BEFORE: 18200,
    REGION: 'EMEA',
    REVENUE_DROP_PCT: 100,
    ONE_LINE_REASON: 'Seller ID mismatch in ads.txt after CMS migration',
  },
  {
    PARTNER_ID: 490,
    PARTNER_NAME: 'Amazon DSP UK (490)',
    PUBLISHER: 'Reach PLC Network',
    NETWORK_ID: 1105,
    BUSINESS_UNIT: 'Web & Media',
    USERNAME: 't.smith@equativ.com',
    CUT_AT: '2026-09-08T11:00:00Z', // 42 days ago (31-90 bucket)
    RECONNECTED_AT: null,
    SPEND_7D_BEFORE: 32000,
    REGION: 'EMEA',
    REVENUE_DROP_PCT: 100,
    ONE_LINE_REASON: 'Reseller declaration revoked on 4 domains during domain consolidation',
  },

  // --- SCENARIO B: IVT spike (Clear Cause) ---
  {
    PARTNER_ID: 437,
    PARTNER_NAME: 'Amazon DSP US (437)',
    PUBLISHER: 'Playwire Gaming Network',
    NETWORK_ID: 2011,
    BUSINESS_UNIT: 'In-App & Gaming',
    USERNAME: 'j.garcia@equativ.com',
    CUT_AT: '2026-10-18T19:00:00Z', // 2 days ago (1-7 bucket)
    RECONNECTED_AT: null,
    SPEND_7D_BEFORE: 28900,
    REGION: 'Americas',
    REVENUE_DROP_PCT: 100,
    ONE_LINE_REASON: 'Amazon DSP IVT threshold breached (GIVT 8.4% on mobile web inventory)',
  },
  {
    PARTNER_ID: 491,
    PARTNER_NAME: 'Amazon DSP APAC (491)',
    PUBLISHER: 'Tokyomotion Interactive',
    NETWORK_ID: 2024,
    BUSINESS_UNIT: 'In-App & Gaming',
    USERNAME: 'k.tanaka@equativ.com',
    CUT_AT: '2026-08-20T06:00:00Z', // 61 days ago (31-90 bucket)
    RECONNECTED_AT: null,
    SPEND_7D_BEFORE: 12400,
    REGION: 'APAC',
    REVENUE_DROP_PCT: 100,
    ONE_LINE_REASON: 'Bot traffic flagged in in-app rewarded placements (Fraud score > 5.5)',
  },
  {
    PARTNER_ID: 492,
    PARTNER_NAME: 'Amazon DSP Global CTV (492)',
    PUBLISHER: 'StreamFree FAST TV',
    NETWORK_ID: 3042,
    BUSINESS_UNIT: 'CTV & Video',
    USERNAME: 's.miller@equativ.com',
    CUT_AT: '2026-06-15T10:00:00Z', // 127 days ago (90+ bucket)
    RECONNECTED_AT: null,
    SPEND_7D_BEFORE: 41500,
    REGION: 'Americas',
    REVENUE_DROP_PCT: 100,
    ONE_LINE_REASON: 'Continuous automated loop pre-roll impressions detected by Moat/Amazon',
  },

  // --- SCENARIO C: All checks PASS or NO_DATA, drop is Amazon-specific ---
  {
    PARTNER_ID: 437,
    PARTNER_NAME: 'Amazon DSP US (437)',
    PUBLISHER: 'Penske Media Tech',
    NETWORK_ID: 4001,
    BUSINESS_UNIT: 'Web & Media',
    USERNAME: 'a.williams@equativ.com',
    CUT_AT: '2026-10-19T22:00:00Z', // <24h ago (Current bucket)
    RECONNECTED_AT: null,
    SPEND_7D_BEFORE: 15800,
    REGION: 'Americas',
    REVENUE_DROP_PCT: 88,
    ONE_LINE_REASON: 'All checks PASS; network auctions stable but Amazon bid requests dropped 91%',
  },
  {
    PARTNER_ID: 490,
    PARTNER_NAME: 'Amazon DSP UK (490)',
    PUBLISHER: 'Future Publishing UK',
    NETWORK_ID: 4005,
    BUSINESS_UNIT: 'Web & Media',
    USERNAME: 't.smith@equativ.com',
    CUT_AT: '2026-10-15T09:30:00Z', // 5 days ago (1-7 bucket)
    RECONNECTED_AT: null,
    SPEND_7D_BEFORE: 19400,
    REGION: 'EMEA',
    REVENUE_DROP_PCT: 92,
    ONE_LINE_REASON: 'OpenRTB 2.5 spec compatibility drop: Missing video.plcmt causing silent drop',
  },
  {
    PARTNER_ID: 489,
    PARTNER_NAME: 'Amazon DSP EMEA (489)',
    PUBLISHER: 'Prisa Noticias',
    NETWORK_ID: 4012,
    BUSINESS_UNIT: 'Web & Media',
    USERNAME: 'c.bernard@equativ.com',
    CUT_AT: '2026-09-28T16:00:00Z', // 22 days ago (8-30 bucket)
    RECONNECTED_AT: null,
    SPEND_7D_BEFORE: 8600,
    REGION: 'EMEA',
    REVENUE_DROP_PCT: 76,
    ONE_LINE_REASON: 'Amazon bid adapter timeout or DSP floor price unfill anomaly',
  },

  // --- Supply Chain Object (SCO) failures ---
  {
    PARTNER_ID: 437,
    PARTNER_NAME: 'Amazon DSP US (437)',
    PUBLISHER: 'Condé Nast Digital',
    NETWORK_ID: 5010,
    BUSINESS_UNIT: 'Web & Media',
    USERNAME: 'm.dubois@equativ.com',
    CUT_AT: '2026-10-08T12:00:00Z', // 12 days ago (8-30 bucket)
    RECONNECTED_AT: null,
    SPEND_7D_BEFORE: 36200,
    REGION: 'Americas',
    REVENUE_DROP_PCT: 100,
    ONE_LINE_REASON: 'Incomplete Sellers.json nodes in SCO chain (asi=equativ.com sid mismatch)',
  },
  {
    PARTNER_ID: 492,
    PARTNER_NAME: 'Amazon DSP Global CTV (492)',
    PUBLISHER: 'Tubular CTV Hub',
    NETWORK_ID: 5022,
    BUSINESS_UNIT: 'CTV & Video',
    USERNAME: 's.miller@equativ.com',
    CUT_AT: '2026-09-12T07:45:00Z', // 38 days ago (31-90 bucket)
    RECONNECTED_AT: null,
    SPEND_7D_BEFORE: 14700,
    REGION: 'Americas',
    REVENUE_DROP_PCT: 100,
    ONE_LINE_REASON: 'Broken schain object: hop count mismatch with sellers.json',
  },

  // --- Blocked Inventory / Domain List Disconnections ---
  {
    PARTNER_ID: 489,
    PARTNER_NAME: 'Amazon DSP EMEA (489)',
    PUBLISHER: 'Bauer Media Group',
    NETWORK_ID: 6015,
    BUSINESS_UNIT: 'Web & Media',
    USERNAME: 'c.bernard@equativ.com',
    CUT_AT: '2026-07-10T11:20:00Z', // 102 days ago (90+ bucket)
    RECONNECTED_AT: null,
    SPEND_7D_BEFORE: 9500,
    REGION: 'EMEA',
    REVENUE_DROP_PCT: 100,
    ONE_LINE_REASON: 'Domain flagged on Amazon Global DSP Content Exclusion List',
  },
  {
    PARTNER_ID: 491,
    PARTNER_NAME: 'Amazon DSP APAC (491)',
    PUBLISHER: 'K-Gaming Nexus',
    NETWORK_ID: 6030,
    BUSINESS_UNIT: 'In-App & Gaming',
    USERNAME: 'k.tanaka@equativ.com',
    CUT_AT: '2026-10-11T03:00:00Z', // 9 days ago (8-30 bucket)
    RECONNECTED_AT: null,
    SPEND_7D_BEFORE: 7200,
    REGION: 'APAC',
    REVENUE_DROP_PCT: 100,
    ONE_LINE_REASON: 'App ID bundles blocked due to unverified store listing URL',
  },

  // --- P1 & P2 special cases (missing revenue, lower spend) ---
  {
    PARTNER_ID: 437,
    PARTNER_NAME: 'Amazon DSP US (437)',
    PUBLISHER: 'Apex Daily Chronicle',
    NETWORK_ID: 7001,
    BUSINESS_UNIT: 'Web & Media',
    USERNAME: 'm.dubois@equativ.com',
    CUT_AT: '2026-10-16T15:00:00Z', // 4 days ago (1-7 bucket)
    RECONNECTED_AT: null,
    SPEND_7D_BEFORE: 3400, // P1 (SPEND_7D_BEFORE >= 1,000)
    REGION: 'Americas',
    REVENUE_DROP_PCT: 100,
    ONE_LINE_REASON: 'ads.txt direct line dropped during CDN cache purge',
  },
  {
    PARTNER_ID: 490,
    PARTNER_NAME: 'Amazon DSP UK (490)',
    PUBLISHER: 'Highland Media Scottish Tribune',
    NETWORK_ID: 7014,
    BUSINESS_UNIT: 'Web & Media',
    USERNAME: 't.smith@equativ.com',
    CUT_AT: '2026-09-02T13:30:00Z', // 48 days ago (31-90 bucket)
    RECONNECTED_AT: null,
    SPEND_7D_BEFORE: null, // P2 (still disconnected with missing revenue)
    REGION: 'EMEA',
    REVENUE_DROP_PCT: 100,
    ONE_LINE_REASON: 'Missing historical spend snapshot (telemetry gap during DSP seat cut)',
  },
  {
    PARTNER_ID: 491,
    PARTNER_NAME: 'Amazon DSP APAC (491)',
    PUBLISHER: 'Sydney Horizon Media',
    NETWORK_ID: 7025,
    BUSINESS_UNIT: 'CTV & Video',
    USERNAME: 'k.tanaka@equativ.com',
    CUT_AT: '2026-08-01T08:00:00Z', // 80 days ago (31-90 bucket)
    RECONNECTED_AT: null,
    SPEND_7D_BEFORE: null, // P2 (still disconnected with missing revenue)
    REGION: 'APAC',
    REVENUE_DROP_PCT: 100,
    ONE_LINE_REASON: 'Unmonitored CTV sub-network disconnected during APAC DSP audit',
  },

  // --- RECONNECTED NETWORKS (RECONNECTED_AT !== null) ---
  {
    PARTNER_ID: 437,
    PARTNER_NAME: 'Amazon DSP US (437)',
    PUBLISHER: 'The Daily Tribune Online',
    NETWORK_ID: 8001,
    BUSINESS_UNIT: 'Web & Media',
    USERNAME: 'm.dubois@equativ.com',
    CUT_AT: '2026-09-10T10:00:00Z',
    RECONNECTED_AT: '2026-09-18T16:00:00Z', // Reconnected in 8 days
    SPEND_7D_BEFORE: 21000,
    REGION: 'Americas',
    REVENUE_DROP_PCT: 0,
    ONE_LINE_REASON: 'ads.txt direct publisher line restored and validated by Amazon crawler',
  },
  {
    PARTNER_ID: 489,
    PARTNER_NAME: 'Amazon DSP EMEA (489)',
    PUBLISHER: 'Mondadori Media France',
    NETWORK_ID: 8012,
    BUSINESS_UNIT: 'Web & Media',
    USERNAME: 'c.bernard@equativ.com',
    CUT_AT: '2026-09-15T09:00:00Z',
    RECONNECTED_AT: '2026-09-23T11:30:00Z',
    SPEND_7D_BEFORE: 16500,
    REGION: 'EMEA',
    REVENUE_DROP_PCT: 0,
    ONE_LINE_REASON: 'schain node corrected in sellers.json; DSP re-enabled buying',
  },
  {
    PARTNER_ID: 490,
    PARTNER_NAME: 'Amazon DSP UK (490)',
    PUBLISHER: 'The Independent Digital',
    NETWORK_ID: 8023,
    BUSINESS_UNIT: 'Web & Media',
    USERNAME: 't.smith@equativ.com',
    CUT_AT: '2026-08-25T14:00:00Z',
    RECONNECTED_AT: '2026-09-01T17:00:00Z',
    SPEND_7D_BEFORE: 27800,
    REGION: 'EMEA',
    REVENUE_DROP_PCT: 0,
    ONE_LINE_REASON: 'Prebid amazon adapter floor optimization rolled back',
  },
  {
    PARTNER_ID: 492,
    PARTNER_NAME: 'Amazon DSP Global CTV (492)',
    PUBLISHER: 'CineStream FAST World',
    NETWORK_ID: 8035,
    BUSINESS_UNIT: 'CTV & Video',
    USERNAME: 's.miller@equativ.com',
    CUT_AT: '2026-07-15T12:00:00Z',
    RECONNECTED_AT: '2026-07-28T18:00:00Z',
    SPEND_7D_BEFORE: 38000,
    REGION: 'Americas',
    REVENUE_DROP_PCT: 0,
    ONE_LINE_REASON: 'video.plcmt OpenRTB declaration added to VAST bid stream',
  },
  {
    PARTNER_ID: 491,
    PARTNER_NAME: 'Amazon DSP APAC (491)',
    PUBLISHER: 'Singtel Media Network',
    NETWORK_ID: 8046,
    BUSINESS_UNIT: 'In-App & Gaming',
    USERNAME: 'k.tanaka@equativ.com',
    CUT_AT: '2026-08-10T05:00:00Z',
    RECONNECTED_AT: '2026-08-22T08:00:00Z',
    SPEND_7D_BEFORE: 11200,
    REGION: 'APAC',
    REVENUE_DROP_PCT: 0,
    ONE_LINE_REASON: 'IVT filter tightened in SDK pre-bid filter; Amazon reinstated app bundle',
  },

  // Additional active disconnected networks to hit ~25 total
  {
    PARTNER_ID: 490,
    PARTNER_NAME: 'Amazon DSP UK (490)',
    PUBLISHER: 'Telegraph Media Group',
    NETWORK_ID: 9001,
    BUSINESS_UNIT: 'Web & Media',
    USERNAME: 't.smith@equativ.com',
    CUT_AT: '2026-10-17T11:00:00Z', // 3 days ago (1-7 bucket)
    RECONNECTED_AT: null,
    SPEND_7D_BEFORE: 15400,
    REGION: 'EMEA',
    REVENUE_DROP_PCT: 100,
    ONE_LINE_REASON: 'Direct sellers.json entry missing publisher entity verification',
  },
  {
    PARTNER_ID: 492,
    PARTNER_NAME: 'Amazon DSP Global CTV (492)',
    PUBLISHER: 'Pluto-Sync FAST Europe',
    NETWORK_ID: 9015,
    BUSINESS_UNIT: 'CTV & Video',
    USERNAME: 's.miller@equativ.com',
    CUT_AT: '2026-09-25T14:00:00Z', // 25 days ago (8-30 bucket)
    RECONNECTED_AT: null,
    SPEND_7D_BEFORE: 22100,
    REGION: 'EMEA',
    REVENUE_DROP_PCT: 100,
    ONE_LINE_REASON: 'Missing device.lmt / consent string forwarding on connected TV stream',
  },
  {
    PARTNER_ID: 437,
    PARTNER_NAME: 'Amazon DSP US (437)',
    PUBLISHER: 'Fandom Entertainment',
    NETWORK_ID: 9028,
    BUSINESS_UNIT: 'In-App & Gaming',
    USERNAME: 'j.garcia@equativ.com',
    CUT_AT: '2026-10-12T16:00:00Z', // 8 days ago (8-30 bucket)
    RECONNECTED_AT: null,
    SPEND_7D_BEFORE: 19800,
    REGION: 'Americas',
    REVENUE_DROP_PCT: 100,
    ONE_LINE_REASON: 'IVT spike following user acquisition campaign on Android',
  },
  {
    PARTNER_ID: 489,
    PARTNER_NAME: 'Amazon DSP EMEA (489)',
    PUBLISHER: 'Axel Springer DE Digital',
    NETWORK_ID: 9044,
    BUSINESS_UNIT: 'Web & Media',
    USERNAME: 'c.bernard@equativ.com',
    CUT_AT: '2026-10-05T09:00:00Z', // 15 days ago (8-30 bucket)
    RECONNECTED_AT: null,
    SPEND_7D_BEFORE: 26300,
    REGION: 'EMEA',
    REVENUE_DROP_PCT: 100,
    ONE_LINE_REASON: 'TCF v2.2 GVL registration for Amazon seat temporarily invalidated',
  },
];

/**
 * Checks (B): one row per network per check, window BEFORE vs AFTER
 * Check ∈ {ADS_TXT, SCO, BLOCKED_INVENTORY, IVT}
 * Result ∈ {PASS, FAIL, NO_DATA}
 */
export const CHECKS_DATA: CheckRow[] = [
  // Network 1082 (Scenario A: ads.txt FAIL after cut)
  { network_id: 1082, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-1082-AT-B', detail: 'equativ.com, 1082, DIRECT, 00b0c441 verified on 42 domains' },
  { network_id: 1082, check: 'ADS_TXT', window: 'AFTER', result: 'FAIL', evidence_ref: 'EV-1082-AT-A', detail: 'amazon.com crawler returned 404 on /ads.txt across 28 subdomains' },
  { network_id: 1082, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-1082-SC-B', detail: 'Schain nodes 1.0 complete, seller_id=1082 published' },
  { network_id: 1082, check: 'SCO', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-1082-SC-A', detail: 'Schain intact with 2 hops' },
  { network_id: 1082, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-1082-BI-B', detail: 'Domains clean on Amazon DSP exclusion lists' },
  { network_id: 1082, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-1082-BI-A', detail: 'No domain exclusions or brand safety blocklist hits' },
  { network_id: 1082, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-1082-IV-B', detail: 'Baseline IVT rate 0.42% (threshold: 2.0%)' },
  { network_id: 1082, check: 'IVT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-1082-IV-A', detail: 'Post-cut IVT rate 0.44% - normal range' },

  // Network 1094 (Scenario A: ads.txt FAIL)
  { network_id: 1094, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-1094-AT-B', detail: 'Direct publisher line in place' },
  { network_id: 1094, check: 'ADS_TXT', window: 'AFTER', result: 'FAIL', evidence_ref: 'EV-1094-AT-A', detail: 'Seller ID mismatch in ads.txt after CMS rewrite' },
  { network_id: 1094, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-1094-SC-B', detail: 'Sellers.json valid' },
  { network_id: 1094, check: 'SCO', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-1094-SC-A', detail: 'Sellers.json valid' },
  { network_id: 1094, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-1094-BI-B', detail: 'Clean domain' },
  { network_id: 1094, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-1094-BI-A', detail: 'Clean domain' },
  { network_id: 1094, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-1094-IV-B', detail: 'IVT 0.38%' },
  { network_id: 1094, check: 'IVT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-1094-IV-A', detail: 'IVT 0.40%' },

  // Network 1105 (Scenario A: ads.txt FAIL)
  { network_id: 1105, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-1105-AT-B', detail: 'ads.txt valid' },
  { network_id: 1105, check: 'ADS_TXT', window: 'AFTER', result: 'FAIL', evidence_ref: 'EV-1105-AT-A', detail: 'Reseller declaration revoked on 4 regional domains' },
  { network_id: 1105, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-1105-SC-B', detail: 'Schain valid' },
  { network_id: 1105, check: 'SCO', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-1105-SC-A', detail: 'Schain valid' },
  { network_id: 1105, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-1105-BI-B', detail: 'Clean' },
  { network_id: 1105, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-1105-BI-A', detail: 'Clean' },
  { network_id: 1105, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-1105-IV-B', detail: 'IVT 0.51%' },
  { network_id: 1105, check: 'IVT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-1105-IV-A', detail: 'IVT 0.55%' },

  // Network 2011 (Scenario B: IVT spike)
  { network_id: 2011, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-2011-AT-B', detail: 'app-ads.txt valid and reachable' },
  { network_id: 2011, check: 'ADS_TXT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-2011-AT-A', detail: 'app-ads.txt valid' },
  { network_id: 2011, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-2011-SC-B', detail: 'Schain complete' },
  { network_id: 2011, check: 'SCO', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-2011-SC-A', detail: 'Schain complete' },
  { network_id: 2011, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-2011-BI-B', detail: 'Not blocked' },
  { network_id: 2011, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-2011-BI-A', detail: 'Not blocked' },
  { network_id: 2011, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-2011-IV-B', detail: 'IVT 0.8% baseline' },
  { network_id: 2011, check: 'IVT', window: 'AFTER', result: 'FAIL', evidence_ref: 'EV-2011-IV-A', detail: 'Amazon DSP IVT surged to 8.4% (Threshold: 2.0%)' },

  // Network 2024 (Scenario B: IVT spike)
  { network_id: 2024, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-2024-AT-B', detail: 'ads.txt verified' },
  { network_id: 2024, check: 'ADS_TXT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-2024-AT-A', detail: 'ads.txt verified' },
  { network_id: 2024, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-2024-SC-B', detail: 'Schain verified' },
  { network_id: 2024, check: 'SCO', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-2024-SC-A', detail: 'Schain verified' },
  { network_id: 2024, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-2024-BI-B', detail: 'Clean' },
  { network_id: 2024, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-2024-BI-A', detail: 'Clean' },
  { network_id: 2024, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-2024-IV-B', detail: 'IVT 1.1%' },
  { network_id: 2024, check: 'IVT', window: 'AFTER', result: 'FAIL', evidence_ref: 'EV-2024-IV-A', detail: 'IVT surged to 6.2% on gaming sub-bundle' },

  // Network 3042 (Scenario B: IVT spike on CTV)
  { network_id: 3042, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-3042-AT-B', detail: 'app-ads.txt verified' },
  { network_id: 3042, check: 'ADS_TXT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-3042-AT-A', detail: 'app-ads.txt verified' },
  { network_id: 3042, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-3042-SC-B', detail: 'Schain verified' },
  { network_id: 3042, check: 'SCO', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-3042-SC-A', detail: 'Schain verified' },
  { network_id: 3042, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-3042-BI-B', detail: 'Clean' },
  { network_id: 3042, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-3042-BI-A', detail: 'Clean' },
  { network_id: 3042, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-3042-IV-B', detail: 'IVT 0.2%' },
  { network_id: 3042, check: 'IVT', window: 'AFTER', result: 'FAIL', evidence_ref: 'EV-3042-IV-A', detail: 'Looping pre-roll ghost sessions detected by Moat (IVT 9.1%)' },

  // Network 4001 (Scenario C: ALL CHECKS PASS or NO_DATA; Amazon-specific drop)
  { network_id: 4001, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-4001-AT-B', detail: 'ads.txt valid' },
  { network_id: 4001, check: 'ADS_TXT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-4001-AT-A', detail: 'ads.txt crawled 2h ago, no changes' },
  { network_id: 4001, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-4001-SC-B', detail: 'Sellers.json fully resolved' },
  { network_id: 4001, check: 'SCO', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-4001-SC-A', detail: 'Schain nodes unaltered' },
  { network_id: 4001, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-4001-BI-B', detail: 'Clean domains' },
  { network_id: 4001, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-4001-BI-A', detail: 'No DSP policy or exclusion blocks' },
  { network_id: 4001, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-4001-IV-B', detail: 'IVT 0.31%' },
  { network_id: 4001, check: 'IVT', window: 'AFTER', result: 'NO_DATA', evidence_ref: 'EV-4001-IV-A', detail: 'Amazon DSP ad-fraud telemetry not reported for the current window' },

  // Network 4005 (Scenario C: SCO/ads.txt PASS, but OpenRTB plcmt missing causing drop)
  { network_id: 4005, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-4005-AT-B', detail: 'ads.txt valid' },
  { network_id: 4005, check: 'ADS_TXT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-4005-AT-A', detail: 'ads.txt valid' },
  { network_id: 4005, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-4005-SC-B', detail: 'Schain valid' },
  { network_id: 4005, check: 'SCO', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-4005-SC-A', detail: 'Schain valid' },
  { network_id: 4005, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-4005-BI-B', detail: 'Clean' },
  { network_id: 4005, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-4005-BI-A', detail: 'Clean' },
  { network_id: 4005, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-4005-IV-B', detail: 'IVT 0.45%' },
  { network_id: 4005, check: 'IVT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-4005-IV-A', detail: 'IVT 0.48%' },

  // Network 4012 (Scenario C: NO_DATA on IVT, PASS on others)
  { network_id: 4012, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-4012-AT-B', detail: 'ads.txt valid' },
  { network_id: 4012, check: 'ADS_TXT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-4012-AT-A', detail: 'ads.txt valid' },
  { network_id: 4012, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-4012-SC-B', detail: 'Schain valid' },
  { network_id: 4012, check: 'SCO', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-4012-SC-A', detail: 'Schain valid' },
  { network_id: 4012, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-4012-BI-B', detail: 'Clean' },
  { network_id: 4012, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-4012-BI-A', detail: 'Clean' },
  { network_id: 4012, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-4012-IV-B', detail: 'IVT 0.60%' },
  { network_id: 4012, check: 'IVT', window: 'AFTER', result: 'NO_DATA', evidence_ref: 'EV-4012-IV-A', detail: 'Third-party IVT feed timed out' },

  // Network 5010 (SCO FAIL)
  { network_id: 5010, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-5010-AT-B', detail: 'ads.txt verified' },
  { network_id: 5010, check: 'ADS_TXT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-5010-AT-A', detail: 'ads.txt verified' },
  { network_id: 5010, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-5010-SC-B', detail: 'Sellers.json node valid' },
  { network_id: 5010, check: 'SCO', window: 'AFTER', result: 'FAIL', evidence_ref: 'EV-5010-SC-A', detail: 'asi=equativ.com sid mismatch in sellers.json declaration' },
  { network_id: 5010, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-5010-BI-B', detail: 'Clean' },
  { network_id: 5010, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-5010-BI-A', detail: 'Clean' },
  { network_id: 5010, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-5010-IV-B', detail: 'IVT 0.35%' },
  { network_id: 5010, check: 'IVT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-5010-IV-A', detail: 'IVT 0.39%' },

  // Network 5022 (SCO FAIL)
  { network_id: 5022, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-5022-AT-B', detail: 'ads.txt verified' },
  { network_id: 5022, check: 'ADS_TXT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-5022-AT-A', detail: 'ads.txt verified' },
  { network_id: 5022, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-5022-SC-B', detail: 'Schain verified' },
  { network_id: 5022, check: 'SCO', window: 'AFTER', result: 'FAIL', evidence_ref: 'EV-5022-SC-A', detail: 'Hop count mismatch: DSP detected 3 hops, sellers.json lists 2' },
  { network_id: 5022, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-5022-BI-B', detail: 'Clean' },
  { network_id: 5022, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-5022-BI-A', detail: 'Clean' },
  { network_id: 5022, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-5022-IV-B', detail: 'IVT 0.22%' },
  { network_id: 5022, check: 'IVT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-5022-IV-A', detail: 'IVT 0.25%' },

  // Network 6015 (BLOCKED_INVENTORY FAIL)
  { network_id: 6015, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-6015-AT-B', detail: 'ads.txt valid' },
  { network_id: 6015, check: 'ADS_TXT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-6015-AT-A', detail: 'ads.txt valid' },
  { network_id: 6015, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-6015-SC-B', detail: 'Schain valid' },
  { network_id: 6015, check: 'SCO', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-6015-SC-A', detail: 'Schain valid' },
  { network_id: 6015, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-6015-BI-B', detail: 'Active inventory' },
  { network_id: 6015, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'FAIL', evidence_ref: 'EV-6015-BI-A', detail: 'Domain listed on Amazon Global Brand Safety exclusion table' },
  { network_id: 6015, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-6015-IV-B', detail: 'IVT 0.45%' },
  { network_id: 6015, check: 'IVT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-6015-IV-A', detail: 'IVT 0.49%' },

  // Network 6030 (BLOCKED_INVENTORY FAIL)
  { network_id: 6030, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-6030-AT-B', detail: 'app-ads.txt valid' },
  { network_id: 6030, check: 'ADS_TXT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-6030-AT-A', detail: 'app-ads.txt valid' },
  { network_id: 6030, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-6030-SC-B', detail: 'Schain valid' },
  { network_id: 6030, check: 'SCO', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-6030-SC-A', detail: 'Schain valid' },
  { network_id: 6030, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-6030-BI-B', detail: 'Active' },
  { network_id: 6030, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'FAIL', evidence_ref: 'EV-6030-BI-A', detail: 'Google Play bundle id rejected by Amazon safety scanner' },
  { network_id: 6030, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-6030-IV-B', detail: 'IVT 0.81%' },
  { network_id: 6030, check: 'IVT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-6030-IV-A', detail: 'IVT 0.88%' },

  // Network 7001 (ads.txt FAIL)
  { network_id: 7001, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-7001-AT-B', detail: 'ads.txt valid' },
  { network_id: 7001, check: 'ADS_TXT', window: 'AFTER', result: 'FAIL', evidence_ref: 'EV-7001-AT-A', detail: 'Line dropped during Cloudflare cache refresh' },
  { network_id: 7001, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-7001-SC-B', detail: 'Schain valid' },
  { network_id: 7001, check: 'SCO', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-7001-SC-A', detail: 'Schain valid' },
  { network_id: 7001, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-7001-BI-B', detail: 'Clean' },
  { network_id: 7001, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-7001-BI-A', detail: 'Clean' },
  { network_id: 7001, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-7001-IV-B', detail: 'IVT 0.3%' },
  { network_id: 7001, check: 'IVT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-7001-IV-A', detail: 'IVT 0.3%' },

  // Network 7014 (Missing revenue - NO_DATA on checks)
  { network_id: 7014, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-7014-AT-B', detail: 'ads.txt cached' },
  { network_id: 7014, check: 'ADS_TXT', window: 'AFTER', result: 'NO_DATA', evidence_ref: 'EV-7014-AT-A', detail: 'Crawler log unavailable' },
  { network_id: 7014, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-7014-SC-B', detail: 'Schain intact' },
  { network_id: 7014, check: 'SCO', window: 'AFTER', result: 'NO_DATA', evidence_ref: 'EV-7014-SC-A', detail: 'Feed unreachable' },
  { network_id: 7014, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-7014-BI-B', detail: 'Clean' },
  { network_id: 7014, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-7014-BI-A', detail: 'Clean' },
  { network_id: 7014, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-7014-IV-B', detail: 'IVT 0.2%' },
  { network_id: 7014, check: 'IVT', window: 'AFTER', result: 'NO_DATA', evidence_ref: 'EV-7014-IV-A', detail: 'Feed unreachable' },

  // Network 7025 (Missing revenue - NO_DATA on checks)
  { network_id: 7025, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-7025-AT-B', detail: 'app-ads.txt verified' },
  { network_id: 7025, check: 'ADS_TXT', window: 'AFTER', result: 'NO_DATA', evidence_ref: 'EV-7025-AT-A', detail: 'Audit pending' },
  { network_id: 7025, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-7025-SC-B', detail: 'Schain verified' },
  { network_id: 7025, check: 'SCO', window: 'AFTER', result: 'NO_DATA', evidence_ref: 'EV-7025-SC-A', detail: 'Audit pending' },
  { network_id: 7025, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-7025-BI-B', detail: 'Clean' },
  { network_id: 7025, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-7025-BI-A', detail: 'Clean' },
  { network_id: 7025, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-7025-IV-B', detail: 'IVT 0.4%' },
  { network_id: 7025, check: 'IVT', window: 'AFTER', result: 'NO_DATA', evidence_ref: 'EV-7025-IV-A', detail: 'Audit pending' },

  // Reconnected networks (All restored to PASS)
  { network_id: 8001, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-8001-AT-B', detail: 'ads.txt valid' },
  { network_id: 8001, check: 'ADS_TXT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-8001-AT-A', detail: 'ads.txt verified by crawler' },
  { network_id: 8001, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-8001-SC-B', detail: 'Schain valid' },
  { network_id: 8001, check: 'SCO', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-8001-SC-A', detail: 'Schain valid' },
  { network_id: 8001, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-8001-BI-B', detail: 'Clean' },
  { network_id: 8001, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-8001-BI-A', detail: 'Clean' },
  { network_id: 8001, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-8001-IV-B', detail: 'IVT 0.3%' },
  { network_id: 8001, check: 'IVT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-8001-IV-A', detail: 'IVT 0.3%' },

  { network_id: 8012, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-8012-AT-B', detail: 'ads.txt valid' },
  { network_id: 8012, check: 'ADS_TXT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-8012-AT-A', detail: 'ads.txt valid' },
  { network_id: 8012, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-8012-SC-B', detail: 'Schain valid' },
  { network_id: 8012, check: 'SCO', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-8012-SC-A', detail: 'Schain fixed and published' },
  { network_id: 8012, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-8012-BI-B', detail: 'Clean' },
  { network_id: 8012, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-8012-BI-A', detail: 'Clean' },
  { network_id: 8012, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-8012-IV-B', detail: 'IVT 0.4%' },
  { network_id: 8012, check: 'IVT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-8012-IV-A', detail: 'IVT 0.4%' },

  { network_id: 8023, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-8023-AT-B', detail: 'ads.txt valid' },
  { network_id: 8023, check: 'ADS_TXT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-8023-AT-A', detail: 'ads.txt valid' },
  { network_id: 8023, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-8023-SC-B', detail: 'Schain valid' },
  { network_id: 8023, check: 'SCO', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-8023-SC-A', detail: 'Schain valid' },
  { network_id: 8023, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-8023-BI-B', detail: 'Clean' },
  { network_id: 8023, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-8023-BI-A', detail: 'Clean' },
  { network_id: 8023, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-8023-IV-B', detail: 'IVT 0.2%' },
  { network_id: 8023, check: 'IVT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-8023-IV-A', detail: 'IVT 0.2%' },

  { network_id: 8035, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-8035-AT-B', detail: 'app-ads.txt valid' },
  { network_id: 8035, check: 'ADS_TXT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-8035-AT-A', detail: 'app-ads.txt valid' },
  { network_id: 8035, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-8035-SC-B', detail: 'Schain valid' },
  { network_id: 8035, check: 'SCO', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-8035-SC-A', detail: 'Schain valid' },
  { network_id: 8035, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-8035-BI-B', detail: 'Clean' },
  { network_id: 8035, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-8035-BI-A', detail: 'Clean' },
  { network_id: 8035, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-8035-IV-B', detail: 'IVT 0.1%' },
  { network_id: 8035, check: 'IVT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-8035-IV-A', detail: 'IVT 0.1%' },

  { network_id: 8046, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-8046-AT-B', detail: 'app-ads.txt valid' },
  { network_id: 8046, check: 'ADS_TXT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-8046-AT-A', detail: 'app-ads.txt valid' },
  { network_id: 8046, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-8046-SC-B', detail: 'Schain valid' },
  { network_id: 8046, check: 'SCO', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-8046-SC-A', detail: 'Schain valid' },
  { network_id: 8046, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-8046-BI-B', detail: 'Clean' },
  { network_id: 8046, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-8046-BI-A', detail: 'Clean' },
  { network_id: 8046, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-8046-IV-B', detail: 'IVT 0.7%' },
  { network_id: 8046, check: 'IVT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-8046-IV-A', detail: 'IVT 0.5% (remediated)' },

  // 9001 (SCO FAIL)
  { network_id: 9001, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-9001-AT-B', detail: 'ads.txt valid' },
  { network_id: 9001, check: 'ADS_TXT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-9001-AT-A', detail: 'ads.txt valid' },
  { network_id: 9001, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-9001-SC-B', detail: 'Sellers.json declared' },
  { network_id: 9001, check: 'SCO', window: 'AFTER', result: 'FAIL', evidence_ref: 'EV-9001-SC-A', detail: 'sellers.json node missing DIRECT flag for publisher domain' },
  { network_id: 9001, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-9001-BI-B', detail: 'Clean' },
  { network_id: 9001, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-9001-BI-A', detail: 'Clean' },
  { network_id: 9001, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-9001-IV-B', detail: 'IVT 0.3%' },
  { network_id: 9001, check: 'IVT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-9001-IV-A', detail: 'IVT 0.3%' },

  // 9015 (BLOCKED_INVENTORY FAIL)
  { network_id: 9015, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-9015-AT-B', detail: 'app-ads.txt valid' },
  { network_id: 9015, check: 'ADS_TXT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-9015-AT-A', detail: 'app-ads.txt valid' },
  { network_id: 9015, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-9015-SC-B', detail: 'Schain valid' },
  { network_id: 9015, check: 'SCO', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-9015-SC-A', detail: 'Schain valid' },
  { network_id: 9015, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-9015-BI-B', detail: 'Clean' },
  { network_id: 9015, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'FAIL', evidence_ref: 'EV-9015-BI-A', detail: 'Device bundle id flagged on consent blocklist' },
  { network_id: 9015, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-9015-IV-B', detail: 'IVT 0.2%' },
  { network_id: 9015, check: 'IVT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-9015-IV-A', detail: 'IVT 0.2%' },

  // 9028 (IVT FAIL)
  { network_id: 9028, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-9028-AT-B', detail: 'ads.txt valid' },
  { network_id: 9028, check: 'ADS_TXT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-9028-AT-A', detail: 'ads.txt valid' },
  { network_id: 9028, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-9028-SC-B', detail: 'Schain valid' },
  { network_id: 9028, check: 'SCO', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-9028-SC-A', detail: 'Schain valid' },
  { network_id: 9028, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-9028-BI-B', detail: 'Clean' },
  { network_id: 9028, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-9028-BI-A', detail: 'Clean' },
  { network_id: 9028, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-9028-IV-B', detail: 'IVT 0.6%' },
  { network_id: 9028, check: 'IVT', window: 'AFTER', result: 'FAIL', evidence_ref: 'EV-9028-IV-A', detail: 'IVT rate 7.8% exceeds Amazon policy ceiling' },

  // 9044 (BLOCKED_INVENTORY FAIL)
  { network_id: 9044, check: 'ADS_TXT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-9044-AT-B', detail: 'ads.txt valid' },
  { network_id: 9044, check: 'ADS_TXT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-9044-AT-A', detail: 'ads.txt valid' },
  { network_id: 9044, check: 'SCO', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-9044-SC-B', detail: 'Schain valid' },
  { network_id: 9044, check: 'SCO', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-9044-SC-A', detail: 'Schain valid' },
  { network_id: 9044, check: 'BLOCKED_INVENTORY', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-9044-BI-B', detail: 'Clean' },
  { network_id: 9044, check: 'BLOCKED_INVENTORY', window: 'AFTER', result: 'FAIL', evidence_ref: 'EV-9044-BI-A', detail: 'CMP vendor ID blocked by Amazon regional privacy gateway' },
  { network_id: 9044, check: 'IVT', window: 'BEFORE', result: 'PASS', evidence_ref: 'EV-9044-IV-B', detail: 'IVT 0.3%' },
  { network_id: 9044, check: 'IVT', window: 'AFTER', result: 'PASS', evidence_ref: 'EV-9044-IV-A', detail: 'IVT 0.3%' },
];

/**
 * Traffic metrics[] (C): traffic context signals
 * metric, partner_name, partner_ids, change_pct, before, after, period, source
 */
export const TRAFFIC_METRICS_DATA: TrafficMetricRow[] = [
  // Scenario A (1082)
  {
    network_id: 1082,
    metric: 'Network Total Auctions',
    partner_name: 'Vox Media Group',
    partner_ids: [437],
    change_pct: -1.2,
    before: 14200000,
    after: 14030000,
    period: '7d_before_vs_after',
    source: 'Equativ Ad Server Analytics',
  },
  {
    network_id: 1082,
    metric: 'Amazon Bid Requests',
    partner_name: 'Amazon DSP US (437)',
    partner_ids: [437],
    change_pct: -98.7,
    before: 8200000,
    after: 106000,
    period: '7d_before_vs_after',
    source: 'Amazon DSP Prebid Gateway',
  },

  // Scenario B (2011)
  {
    network_id: 2011,
    metric: 'Network Total Auctions',
    partner_name: 'Playwire Gaming Network',
    partner_ids: [437],
    change_pct: +4.8,
    before: 9400000,
    after: 9850000,
    period: '7d_before_vs_after',
    source: 'Equativ Ad Server Analytics',
  },
  {
    network_id: 2011,
    metric: 'Amazon Bid Requests',
    partner_name: 'Amazon DSP US (437)',
    partner_ids: [437],
    change_pct: -100.0,
    before: 5100000,
    after: 0,
    period: '7d_before_vs_after',
    source: 'Amazon DSP Prebid Gateway',
  },

  // Scenario C (4001) - Demonstrates: auctions stable, Amazon bid requests dropped!
  {
    network_id: 4001,
    metric: 'Network Total Auctions',
    partner_name: 'Penske Media Tech',
    partner_ids: [437],
    change_pct: +0.3,
    before: 18500000,
    after: 18550000,
    period: '7d_before_vs_after',
    source: 'Equativ Ad Server Analytics',
  },
  {
    network_id: 4001,
    metric: 'Amazon Bid Requests',
    partner_name: 'Amazon DSP US (437)',
    partner_ids: [437],
    change_pct: -91.4,
    before: 11200000,
    after: 960000,
    period: '7d_before_vs_after',
    source: 'Amazon DSP Prebid Gateway',
  },

  // 4005
  {
    network_id: 4005,
    metric: 'Network Total Auctions',
    partner_name: 'Future Publishing UK',
    partner_ids: [490],
    change_pct: -2.1,
    before: 12100000,
    after: 11840000,
    period: '7d_before_vs_after',
    source: 'Equativ Ad Server Analytics',
  },
  {
    network_id: 4005,
    metric: 'Amazon Bid Requests',
    partner_name: 'Amazon DSP UK (490)',
    partner_ids: [490],
    change_pct: -92.5,
    before: 7400000,
    after: 555000,
    period: '7d_before_vs_after',
    source: 'Amazon DSP Prebid Gateway',
  },

  // 5010
  {
    network_id: 5010,
    metric: 'Network Total Auctions',
    partner_name: 'Condé Nast Digital',
    partner_ids: [437],
    change_pct: +1.0,
    before: 22000000,
    after: 22220000,
    period: '7d_before_vs_after',
    source: 'Equativ Ad Server Analytics',
  },
  {
    network_id: 5010,
    metric: 'Amazon Bid Requests',
    partner_name: 'Amazon DSP US (437)',
    partner_ids: [437],
    change_pct: -99.4,
    before: 14000000,
    after: 84000,
    period: '7d_before_vs_after',
    source: 'Amazon DSP Prebid Gateway',
  },

  // 9028: General traffic collapse (auctions dropped -45% across all demand)
  {
    network_id: 9028,
    metric: 'Network Total Auctions',
    partner_name: 'Fandom Entertainment',
    partner_ids: [437],
    change_pct: -45.0, // NOT stable!
    before: 10000000,
    after: 5500000,
    period: '7d_before_vs_after',
    source: 'Equativ Ad Server Analytics',
  },
  {
    network_id: 9028,
    metric: 'Amazon Bid Requests',
    partner_name: 'Amazon DSP US (437)',
    partner_ids: [437],
    change_pct: -95.0,
    before: 6000000,
    after: 300000,
    period: '7d_before_vs_after',
    source: 'Amazon DSP Prebid Gateway',
  },
];

/**
 * Demand funnel (D): per network
 * auctions, bid_requests, bids, wins, impressions, plus drop_reasons[] {stage, reason, count}
 */
export const DEMAND_FUNNEL_DATA: Record<number, DemandFunnelRow> = {
  1082: {
    network_id: 1082,
    auctions: 14030000,
    bid_requests: 106000, // collapsed
    bids: 18200,
    wins: 2400,
    impressions: 2310,
    drop_reasons: [
      { stage: 'Auctions', reason: 'Amazon DSP ads.txt direct line verification failure', count: 13924000 },
      { stage: 'Bid requests', reason: 'Timeout on prebid client adapter (>800ms)', count: 54000 },
      { stage: 'Bid requests', reason: 'DSP floor pricing unfulfilled', count: 33800 },
      { stage: 'Bids', reason: 'Outbid by Google DV360 & The Trade Desk', count: 15800 },
      { stage: 'Wins', reason: 'Ad render timeout / network loss', count: 90 },
    ],
  },
  2011: {
    network_id: 2011,
    auctions: 9850000,
    bid_requests: 0,
    bids: 0,
    wins: 0,
    impressions: 0,
    drop_reasons: [
      { stage: 'Auctions', reason: 'DSP hard blacklist triggered by Moat IVT spike (>8%)', count: 9850000 },
      { stage: 'Bid requests', reason: 'No bid requests issued by DSP seat', count: 0 },
      { stage: 'Bids', reason: 'No bids', count: 0 },
      { stage: 'Wins', reason: 'No wins', count: 0 },
    ],
  },
  4001: {
    network_id: 4001,
    auctions: 18550000,
    bid_requests: 960000,
    bids: 240000,
    wins: 48000,
    impressions: 46500,
    drop_reasons: [
      { stage: 'Auctions', reason: 'Amazon buyer DSP bid filtering (undisclosed buyer DSP logic)', count: 17590000 },
      { stage: 'Bid requests', reason: 'DSP floor price set above Amazon max CPM bid', count: 480000 },
      { stage: 'Bid requests', reason: 'Missing video.plcmt or content metadata signals', count: 240000 },
      { stage: 'Bids', reason: 'Auction lost to competitive header bidders', count: 192000 },
      { stage: 'Wins', reason: 'Viewability discard / render delay', count: 1500 },
    ],
  },
  5010: {
    network_id: 5010,
    auctions: 22220000,
    bid_requests: 84000,
    bids: 12000,
    wins: 1500,
    impressions: 1460,
    drop_reasons: [
      { stage: 'Auctions', reason: 'Schain incomplete: sellers.json lookup failed', count: 22136000 },
      { stage: 'Bid requests', reason: 'DSP internal floor mismatch', count: 52000 },
      { stage: 'Bids', reason: 'Loss to direct deal ID', count: 10500 },
      { stage: 'Wins', reason: 'Creative timeout', count: 40 },
    ],
  },
};

/**
 * Fallback cohort-aggregate funnel for all networks combined
 */
export const COHORT_AGGREGATE_FUNNEL: DemandFunnelRow = {
  network_id: 0,
  auctions: 182400000,
  bid_requests: 42100000,
  bids: 9840000,
  wins: 1920000,
  impressions: 1860000,
  drop_reasons: [
    { stage: 'Auctions', reason: 'DSP ads.txt & sellers.json eligibility gate', count: 112000000 },
    { stage: 'Auctions', reason: 'IVT safety threshold filtering', count: 18400000 },
    { stage: 'Auctions', reason: 'OpenRTB 2.5 spec compatibility omission', count: 9900000 },
    { stage: 'Bid requests', reason: 'DSP bid floor unfulfilled / reserve price', count: 21500000 },
    { stage: 'Bid requests', reason: 'Client-side adapter timeout (>800ms)', count: 10760000 },
    { stage: 'Bids', reason: 'Auction lost to alternative omnichannel DSPs', count: 7920000 },
    { stage: 'Wins', reason: 'Render latency & viewability drop-off', count: 60000 },
  ],
};

/**
 * AI Investigation (E): per network
 * hypotheses[] {label, confidence ∈ {LOW, MEDIUM, HIGH}, evidence_refs[], missing_info[]},
 * draft_message, validation {passed, ai_output_accepted, fallback_fields[]}
 * RULE: if no check is FAIL, never display HIGH confidence.
 * If an evidence_ref does not exist in Checks, show a red "Unverified evidence" badge.
 */
export const AI_INVESTIGATION_DATA: Record<number, AIInvestigationRow> = {
  // Scenario A: ads.txt FAIL after cut (Clear cause, high confidence)
  1082: {
    network_id: 1082,
    hypotheses: [
      {
        label: 'ads.txt publisher line missing or inaccessible during Amazon DSP periodic crawl',
        confidence: 'HIGH', // allowed because check ADS_TXT is FAIL
        evidence_refs: ['EV-1082-AT-A'],
        missing_info: ['Publisher CMS deployment git commit log for Oct 14', 'Direct DNS records for secondary cdn.voxmedia.com'],
      },
      {
        label: 'Seller ID mapping mismatch in app-ads.txt vs OpenRTB bid request sid',
        confidence: 'MEDIUM',
        evidence_refs: ['EV-1082-AT-A', 'EV-1082-SC-A'],
        missing_info: ['Updated ads.txt direct crawl timestamp from Amazon Support'],
      },
      {
        label: 'Unverified external crawl throttle',
        confidence: 'LOW',
        evidence_refs: ['EV-NONEXISTENT-REF-999'], // Test unverified evidence badge!
        missing_info: ['Edge CDN rate limiting headers'],
      },
    ],
    draft_message: `Hello Vox Media AdOps Team,

Our automated Amazon DSP telemetry detected that bidder seat 437 ceased bid requests to Network ID 1082 on October 14, 2026. 

Key finding:
- Evidence [EV-1082-AT-A]: The Amazon DSP ads.txt crawler reported a 404 response on 28 publisher subdomains.
- Root Cause: Missing DIRECT declaration "equativ.com, 1082, DIRECT, 00b0c441".

Recommended remediation:
1. Re-insert the Equativ direct line in your root ads.txt: "equativ.com, 1082, DIRECT, 00b0c441".
2. Purge Cloudflare/Fastly cache for https://voxmedia.com/ads.txt.
3. Once updated, notify us so we can trigger an expedited Amazon DSP recrawl ticket.

Best regards,
Equativ Yield Operations`,
    validation: {
      passed: true,
      ai_output_accepted: true,
      fallback_fields: [],
    },
  },

  // Scenario B: IVT spike (Clear cause, high confidence)
  2011: {
    network_id: 2011,
    hypotheses: [
      {
        label: 'Mobile web IVT spike (8.4%) exceeded Amazon DSP strict 2.0% threshold, triggering automated circuit-breaker',
        confidence: 'HIGH', // allowed because IVT is FAIL
        evidence_refs: ['EV-2011-IV-A'],
        missing_info: ['Referrer domain breakdown for paid user-acquisition campaigns active on Oct 18', 'Prebid.js user-agent filter log'],
      },
      {
        label: 'In-App SDK auto-refresh loop simulating continuous impressions',
        confidence: 'MEDIUM',
        evidence_refs: ['EV-2011-IV-A'],
        missing_info: ['App bundle v4.2.1 telemetry telemetry telemetry'],
      },
    ],
    draft_message: `Hello Playwire Yield Engineering,

Amazon DSP (Seat 437) has placed Network ID 2011 into automated risk isolation due to an invalid traffic surge.

Diagnostic findings:
- Evidence [EV-2011-IV-A]: Post-cut IVT escalated to 8.4%, exceeding the DSP contract ceiling of 2.0%.
- Supply Chain & ads.txt are fully valid ([EV-2011-AT-A], [EV-2011-SC-A]).

Recommended remediation:
1. Pause low-tier paid acquisition sources launched around October 18.
2. Enable pre-bid IVT filtering (e.g., HUMAN or Moat pre-bid blocking) in your wrapper.
3. Provide 48h clean traffic logs to request DSP whitelist reinstatement.

Best regards,
Equativ Quality & Yield Team`,
    validation: {
      passed: true,
      ai_output_accepted: true,
      fallback_fields: [],
    },
  },

  // Scenario C: All checks PASS or NO_DATA (Low confidence, missing info listed)
  4001: {
    network_id: 4001,
    hypotheses: [
      {
        label: 'Amazon-specific buyer DSP throttle or unannounced internal DSP pacing restriction',
        confidence: 'LOW', // NO CHECKS FAIL -> MUST NOT BE HIGH!
        evidence_refs: ['EV-4001-AT-A', 'EV-4001-SC-A', 'EV-4001-BI-A'],
        missing_info: [
          'Amazon DSP seat account manager log for partner 437',
          'Bid response error codes from Amazon DSP endpoint',
          'DSP target CPM floor sensitivity analysis',
          'Verification of Amazon buyer campaign flight dates ending Oct 19',
        ],
      },
      {
        label: 'Client-side OpenRTB 2.5 video/content attribute omission causing silent DSP bid drop',
        confidence: 'LOW',
        evidence_refs: ['EV-4001-AT-A'],
        missing_info: ['Inspection of imp.ext.gpid and video.plcmt in live bid stream'],
      },
    ],
    draft_message: `Hello Penske Media Ad Tech,

Our monitoring indicates a 91% reduction in Amazon DSP bid requests for Network ID 4001 since October 19.

Investigation summary:
- Core supply health checks (ads.txt, schain, blocked inventory) all report PASS.
- Network auctions remain steady (+0.3%), confirming the drop is Amazon-specific.
- The root cause is currently indeterminate due to missing DSP buyer error logs.

Next steps:
- We have opened a priority ticket with Amazon DSP Partner Support.
- Please verify if any floor price rules or wrapper timeout parameters were adjusted on Oct 19.

Best regards,
Equativ Partner Solutions`,
    validation: {
      passed: true,
      ai_output_accepted: true,
      fallback_fields: ['dsp_buyer_error_code'],
    },
  },

  // Network 5010: SCO failure
  5010: {
    network_id: 5010,
    hypotheses: [
      {
        label: 'Supply Chain Object (SCO) verification failure: sellers.json sid discrepancy',
        confidence: 'HIGH',
        evidence_refs: ['EV-5010-SC-A'],
        missing_info: ['Historical sellers.json cache invalidation timestamp on Amazon DSP crawler'],
      },
    ],
    draft_message: `Hello Condé Nast Ad Operations,

Network ID 5010 experienced a cutoff from Amazon DSP seat 437 due to an schain validation failure [EV-5010-SC-A].
Please ensure sellers.json declares asi=equativ.com and matching seller_id=5010 with seller_type=PUBLISHER.`,
    validation: {
      passed: true,
      ai_output_accepted: true,
      fallback_fields: [],
    },
  },
};

/**
 * OpenRTB signals readiness checklist (OpenRTB 2.5/2.6)
 * Signals:
 * content.genre, content.genres, content.contentrating, content.keywords, content.kwarray, content.id,
 * video.plcmt, video.placement, video.api, video.ext.orientation,
 * app.content.url,
 * imp.ext.gpid, imp.secure,
 * regs.ext.agerange, regs.gpp, regs.gpp_sid, regs.us_privacy, regs.ext.gdpr, regs.ext.gpc,
 * device.lmt, device.dnt
 * Tag content.* group "Not fully relevant until January 2027"
 */
export const READINESS_SIGNALS_TEMPLATE: OpenRtbSignalStatus[] = [
  // content.* group
  { signal: 'content.genre', category: 'content', present: false, valueDescription: 'IAB Category tag' },
  { signal: 'content.genres', category: 'content', present: false, valueDescription: 'Array of genre strings' },
  { signal: 'content.contentrating', category: 'content', present: true, valueDescription: 'MPAA/TV-PG rating' },
  { signal: 'content.keywords', category: 'content', present: true, valueDescription: 'Comma-delimited keywords' },
  { signal: 'content.kwarray', category: 'content', present: false, valueDescription: 'Structured keyword tokens' },
  { signal: 'content.id', category: 'content', present: true, valueDescription: 'Canonical content asset ID' },

  // video.* group
  { signal: 'video.plcmt', category: 'video', present: false, valueDescription: 'IAB plcmt standard (1-4)' },
  { signal: 'video.placement', category: 'video', present: true, valueDescription: 'Legacy placement type' },
  { signal: 'video.api', category: 'video', present: true, valueDescription: 'VPAID/OMID supported (7)' },
  { signal: 'video.ext.orientation', category: 'video', present: false, valueDescription: 'Portrait vs Landscape hint' },

  // app.* group
  { signal: 'app.content.url', category: 'app', present: true, valueDescription: 'Deep-link / store URL' },

  // imp.* group
  { signal: 'imp.ext.gpid', category: 'imp', present: true, valueDescription: 'Global Placement ID' },
  { signal: 'imp.secure', category: 'imp', present: true, valueDescription: 'HTTPS compliance flag (1)' },

  // regs.* group
  { signal: 'regs.ext.agerange', category: 'regs', present: false, valueDescription: 'COPPA age-bracket hint' },
  { signal: 'regs.gpp', category: 'regs', present: true, valueDescription: 'Global Privacy Platform string' },
  { signal: 'regs.gpp_sid', category: 'regs', present: true, valueDescription: 'GPP Section IDs active' },
  { signal: 'regs.us_privacy', category: 'regs', present: true, valueDescription: 'IAB CCPA 1YYN string' },
  { signal: 'regs.ext.gdpr', category: 'regs', present: true, valueDescription: 'GDPR applicability flag' },
  { signal: 'regs.ext.gpc', category: 'regs', present: false, valueDescription: 'Global Privacy Control flag' },

  // device.* group
  { signal: 'device.lmt', category: 'device', present: true, valueDescription: 'Limit Ad Tracking flag (0/1)' },
  { signal: 'device.dnt', category: 'device', present: true, valueDescription: 'Do Not Track header flag' },
];

/**
 * Generate network-specific readiness checklists
 */
export function getReadinessChecklist(networkId: number): OpenRtbSignalStatus[] {
  // Customize based on network
  if (networkId === 1082) {
    return READINESS_SIGNALS_TEMPLATE.map(s => {
      if (s.signal === 'video.plcmt') return { ...s, present: true };
      if (s.signal === 'content.kwarray') return { ...s, present: true };
      return s;
    });
  }
  if (networkId === 4005) {
    // 4005 is missing video.plcmt
    return READINESS_SIGNALS_TEMPLATE.map(s => {
      if (s.signal === 'video.plcmt') return { ...s, present: false, valueDescription: 'MISSING - caused drop' };
      return s;
    });
  }
  return READINESS_SIGNALS_TEMPLATE;
}
