/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Unit tests for The Pitt engine logic
 * Tests priority classification, reconciliation invariants, AI guardrails, and what-if simulation.
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  enrichAndFilterCohort,
  calculateKpis,
  deriveSankeyData,
  checkReconciliation,
  determinePriority,
  getAgingBucket,
  simulateWhatIf,
  getAIInvestigation,
  DEFAULT_ENGINE_CONFIG,
} from './engine.ts';
import { DISCONNECTIONS_DATA, CHECKS_DATA, TRAFFIC_METRICS_DATA } from './data.ts';

test('Reconciliation Invariant: Sankey total == KPI total == Risk table total', () => {
  const cohort = enrichAndFilterCohort(DISCONNECTIONS_DATA);
  const recon = checkReconciliation(cohort);

  assert.equal(recon.ok, true, `Reconciliation should match: ${recon.message}`);
  assert.equal(recon.sankeyTotal, recon.kpiTotal);
  assert.equal(recon.kpiTotal, recon.tableTotal);
  assert.ok(recon.kpiTotal > 0, 'Revenue at risk should be greater than zero for synthetic data');
});

test('Priority Engine: P0, P1, P2 logic adheres to contract', () => {
  // P0: still disconnected AND SPEND_7D_BEFORE >= 10,000
  const p0Row = {
    PARTNER_ID: 437,
    PARTNER_NAME: 'Amazon DSP US',
    PUBLISHER: 'Test Pub',
    NETWORK_ID: 9999,
    BUSINESS_UNIT: 'Web & Media' as const,
    USERNAME: 'test@equativ.com',
    CUT_AT: '2026-10-10T00:00:00Z',
    RECONNECTED_AT: null,
    SPEND_7D_BEFORE: 12000,
    REGION: 'Americas' as const,
    REVENUE_DROP_PCT: 100,
    ONE_LINE_REASON: 'Test reason',
  };
  assert.equal(determinePriority(p0Row, DEFAULT_ENGINE_CONFIG), 'P0');

  // P1: SPEND_7D_BEFORE >= 1,000 OR revenue drop >= 50%
  const p1Row = {
    ...p0Row,
    SPEND_7D_BEFORE: 3500,
    REVENUE_DROP_PCT: 40,
  };
  assert.equal(determinePriority(p1Row, DEFAULT_ENGINE_CONFIG), 'P1');

  // P2: still disconnected with missing revenue
  const p2Row = {
    ...p0Row,
    SPEND_7D_BEFORE: null,
  };
  assert.equal(determinePriority(p2Row, DEFAULT_ENGINE_CONFIG), 'P2');
});

test('Aging buckets correctly classify cut days', () => {
  assert.equal(getAgingBucket(0), 'Current');
  assert.equal(getAgingBucket(4), '1–7');
  assert.equal(getAgingBucket(21), '8–30');
  assert.equal(getAgingBucket(45), '31–90');
  assert.equal(getAgingBucket(110), '90+');
});

test('AI Guardrail: If no check is FAIL, never display HIGH confidence', () => {
  // Network 4001 has no failing checks
  const ai = getAIInvestigation(4001, CHECKS_DATA, TRAFFIC_METRICS_DATA);
  assert.ok(ai !== null);
  for (const hyp of ai.hypotheses) {
    assert.notEqual(hyp.displayConfidence, 'HIGH', 'Confidence must not be HIGH when no check is FAIL');
  }
});

test('AI Guardrail: Unverified evidence refs are flagged', () => {
  // Network 1082 has EV-NONEXISTENT-REF-999
  const ai = getAIInvestigation(1082, CHECKS_DATA, TRAFFIC_METRICS_DATA);
  assert.ok(ai !== null);
  const unverified = ai.hypotheses.flatMap(h => h.verifiedEvidenceRefs).find(r => r.ref === 'EV-NONEXISTENT-REF-999');
  assert.ok(unverified !== undefined);
  assert.equal(unverified.isVerified, false, 'Nonexistent evidence ref must be flagged as unverified');
});

test('Traffic Signal: Banner shows "Drop is Amazon-specific" only when auctions stable & Amazon dropped', () => {
  // Network 4001 has stable auctions (+0.3%) and Amazon dropped (-91.4%)
  const ai4001 = getAIInvestigation(4001, CHECKS_DATA, TRAFFIC_METRICS_DATA);
  assert.ok(ai4001 !== null);
  assert.equal(ai4001.isAmazonSpecificDrop, true);

  // Network 9028 has site-wide auction collapse (-45%), so drop is NOT Amazon-specific
  const ai9028 = getAIInvestigation(9028, CHECKS_DATA, TRAFFIC_METRICS_DATA);
  assert.ok(ai9028 !== null);
  assert.equal(ai9028.isAmazonSpecificDrop, false);
});

test('What-If Engine: Correctly projects recovered revenue and shifts P0', () => {
  const cohort = enrichAndFilterCohort(DISCONNECTIONS_DATA);
  const whatIf = simulateWhatIf(cohort, {
    networksFixedCount: 0,
    fixAdsTxt: true,
    fixSco: false,
    fixIvt: false,
    fixBlockedInventory: false,
  });

  assert.equal(whatIf.label, 'Projection, not a forecast');
  assert.ok(whatIf.projectedRevenueRecovered > 0, 'Fixing ads.txt should recover revenue');
  assert.ok(whatIf.projectedRemainingAtRisk < cohort.reduce((s, r) => s + r.revenueAtRisk, 0));
});
