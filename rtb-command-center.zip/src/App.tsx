/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * RTB Command Center · Equativ TechOps
 * Evidence-based publisher and demand diagnostics
 */

import React, { useState } from 'react';
import { RTBViewModel, DisconnectionPartnerRecord } from './lib/adapter/types.ts';
import {
  getInitialSampleModel,
  getFinalizedSampleModel,
} from './lib/adapter/parser.ts';
import { RTBHeader } from './components/rtb/RTBHeader.tsx';
import { RTBOverviewCards } from './components/rtb/RTBOverviewCards.tsx';
import { RTBCentralVisual } from './components/rtb/RTBCentralVisual.tsx';
import { RTBDisconnectionsTable } from './components/rtb/RTBDisconnectionsTable.tsx';
import { RTBInvestigationPanel } from './components/rtb/RTBInvestigationPanel.tsx';
import { RTBAmazonDspViews } from './components/rtb/RTBAmazonDspViews.tsx';
import { RTBValidationPanel } from './components/rtb/RTBValidationPanel.tsx';
import { RTBSpecsAdapter } from './components/rtb/RTBSpecsAdapter.tsx';
import { RTBDataImportModal } from './components/rtb/RTBDataImportModal.tsx';
import { RTBDetailDrawer } from './components/rtb/RTBDetailDrawer.tsx';
import {
  AlertTriangle,
  Code,
  Copy,
  Check,
  X,
  Database,
  Layers,
  Sparkles,
} from 'lucide-react';

export default function App() {
  const [model, setModel] = useState<RTBViewModel>(() => getInitialSampleModel());
  const [activeTab, setActiveTab] = useState<'overview' | 'disconnections' | 'signals' | 'validation' | 'specs'>('overview');
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isRawSourceModalOpen, setIsRawSourceModalOpen] = useState(false);
  const [selectedDisconnection, setSelectedDisconnection] = useState<DisconnectionPartnerRecord | null>(null);
  const [copiedRaw, setCopiedRaw] = useState(false);

  const handleCopyRaw = () => {
    navigator.clipboard.writeText(model.rawSourceJson);
    setCopiedRaw(true);
    setTimeout(() => setCopiedRaw(false), 2000);
  };

  const handleLoadSample = () => {
    setModel(getInitialSampleModel());
  };

  const handleLoadFinalized = () => {
    setModel(getFinalizedSampleModel());
  };

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* 1. Top Source Banner */}
      {model.sourceType === 'sample_input' ? (
        <aside
          aria-label="Workflow sample input notice"
          className="bg-amber-950/70 border-b border-amber-500/30 text-amber-300 text-xs py-1.5 px-4 text-center flex flex-wrap items-center justify-center gap-1.5 relative z-20"
        >
          <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <span>
            <strong>Sample workflow input — not production data.</strong> Workflow priority, confidence, and Gemini validation have not yet executed on this raw input.
          </span>
          <button
            onClick={handleLoadFinalized}
            className="underline hover:text-white text-[11px] font-semibold ml-1 cursor-pointer"
          >
            Preview finalized executed report output &rarr;
          </button>
        </aside>
      ) : model.sourceType === 'finalized_report' ? (
        <aside
          aria-label="Finalized report preview notice"
          className="bg-emerald-950/60 border-b border-emerald-500/30 text-emerald-300 text-xs py-1.5 px-4 text-center flex flex-wrap items-center justify-center gap-1.5 relative z-20"
        >
          <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span>
            <strong>Previewing Finalized Executed Report Output.</strong> Deterministic derivations (P0 · HIGH), Gemini narrative, and Boundary C validation verified.
          </span>
          <button
            onClick={handleLoadSample}
            className="underline hover:text-white text-[11px] font-semibold ml-1 cursor-pointer"
          >
            Switch back to raw sample input &rarr;
          </button>
        </aside>
      ) : null}

      {/* 2. Top Header & Metadata Strip */}
      <RTBHeader
        model={model}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onOpenImport={() => setIsImportModalOpen(true)}
        onOpenSourceViewer={() => setIsRawSourceModalOpen(true)}
        onLoadSampleInput={handleLoadSample}
        onLoadFinalizedDemo={handleLoadFinalized}
      />

      {/* 3. Main Operational Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {activeTab === 'overview' && (
          <div className="space-y-6 animate-in fade-in">
            {/* KPI Cards Strip */}
            <RTBOverviewCards model={model} />

            {/* Central Visual: Bid-Request Collapse Comparison & Demand Flow */}
            <RTBCentralVisual model={model} />

            {/* Investigation & Evidence Ledger */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <RTBInvestigationPanel model={model} />
              <RTBDisconnectionsTable
                model={model}
                onSelectRecord={rec => setSelectedDisconnection(rec)}
              />
            </div>
          </div>
        )}

        {activeTab === 'disconnections' && (
          <div className="space-y-6 animate-in fade-in">
            <RTBDisconnectionsTable
              model={model}
              onSelectRecord={rec => setSelectedDisconnection(rec)}
            />
          </div>
        )}

        {activeTab === 'signals' && (
          <div className="space-y-6 animate-in fade-in">
            <RTBAmazonDspViews model={model} />
          </div>
        )}

        {activeTab === 'validation' && (
          <div className="space-y-6 animate-in fade-in">
            <RTBValidationPanel model={model} />
          </div>
        )}

        {activeTab === 'specs' && (
          <div className="space-y-6 animate-in fade-in">
            <RTBSpecsAdapter />
          </div>
        )}
      </main>

      {/* 4. Data Import Modal */}
      <RTBDataImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onApplyModel={newModel => {
          setModel(newModel);
          setIsImportModalOpen(false);
        }}
      />

      {/* 5. Detail Drawer for specific partner disconnections */}
      <RTBDetailDrawer
        record={selectedDisconnection}
        onClose={() => setSelectedDisconnection(null)}
        model={model}
      />

      {/* 6. Raw Source JSON Modal */}
      {isRawSourceModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in">
          <div className="bg-[#0d1424] border border-white/10 rounded-2xl w-full max-w-3xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="p-4 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Code className="w-4 h-4 text-blue-400" />
                <h2 className="text-sm font-bold text-white">Active Source JSON Payload</h2>
                <span className="text-[11px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono-num">
                  {model.sourceType === 'sample_input' ? 'Raw Sample Input' : 'Finalized Report'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopyRaw}
                  className="px-2.5 py-1 rounded bg-slate-800 text-xs text-slate-300 hover:text-white flex items-center gap-1.5"
                >
                  {copiedRaw ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedRaw ? 'Copied' : 'Copy JSON'}</span>
                </button>
                <button
                  onClick={() => setIsRawSourceModalOpen(false)}
                  className="p-1 rounded text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div className="p-4 overflow-y-auto flex-1 font-mono text-xs text-slate-300 bg-slate-950">
              <pre className="whitespace-pre-wrap break-all leading-relaxed">{model.rawSourceJson}</pre>
            </div>
          </div>
        </div>
      )}

      {/* 7. Footer */}
      <footer className="border-t border-white/10 bg-[#070b14] py-4 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-slate-400 font-medium">RTB Command Center</span>
            <span>·</span>
            <span>Equativ TechOps</span>
            <span>·</span>
            <span className="font-mono-num text-[11px]">Workflow: [TechOps] RTB-Checklist-Output-Generation</span>
          </div>

          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <span>
              Mode: <strong className="text-white font-mono-num">{model.sourceType}</strong>
            </span>
            <span>·</span>
            <span>
              Reporting Window: <span className="font-mono-num text-slate-300">{model.metadata.moduleReportingWindow}</span>
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
